"use client";

import * as React from "react";
import {
  Target,
  ArrowLeft,
  Check,
  X,
  Lock,
  ChevronRight,
  Award,
  Lightbulb,
  Bot,
  Flag,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill, EmptyState } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import CandleChart, { type ChartMark, type PriceLine } from "@/components/candle-chart";
import { generateSeries, fmtPrice } from "@/lib/market";
import {
  findSupportLevels,
  findResistanceLevels,
  detectTrend,
} from "@/lib/patterns";
import { ROOMS, type Room, type RoomObjective } from "@/lib/content";
import { useTraderApi } from "@/lib/client-api";
import { rankForXp } from "@/lib/ranks";

// Choice questions for choice-type objectives, keyed by objective id.
const CHOICES: Record<string, { question: string; options: string[]; correct: number; explain: string }> = {
  dir: {
    question: "What is the prevailing trend on this chart?",
    options: ["Uptrend", "Downtrend", "Ranging / Sideways"],
    correct: 0, // corrected dynamically against detectTrend
    explain: "Read the sequence of highs and lows: HH/HL = uptrend, LH/LL = downtrend.",
  },
  size: {
    question: "Account ₹1,00,000. Entry ₹100, Stop ₹98. What position size respects the 1% rule?",
    options: ["250 shares", "500 shares", "1,000 shares", "5,000 shares"],
    correct: 1,
    explain: "1% of ₹1,00,000 = ₹1,000 risk. Stop distance ₹2. Size = ₹1,000 ÷ ₹2 = 500 shares.",
  },
  rr: {
    question: "What is the minimum Risk-to-Reward ratio a disciplined trader accepts?",
    options: ["1 : 0.5", "1 : 1", "1 : 2", "1 : 5"],
    correct: 2,
    explain: "1:2 lets you break even at a 33% win rate. Below that, the math fights you.",
  },
  dd: {
    question: "What's a sensible maximum daily drawdown limit for a developing trader?",
    options: ["2%", "5%", "10%", "20%"],
    correct: 1,
    explain: "A 5% daily loss limit stops the death spiral of revenge trading while leaving room to come back.",
  },
};

type ObjKind = "click-support" | "click-resistance" | "click-entry" | "click-sl" | "click-tp" | "click-confirm" | "choice-trend" | "choice-size" | "choice-rr" | "choice-dd";

function kindFor(obj: RoomObjective): ObjKind {
  const id = obj.id;
  if (id.startsWith("s")) return "click-support";
  if (id.startsWith("r") || id === "level") return "click-resistance";
  if (id === "entry") return "click-entry";
  if (id === "sl" || id === "stop") return "click-sl";
  if (id === "tp") return "click-tp";
  if (id === "confirm") return "click-confirm";
  if (id === "dir") return "choice-trend";
  if (id === "size") return "choice-size";
  if (id === "rr") return "choice-rr";
  if (id === "dd") return "choice-dd";
  return "click-entry";
}

export function RoomsModule() {
  const progress = useStore((s) => s.progress);
  const trader = useStore((s) => s.trader);
  const [selectedId, setSelectedId] = React.useState<string | null>(null);

  // Rooms completed tracked via lesson-progress store keyed by room id prefixed "room:".
  const completedRooms = new Set(
    progress.filter((p) => p.status === "completed" && p.lessonId.startsWith("room:")).map((p) => p.lessonId.slice(5))
  );

  const selected = ROOMS.find((r) => r.id === selectedId) ?? null;

  return (
    <div>
      <ModuleHeader
        title="Trading Rooms"
        description="Mission-based challenges inspired by TryHackMe. Identify levels, place trades, and prove your edge."
        icon={<Target className="size-5" />}
      />
      {selected ? (
        <RoomView
          room={selected}
          isCompleted={completedRooms.has(selected.id)}
          onBack={() => setSelectedId(null)}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {ROOMS.map((r, i) => {
            const done = completedRooms.has(r.id);
            const prevDone = i === 0 || completedRooms.has(ROOMS[i - 1].id);
            const rankOk = trader ? trader.rank >= (r.level === "Beginner" ? 1 : r.level === "Intermediate" ? 2 : 3) : true;
            const locked = !prevDone && !done;
            return (
              <Card
                key={r.id}
                className={"group relative p-5 transition-all " + (locked ? "opacity-60" : "cursor-pointer hover:border-emerald-500/40 hover:shadow-lg")}
                onClick={() => !locked && setSelectedId(r.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex size-11 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
                    <Flag className="size-5" />
                  </div>
                  {done ? (
                    <Pill tone="up"><Check className="size-3" /> Completed</Pill>
                  ) : locked ? (
                    <Pill><Lock className="size-3" /> Locked</Pill>
                  ) : (
                    <Pill tone="sky">{r.level}</Pill>
                  )}
                </div>
                <h3 className="mt-3 text-lg font-bold text-foreground">{r.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{r.blurb}</p>
                <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                  <Target className="size-3" /> {r.objectives.length} objectives
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-sm font-semibold text-emerald-400">+{r.xp} XP</span>
                  {!locked && (
                    <span className="flex items-center text-sm font-medium text-emerald-400 opacity-0 transition-opacity group-hover:opacity-100">
                      {done ? "Replay" : "Enter Room"} <ChevronRight className="size-4" />
                    </span>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function RoomView({
  room,
  isCompleted,
  onBack,
}: {
  room: Room;
  isCompleted: boolean;
  onBack: () => void;
}) {
  const { toast } = useToast();
  const api = useTraderApi();
  const data = React.useMemo(
    () => generateSeries(room.seed, room.count, room.startPrice),
    [room]
  );
  const supports = React.useMemo(() => findSupportLevels(data), [data]);
  const resistances = React.useMemo(() => findResistanceLevels(data), [data]);
  const trend = React.useMemo(() => detectTrend(data), [data]);
  const maxVolIdx = React.useMemo(() => {
    let mi = 0;
    let mv = -1;
    data.forEach((c, i) => {
      if (c.volume > mv) {
        mv = c.volume;
        mi = i;
      }
    });
    return mi;
  }, [data]);

  const [step, setStep] = React.useState(0);
  const [results, setResults] = React.useState<Record<string, boolean>>({});
  const [marks, setMarks] = React.useState<ChartMark[]>([]);
  const [lines, setLines] = React.useState<PriceLine[]>([]);
  const [clickFeedback, setClickFeedback] = React.useState<string>("");
  const [entryPrice, setEntryPrice] = React.useState<number | null>(null);
  const [slPrice, setSlPrice] = React.useState<number | null>(null);
  const [completed, setCompleted] = React.useState(false);
  const [aiEval, setAiEval] = React.useState<string>("");
  const [loadingEval, setLoadingEval] = React.useState(false);

  const total = room.objectives.length;
  const currentObj = room.objectives[step];
  const done = step >= total || completed;

  const validateClick = (idx: number, obj: RoomObjective): { ok: boolean; msg: string; price?: number } => {
    const kind = kindFor(obj);
    const candle = data[idx];
    if (kind === "click-support") {
      const near = supports.find((s) => Math.abs(s.price - candle.low) / s.price < 0.015);
      if (near) return { ok: true, msg: `✓ Valid support near ${fmtPrice(near.price)}.`, price: candle.low };
      return { ok: false, msg: "Not a strong support zone. Find a price where price bounced multiple times." };
    }
    if (kind === "click-resistance") {
      const near = resistances.find((r) => Math.abs(r.price - candle.high) / r.price < 0.015);
      if (near) return { ok: true, msg: `✓ Valid resistance near ${fmtPrice(near.price)}.`, price: candle.high };
      return { ok: false, msg: "Not a strong resistance zone. Find a ceiling tested more than once." };
    }
    if (kind === "click-confirm") {
      if (Math.abs(idx - maxVolIdx) <= 2)
        return { ok: true, msg: "✓ High-volume breakout candle confirmed.", price: candle.close };
      return { ok: false, msg: "Look for the candle with the tallest volume bar — that's the conviction candle." };
    }
    if (kind === "click-entry") {
      setEntryPrice(candle.close);
      return { ok: true, msg: `✓ Entry marked at ${fmtPrice(candle.close)}.`, price: candle.close };
    }
    if (kind === "click-sl") {
      setSlPrice(candle.low);
      const belowEntry = entryPrice != null && candle.low < entryPrice;
      return {
        ok: true,
        msg: belowEntry
          ? `✓ Stop placed at ${fmtPrice(candle.low)} (below entry — sensible).`
          : `⚠ Stop at ${fmtPrice(candle.low)} — make sure it's below your entry for a long.`,
        price: candle.low,
      };
    }
    if (kind === "click-tp") {
      const tp = candle.high;
      let ok = true;
      let msg = `✓ Target marked at ${fmtPrice(tp)}.`;
      if (entryPrice != null && slPrice != null) {
        const risk = Math.abs(entryPrice - slPrice);
        const reward = Math.abs(tp - entryPrice);
        const rr = risk > 0 ? reward / risk : 0;
        ok = rr >= 1.5;
        msg = ok
          ? `✓ Target at ${fmtPrice(tp)} gives R:R of 1:${rr.toFixed(2)} — solid.`
          : `⚠ Target R:R is only 1:${rr.toFixed(2)}. Aim for at least 1:2.`;
      }
      return { ok, msg, price: tp };
    }
    return { ok: true, msg: "Marked.", price: candle.close };
  };

  const handleChartClick = (idx: number) => {
    if (done || !currentObj) return;
    if (!kindFor(currentObj).startsWith("click")) return;
    const res = validateClick(idx, currentObj);
    setClickFeedback(res.msg);
    if (res.ok) {
      setResults((r) => ({ ...r, [currentObj.id]: true }));
      // Add mark/line.
      setMarks((m) => [...m, { index: idx, type: "note", label: currentObj.label.slice(0, 14) }]);
      if (res.price != null) {
        const lineType: PriceLine["type"] =
          kindFor(currentObj) === "click-sl"
            ? "sl"
            : kindFor(currentObj) === "click-tp"
            ? "tp"
            : kindFor(currentObj) === "click-entry"
            ? "entry"
            : kindFor(currentObj) === "click-support"
            ? "support"
            : "resistance";
        setLines((l) => [...l, { price: res.price!, type: lineType, label: currentObj.label.slice(0, 10) }]);
      }
      toast({ title: "✓ Objective complete", description: currentObj.label });
      setTimeout(() => {
        setStep((s) => s + 1);
        setClickFeedback("");
      }, 900);
    } else {
      toast({ title: "Try again", description: res.msg, variant: "destructive" });
    }
  };

  const handleChoice = (objId: string, optionIdx: number) => {
    if (done || !currentObj) return;
    const kind = kindFor(currentObj);
    let correctIdx = 0;
    let explain = "";
    if (kind === "choice-trend") {
      correctIdx = trend === "uptrend" ? 0 : trend === "downtrend" ? 1 : 2;
      explain = `The chart structure indicates a ${trend}. ${CHOICES.dir.explain}`;
    } else if (kind === "choice-size") {
      correctIdx = CHOICES.size.correct;
      explain = CHOICES.size.explain;
    } else if (kind === "choice-rr") {
      correctIdx = CHOICES.rr.correct;
      explain = CHOICES.rr.explain;
    } else if (kind === "choice-dd") {
      correctIdx = CHOICES.dd.correct;
      explain = CHOICES.dd.explain;
    }
    const ok = optionIdx === correctIdx;
    setResults((r) => ({ ...r, [objId]: ok }));
    if (ok) {
      toast({ title: "✓ Correct", description: explain });
      setTimeout(() => {
        setStep((s) => s + 1);
      }, 800);
    } else {
      toast({ title: "✗ Incorrect", description: explain, variant: "destructive" });
      // still advance after a moment so they're not stuck
      setTimeout(() => setStep((s) => s + 1), 1400);
    }
  };

  const finish = async () => {
    if (completed) return;
    setCompleted(true);
    const correctCount = Object.values(results).filter(Boolean).length;
    const scorePct = Math.round((correctCount / total) * 100);
    setLoadingEval(true);
    await api.setProgress({ lessonId: `room:${room.id}`, status: "completed", score: scorePct });
    await api.awardXp({ xp: room.xp, roomCompleted: true });
    // AI evaluation
    try {
      const res = await fetch("/api/ai/trade-feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trade: {
            symbol: room.symbol,
            side: "LONG",
            entry: entryPrice ?? 0,
            exit: null,
            size: 0,
            stopLoss: slPrice,
            takeProfit: null,
            pnl: null,
            rMultiple: null,
            context: `Trading Room: ${room.title}`,
            reason: `Scored ${correctCount}/${total} on objectives. Trend detected: ${trend}.`,
          },
        }),
      });
      if (res.ok) {
        const d = await res.json();
        setAiEval(d.content);
      }
    } catch {
      /* ignore */
    }
    setLoadingEval(false);
    toast({ title: `Room complete! +${room.xp} XP`, description: `Score: ${correctCount}/${total}` });
  };

  React.useEffect(() => {
    if (step >= total && !completed) {
      finish();
    }
  }, [step]);

  const correctCount = Object.values(results).filter(Boolean).length;

  return (
    <div>
      <button onClick={onBack} className="mb-4 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> All rooms
      </button>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Pill tone="sky">{room.level}</Pill>
            {isCompleted && <Pill tone="up"><Check className="size-3" /> Completed</Pill>}
          </div>
          <h1 className="mt-1 text-xl font-bold text-foreground">{room.title}</h1>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground">Reward</div>
          <div className="text-lg font-bold text-emerald-400">+{room.xp} XP</div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-0 overflow-hidden">
            <div className="border-b border-border/60 p-4">
              <p className="text-sm text-muted-foreground">{room.briefing}</p>
            </div>
            <CandleChart
              data={data}
              height={440}
              symbol={room.symbol}
              interactive={!done && currentObj ? kindFor(currentObj).startsWith("click") : false}
              onCandleClick={handleChartClick}
              marks={marks}
              lines={lines}
            />
          </Card>
          {clickFeedback && (
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">
              {clickFeedback}
            </div>
          )}
        </div>

        {/* Objectives panel */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Target className="size-4 text-emerald-400" /> Objectives
            </h3>
            <Progress value={(correctCount / total) * 100} className="mb-3 h-1.5" />
            <div className="space-y-2">
              {room.objectives.map((o, i) => {
                const r = results[o.id];
                const isCurrent = i === step && !done;
                return (
                  <div
                    key={o.id}
                    className={
                      "flex items-start gap-2.5 rounded-lg border p-2.5 text-sm " +
                      (r
                        ? "border-emerald-500/30 bg-emerald-500/5"
                        : isCurrent
                        ? "border-emerald-500/50 bg-emerald-500/10"
                        : "border-border/50")
                    }
                  >
                    <span
                      className={
                        "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold " +
                        (r
                          ? "bg-emerald-500 text-white"
                          : isCurrent
                          ? "bg-emerald-500/30 text-emerald-300"
                          : "bg-muted text-muted-foreground")
                      }
                    >
                      {r ? <Check className="size-3" /> : i + 1}
                    </span>
                    <div className="flex-1">
                      <div className={r ? "text-foreground" : isCurrent ? "font-medium text-foreground" : "text-muted-foreground"}>
                        {o.label}
                      </div>
                      {isCurrent && o.hint && (
                        <div className="mt-0.5 flex items-start gap-1 text-xs text-muted-foreground">
                          <Lightbulb className="mt-0.5 size-3 shrink-0 text-amber-400" /> {o.hint}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Current objective input */}
          {!done && currentObj && (
            <Card className="p-5">
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-emerald-400">
                Current Task
              </h3>
              <p className="mb-3 text-sm font-medium text-foreground">{currentObj.label}</p>
              {(() => {
                const kind = kindFor(currentObj);
                if (kind.startsWith("click")) {
                  return (
                    <p className="text-sm text-muted-foreground">
                      👆 Click on the chart where you identify this.
                    </p>
                  );
                }
                const key = kind.replace("choice-", "");
                const q = CHOICES[key];
                if (!q) return null;
                return (
                  <div className="space-y-2">
                    <p className="text-sm text-foreground">{q.question}</p>
                    {q.options.map((opt, i) => (
                      <button
                        key={i}
                        onClick={() => handleChoice(currentObj.id, i)}
                        className="flex w-full items-center gap-2 rounded-lg border border-border/60 p-2.5 text-left text-sm hover:border-emerald-500/40 hover:bg-muted/40"
                      >
                        <span className="flex size-5 items-center justify-center rounded-full bg-muted text-xs font-bold text-muted-foreground">
                          {String.fromCharCode(65 + i)}
                        </span>
                        {opt}
                      </button>
                    ))}
                  </div>
                );
              })()}
            </Card>
          )}

          {done && (
            <Card className="p-5">
              <div className="flex flex-col items-center text-center">
                <div className="flex size-14 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
                  <Award className="size-7" />
                </div>
                <h3 className="mt-3 text-lg font-bold text-foreground">Room Complete!</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Scored <span className="font-bold text-emerald-400">{correctCount}/{total}</span> · +{room.xp} XP earned
                </p>
                <Button className="mt-4" variant="outline" onClick={onBack}>
                  Back to Rooms
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* AI evaluation */}
      <Dialog open={!!aiEval || loadingEval} onOpenChange={() => setAiEval("")}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> AI Room Evaluation
            </DialogTitle>
            <DialogDescription>{room.title} — professional debrief</DialogDescription>
          </DialogHeader>
          {loadingEval ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="typing-dot">●</span>
              <span className="typing-dot">●</span>
              <span className="typing-dot">●</span> Analyzing your performance…
            </div>
          ) : (
            <Markdown>{aiEval || room.successFeedback}</Markdown>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
