"use client";

import * as React from "react";
import {
  CandlestickChart,
  TrendingUp,
  TrendingDown,
  Play,
  Pause,
  Zap,
  Calculator,
  X,
  Activity,
  Bot,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill, EmptyState } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import CandleChart from "@/components/candle-chart";
import { SYMBOLS, generateSeries, fmtPrice, fmtINR, fmtINRCompact, type Candle } from "@/lib/market";
import { useTraderApi } from "@/lib/client-api";
import type { Trade } from "@/lib/types";

function nextCandle(prev: Candle, rand: () => number, volatility = 0.012): Candle {
  const ret = (rand() - 0.5) * 2 * volatility + (rand() - 0.5) * 0.004;
  const open = prev.close;
  const close = Math.max(0.01, prev.close * (1 + ret));
  const bodyHigh = Math.max(open, close);
  const bodyLow = Math.min(open, close);
  const wick = prev.close * volatility * (0.5 + rand());
  const high = bodyHigh + rand() * wick;
  const low = Math.max(bodyLow * 0.5, bodyLow - rand() * wick);
  const volume = 800000 + rand() * 800000 + Math.abs(ret) * 40000000;
  const time = prev.time + 86400000;
  return {
    time,
    open: round2(open),
    high: round2(high),
    low: round2(low),
    close: round2(close),
    volume: Math.round(volume),
  };
}
function round2(n: number) {
  return Math.round(n * 100) / 100;
}
function rand() {
  return Math.random();
}

export function SimulationModule() {
  const trader = useStore((s) => s.trader);
  const trades = useStore((s) => s.trades);
  const { toast } = useToast();
  const api = useTraderApi();

  const [symbolIdx, setSymbolIdx] = React.useState(0);
  const sym = SYMBOLS[symbolIdx];
  const [candles, setCandles] = React.useState<Candle[]>([]);
  const [playing, setPlaying] = React.useState(true);
  const [speed, setSpeed] = React.useState(2500);

  // Order form
  const [side, setSide] = React.useState<"LONG" | "SHORT">("LONG");
  const [sizeStr, setSizeStr] = React.useState("");
  const [slStr, setSlStr] = React.useState("");
  const [tpStr, setTpStr] = React.useState("");
  const [reason, setReason] = React.useState("");
  const [placing, setPlacing] = React.useState(false);

  // AI feedback dialog
  const [feedback, setFeedback] = React.useState<{ open: boolean; content: string; trade: Trade | null }>({
    open: false,
    content: "",
    trade: null,
  });

  // Seed candles when symbol changes.
  React.useEffect(() => {
    setCandles(generateSeries(sym.seed, 90, sym.startPrice));
  }, [sym]);

  // Live ticking.
  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setCandles((c) => {
        if (!c.length) return c;
        const next = nextCandle(c[c.length - 1], rand);
        return [...c.slice(-160), next];
      });
    }, speed);
    return () => clearInterval(id);
  }, [playing, speed]);

  const price = candles.length ? candles[candles.length - 1].close : sym.startPrice;
  const prevClose = candles.length > 1 ? candles[candles.length - 2].close : price;
  const change = price - prevClose;
  const changePct = prevClose ? (change / prevClose) * 100 : 0;

  const openTrades = trades.filter((t) => t.status === "OPEN" && t.symbol === sym.symbol);

  // Risk calculator (live).
  const slNum = slStr ? parseFloat(slStr) : NaN;
  const tpNum = tpStr ? parseFloat(tpStr) : NaN;
  const sizeNum = sizeStr ? parseFloat(sizeStr) : NaN;
  const stopDist = Math.abs(price - slNum);
  const riskPerUnit = isFinite(stopDist) && stopDist > 0 ? stopDist : 0;
  const onePctRisk = trader ? trader.capital * 0.01 : 0;
  const suggestedSize = riskPerUnit > 0 ? Math.floor(onePctRisk / riskPerUnit) : 0;
  const riskAmount = isFinite(sizeNum) && riskPerUnit > 0 ? sizeNum * riskPerUnit : 0;
  const riskPct = trader && riskAmount ? (riskAmount / trader.capital) * 100 : 0;
  const rewardDist = Math.abs(tpNum - price);
  const rr = riskPerUnit > 0 && isFinite(rewardDist) ? rewardDist / riskPerUnit : 0;

  const placeOrder = async () => {
    if (!trader) return;
    if (!isFinite(sizeNum) || sizeNum <= 0) {
      toast({ title: "Enter a valid size", variant: "destructive" });
      return;
    }
    if (riskPct > 3) {
      toast({
        title: "Risk too high",
        description: `This risks ${riskPct.toFixed(1)}% of your account. Pros cap at 1%.`,
        variant: "destructive",
      });
    }
    setPlacing(true);
    const trade = await api.openTrade({
      symbol: sym.symbol,
      side,
      entry: price,
      size: sizeNum,
      stopLoss: isFinite(slNum) ? slNum : undefined,
      takeProfit: isFinite(tpNum) ? tpNum : undefined,
      context: "simulation",
      reason: reason || undefined,
    });
    setPlacing(false);
    if (trade) {
      toast({
        title: `${side} opened on ${sym.symbol}`,
        description: `${sizeNum} units @ ${fmtPrice(price)} · Risk ${riskPct.toFixed(1)}% · R:R ${rr.toFixed(2)}`,
      });
      setSizeStr("");
      setSlStr("");
      setTpStr("");
      setReason("");
    } else {
      toast({ title: "Failed to open trade", variant: "destructive" });
    }
  };

  const closePosition = async (t: Trade) => {
    const result = await api.closeTrade(t.id, price);
    if (result) {
      const pnl = result.trade.pnl ?? 0;
      toast({
        title: pnl >= 0 ? `Trade closed: +${fmtINRCompact(pnl)}` : `Trade closed: ${fmtINRCompact(pnl)}`,
        description: `${result.trade.rMultiple?.toFixed(2) ?? "0"}R · AI feedback ready`,
      });
      setFeedback({ open: true, content: result.aiFeedback, trade: result.trade });
    }
  };

  // Lines for open positions on the chart.
  const lines = openTrades.flatMap((t) => {
    const arr: { price: number; type: "entry" | "sl" | "tp"; label: string }[] = [
      { price: t.entry, type: "entry", label: `${t.side} entry` },
    ];
    if (t.stopLoss) arr.push({ price: t.stopLoss, type: "sl", label: "SL" });
    if (t.takeProfit) arr.push({ price: t.takeProfit, type: "tp", label: "TP" });
    return arr;
  });

  return (
    <div>
      <ModuleHeader
        title="Market Simulator"
        description="Practice with virtual capital. Real-time charts, risk control, and AI feedback on every trade."
        icon={<CandlestickChart className="size-5" />}
        actions={
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant={playing ? "default" : "outline"}
              onClick={() => setPlaying((p) => !p)}
              className={playing ? "bg-emerald-600 hover:bg-emerald-500 text-white" : ""}
            >
              {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
              {playing ? "Live" : "Paused"}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSpeed((s) => (s === 2500 ? 1200 : s === 1200 ? 600 : 2500))}
            >
              <Zap className="size-4" /> {speed === 2500 ? "1x" : speed === 1200 ? "2x" : "4x"}
            </Button>
          </div>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Chart */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-0 overflow-hidden">
            {/* Ticker header */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 p-4">
              <div className="flex items-center gap-3">
                <select
                  value={symbolIdx}
                  onChange={(e) => setSymbolIdx(Number(e.target.value))}
                  className="rounded-lg border border-border bg-background px-3 py-1.5 text-sm font-semibold text-foreground focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                >
                  {SYMBOLS.map((s, i) => (
                    <option key={s.symbol} value={i}>
                      {s.symbol} — {s.name}
                    </option>
                  ))}
                </select>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className={"size-1.5 rounded-full " + (playing ? "bg-emerald-400 pulse-ring" : "bg-muted-foreground")} />
                  {playing ? "Streaming" : "Paused"}
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold tabular-nums text-foreground">{fmtPrice(price)}</span>
                  <span className={"text-sm font-semibold " + (change >= 0 ? "text-emerald-400" : "text-rose-400")}>
                    {change >= 0 ? "+" : ""}
                    {fmtPrice(change)} ({changePct >= 0 ? "+" : ""}
                    {changePct.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>
            <CandleChart data={candles} height={420} symbol={sym.symbol} lines={lines} />
          </Card>

          {/* Open positions */}
          <Card className="p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Activity className="size-4 text-emerald-400" /> Open Positions
              {openTrades.length > 0 && <Pill tone="amber">{openTrades.length}</Pill>}
            </h3>
            {openTrades.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                No open positions on {sym.symbol}. Place an order →
              </p>
            ) : (
              <div className="space-y-2">
                {openTrades.map((t) => {
                  const upnl = t.side === "LONG" ? (price - t.entry) * t.size : (t.entry - price) * t.size;
                  return (
                    <div
                      key={t.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border/60 p-3"
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={
                            "rounded-md px-2 py-1 text-xs font-bold " +
                            (t.side === "LONG"
                              ? "bg-emerald-500/15 text-emerald-400"
                              : "bg-rose-500/15 text-rose-400")
                          }
                        >
                          {t.side}
                        </span>
                        <div>
                          <div className="text-sm font-medium text-foreground">
                            {t.size} {t.symbol} @ {fmtPrice(t.entry)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            SL {t.stopLoss ? fmtPrice(t.stopLoss) : "—"} · TP {t.takeProfit ? fmtPrice(t.takeProfit) : "—"}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className={"text-sm font-semibold tabular-nums " + (upnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
                            {upnl >= 0 ? "+" : ""}
                            {fmtINRCompact(upnl)}
                          </div>
                          <div className="text-xs text-muted-foreground">@ {fmtPrice(price)}</div>
                        </div>
                        <Button size="sm" variant="outline" onClick={() => closePosition(t)}>
                          <X className="size-3.5" /> Close
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Order panel */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-foreground">
              <TrendingUp className="size-4 text-emerald-400" /> Place Order
            </h3>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSide("LONG")}
                className={
                  "rounded-lg border py-2.5 text-sm font-semibold transition-all " +
                  (side === "LONG"
                    ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-400"
                    : "border-border/60 text-muted-foreground hover:bg-muted/40")
                }
              >
                <TrendingUp className="mr-1 inline size-4" /> Long / Buy
              </button>
              <button
                onClick={() => setSide("SHORT")}
                className={
                  "rounded-lg border py-2.5 text-sm font-semibold transition-all " +
                  (side === "SHORT"
                    ? "border-rose-500/50 bg-rose-500/15 text-rose-400"
                    : "border-border/60 text-muted-foreground hover:bg-muted/40")
                }
              >
                <TrendingDown className="mr-1 inline size-4" /> Short / Sell
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">Position Size (units)</Label>
                <Input
                  type="number"
                  placeholder={suggestedSize ? String(suggestedSize) : "e.g. 100"}
                  value={sizeStr}
                  onChange={(e) => setSizeStr(e.target.value)}
                  className="mt-1"
                />
                {suggestedSize > 0 && (
                  <button
                    onClick={() => setSizeStr(String(suggestedSize))}
                    className="mt-1 text-xs text-emerald-400 hover:underline"
                  >
                    Use 1% risk size: {suggestedSize}
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Stop Loss</Label>
                  <Input
                    type="number"
                    placeholder={fmtPrice(price * (side === "LONG" ? 0.98 : 1.02))}
                    value={slStr}
                    onChange={(e) => setSlStr(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Take Profit</Label>
                  <Input
                    type="number"
                    placeholder={fmtPrice(price * (side === "LONG" ? 1.04 : 0.96))}
                    value={tpStr}
                    onChange={(e) => setTpStr(e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Trade note (optional)</Label>
                <Input
                  placeholder="Why are you entering?"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            {/* Risk calculator */}
            <div className="mt-4 rounded-lg border border-border/60 bg-muted/30 p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <Calculator className="size-3.5" /> Risk Calculator
              </div>
              <div className="space-y-1.5 text-xs">
                <Row label="Entry (current)" value={fmtPrice(price)} />
                <Row label="Stop distance" value={riskPerUnit > 0 ? fmtPrice(riskPerUnit) : "—"} />
                <Row
                  label="Risk amount"
                  value={riskAmount > 0 ? fmtINR(riskAmount) : "—"}
                  tone={riskPct > 1 ? "down" : "default"}
                />
                <Row
                  label="% of account"
                  value={riskPct ? `${riskPct.toFixed(2)}%` : "—"}
                  tone={riskPct > 1 ? "down" : riskPct > 0 ? "up" : "default"}
                />
                <Row label="R : R" value={rr > 0 ? `1 : ${rr.toFixed(2)}` : "—"} tone={rr >= 2 ? "up" : "default"} />
                <Row label="1% risk size" value={suggestedSize ? String(suggestedSize) : "—"} />
              </div>
              {riskPct > 1 && (
                <div className="mt-2 rounded bg-rose-500/10 px-2 py-1 text-[11px] text-rose-400">
                  ⚠ Exceeds 1% rule. Pros cap risk at 1% per trade.
                </div>
              )}
            </div>

            <Button
              className="mt-4 w-full bg-emerald-600 hover:bg-emerald-500 text-white"
              disabled={placing}
              onClick={placeOrder}
            >
              {placing ? "Placing..." : `Place ${side} Order`}
            </Button>
          </Card>

          {/* Account summary */}
          {trader && (
            <Card className="p-5">
              <h3 className="mb-3 text-sm font-semibold text-foreground">Account</h3>
              <div className="space-y-1.5 text-sm">
                <Row label="Capital" value={fmtINR(trader.capital)} />
                <Row
                  label="P&L (total)"
                  value={`${trader.capital - trader.startingCapital >= 0 ? "+" : ""}${fmtINRCompact(trader.capital - trader.startingCapital)}`}
                  tone={trader.capital >= trader.startingCapital ? "up" : "down"}
                />
                <Row label="Open positions" value={String(trades.filter((t) => t.status === "OPEN").length)} />
                <Row label="Trades done" value={String(trader.tradesDone)} />
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* AI feedback dialog */}
      <Dialog open={feedback.open} onOpenChange={(o) => setFeedback((f) => ({ ...f, open: o }))}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> AI Trade Review
            </DialogTitle>
            <DialogDescription>
              {feedback.trade
                ? `${feedback.trade.side} ${feedback.trade.symbol} · ${feedback.trade.rMultiple?.toFixed(2) ?? "0"}R`
                : ""}
            </DialogDescription>
          </DialogHeader>
          {feedback.content ? (
            <Markdown>{feedback.content}</Markdown>
          ) : (
            <p className="text-sm text-muted-foreground">No feedback available.</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: string;
  tone?: "default" | "up" | "down";
}) {
  const toneCls = tone === "up" ? "text-emerald-400" : tone === "down" ? "text-rose-400" : "text-foreground";
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={"font-medium tabular-nums " + toneCls}>{value}</span>
    </div>
  );
}
