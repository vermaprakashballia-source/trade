"use client";

import * as React from "react";
import {
  BookOpen,
  Check,
  X,
  ArrowLeft,
  ChevronRight,
  Lock,
  Lightbulb,
  Award,
  RefreshCw,
  GraduationCap,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import CandleChart, { type ChartMark } from "@/components/candle-chart";
import { generateSeries, fmtPrice } from "@/lib/market";
import {
  findBullishEngulfing,
  findBearishEngulfing,
  findDoji,
  findHammer,
  findSupportLevels,
  findResistanceLevels,
} from "@/lib/patterns";
import { LESSONS, type Lesson, type ChartIdTask } from "@/lib/content";
import { useTraderApi } from "@/lib/client-api";
import * as Icons from "lucide-react";

function getIcon(name: string) {
  const I = (Icons as any)[name] ?? Icons.BookOpen;
  return <I className="size-5" />;
}

// Compute valid target candle indices for a chart-id task.
function computeTargets(task: ChartIdTask, data: ReturnType<typeof generateSeries>): number[] {
  switch (task.pattern) {
    case "bullish-engulfing":
      return findBullishEngulfing(data);
    case "bearish-engulfing":
      return findBearishEngulfing(data);
    case "doji":
      return findDoji(data).slice(-3);
    case "hammer":
      return findHammer(data).slice(-3);
    case "support": {
      const sup = findSupportLevels(data);
      return sup.map((s) => s.index);
    }
    case "resistance": {
      const res = findResistanceLevels(data);
      return res.map((r) => r.index);
    }
    case "uptrend": {
      // Most recent higher low = last support swing
      const sup = findSupportLevels(data);
      return sup.length ? [sup[sup.length - 1].index] : [data.length - 5];
    }
    case "downtrend": {
      const res = findResistanceLevels(data);
      return res.length ? [res[res.length - 1].index] : [data.length - 5];
    }
    default:
      return [Math.floor(data.length / 2)];
  }
}

export function AcademyModule() {
  const progress = useStore((s) => s.progress);
  const trader = useStore((s) => s.trader);
  const [selectedId, setSelectedId] = React.useState<string | null>(null);

  const completedIds = new Set(
    progress.filter((p) => p.status === "completed").map((p) => p.lessonId)
  );

  const selected = LESSONS.find((l) => l.id === selectedId) ?? null;

  const levelStats = (level: Lesson["level"]) => {
    const list = LESSONS.filter((l) => l.level === level);
    const done = list.filter((l) => completedIds.has(l.id)).length;
    return { total: list.length, done };
  };

  return (
    <div>
      <ModuleHeader
        title="Interactive Academy"
        description="Learn by doing — theory, live chart exercises, quizzes, and instant AI-grade feedback."
        icon={<GraduationCap className="size-5" />}
      />

      {/* Level progress bars */}
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        {(["Beginner", "Intermediate", "Advanced"] as const).map((lvl) => {
          const s = levelStats(lvl);
          const pct = s.total ? (s.done / s.total) * 100 : 0;
          return (
            <Card key={lvl} className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-foreground">{lvl}</span>
                <span className="text-xs text-muted-foreground">{s.done}/{s.total}</span>
              </div>
              <Progress value={pct} className="mt-2 h-1.5" />
            </Card>
          );
        })}
      </div>

      {selected ? (
        <LessonView
          lesson={selected}
          isCompleted={completedIds.has(selected.id)}
          onBack={() => setSelectedId(null)}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {LESSONS.map((l, i) => {
            const done = completedIds.has(l.id);
            // Sequential unlock: a lesson is locked if the previous isn't done.
            const prevDone = i === 0 || completedIds.has(LESSONS[i - 1].id);
            const locked = !prevDone && !done;
            return (
              <Card
                key={l.id}
                className={
                  "group relative cursor-pointer p-5 transition-all hover:border-emerald-500/40 hover:shadow-lg " +
                  (locked ? "opacity-60" : "")
                }
                onClick={() => !locked && setSelectedId(l.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
                    {getIcon(l.icon)}
                  </div>
                  {done ? (
                    <Pill tone="up"><Check className="size-3" /> Done</Pill>
                  ) : locked ? (
                    <Pill><Lock className="size-3" /> Locked</Pill>
                  ) : (
                    <Pill tone="sky">{l.level}</Pill>
                  )}
                </div>
                <h3 className="mt-3 font-semibold text-foreground">{l.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{l.blurb}</p>
                <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <BookOpen className="size-3" /> {l.duration} min
                  </span>
                  <span className="flex items-center gap-1 font-medium text-emerald-400">
                    +{l.xp} XP
                  </span>
                </div>
                {!locked && (
                  <div className="mt-3 flex items-center text-sm font-medium text-emerald-400 opacity-0 transition-opacity group-hover:opacity-100">
                    {done ? "Review" : "Start"} <ChevronRight className="size-4" />
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function LessonView({
  lesson,
  isCompleted,
  onBack,
}: {
  lesson: Lesson;
  isCompleted: boolean;
  onBack: () => void;
}) {
  const { toast } = useToast();
  const api = useTraderApi();
  const [taskStatus, setTaskStatus] = React.useState<"idle" | "correct" | "wrong">("idle");
  const [taskAnswer, setTaskAnswer] = React.useState<number | number[] | null>(null);
  const [quizAnswer, setQuizAnswer] = React.useState<number | null>(null);
  const [quizRevealed, setQuizRevealed] = React.useState(false);
  const [finalAnswer, setFinalAnswer] = React.useState<number | null>(null);
  const [finalRevealed, setFinalRevealed] = React.useState(false);
  const [completing, setCompleting] = React.useState(false);
  const [justCompleted, setJustCompleted] = React.useState(false);

  const data = React.useMemo(
    () =>
      lesson.task.type === "chart-id"
        ? generateSeries(lesson.task.seed, lesson.task.count, lesson.task.startPrice)
        : [],
    [lesson]
  );

  const targets = React.useMemo(
    () =>
      lesson.task.type === "chart-id" ? computeTargets(lesson.task, data) : [],
    [lesson, data]
  );

  const taskDone =
    lesson.task.type === "quiz"
      ? quizRevealed && quizAnswer === lesson.task.answer
      : taskStatus === "correct";
  const finalDone = finalRevealed && finalAnswer === lesson.finalQuiz.answer;
  const readyToComplete = taskDone && finalDone;

  const handleChartClick = (idx: number) => {
    if (taskStatus === "correct") return;
    setTaskAnswer(idx);
    const hit = targets.some((t) => Math.abs(t - idx) <= 1);
    if (hit) {
      setTaskStatus("correct");
      toast({ title: "✓ Correct!", description: lesson.task.type === "chart-id" ? lesson.task.success : "" });
    } else {
      setTaskStatus("wrong");
      toast({ title: "✗ Not quite", description: lesson.task.type === "chart-id" ? lesson.task.failHint : "", variant: "destructive" });
    }
  };

  const resetTask = () => {
    setTaskStatus("idle");
    setTaskAnswer(null);
  };

  const completeLesson = async () => {
    if (!readyToComplete || completing) return;
    setCompleting(true);
    await api.setProgress({ lessonId: lesson.id, status: "completed", score: lesson.xp });
    await api.awardXp({ xp: lesson.xp, lessonCompleted: true });
    setCompleting(false);
    setJustCompleted(true);
    toast({
      title: `Lesson complete! +${lesson.xp} XP`,
      description: "Your progress and rank have been updated.",
    });
  };

  const targetMarks: ChartMark[] =
    taskStatus === "correct" && targets.length
      ? targets.slice(0, 3).map((t, i) => ({
          index: t,
          type: "note",
          label: i === 0 ? "Target" : undefined,
        }))
      : [];

  return (
    <div>
      <button
        onClick={onBack}
        className="mb-4 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> All lessons
      </button>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-12 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
            {getIcon(lesson.icon)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <Pill tone="sky">{lesson.level}</Pill>
              <Pill>{lesson.category}</Pill>
              {isCompleted && <Pill tone="up"><Check className="size-3" /> Completed</Pill>}
            </div>
            <h1 className="mt-1 text-xl font-bold text-foreground">{lesson.title}</h1>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground">Reward</div>
          <div className="text-lg font-bold text-emerald-400">+{lesson.xp} XP</div>
        </div>
      </div>

      {/* Theory */}
      <Card className="mb-4 p-5">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          <BookOpen className="size-4" /> Theory
        </h2>
        <div className="space-y-4">
          {lesson.sections.map((s, i) => (
            <div key={i}>
              <h3 className="text-base font-semibold text-foreground">{s.heading}</h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
          <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-emerald-400">
            <Lightbulb className="size-3.5" /> Key Points
          </div>
          <ul className="space-y-1">
            {lesson.keyPoints.map((k, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                <Check className="mt-0.5 size-3.5 shrink-0 text-emerald-400" />
                {k}
              </li>
            ))}
          </ul>
        </div>
      </Card>

      {/* Interactive task */}
      <Card className="mb-4 p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <Target2 /> Interactive Task
          </h2>
          {taskDone && <Pill tone="up"><Check className="size-3" /> Solved</Pill>}
        </div>

        {lesson.task.type === "chart-id" ? (
          <div>
            <p className="mb-3 text-sm text-foreground">{lesson.task.instruction}</p>
            <div className="overflow-hidden rounded-xl border border-border/60">
              <CandleChart
                data={data}
                height={360}
                symbol={lesson.task.symbol}
                interactive={taskStatus !== "correct"}
                onCandleClick={handleChartClick}
                marks={targetMarks}
              />
            </div>
            {taskStatus === "correct" && (
              <div className="mt-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">
                <Check className="mr-1 inline size-4" />
                {lesson.task.success}
              </div>
            )}
            {taskStatus === "wrong" && (
              <div className="mt-3 flex items-start justify-between gap-3 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-300">
                <span>
                  <X className="mr-1 inline size-4" />
                  {lesson.task.failHint}
                </span>
                <Button size="sm" variant="ghost" onClick={resetTask}>
                  <RefreshCw className="size-3.5" /> Try again
                </Button>
              </div>
            )}
          </div>
        ) : (
          <QuizBlock
            question={lesson.task.question}
            options={lesson.task.options}
            answer={lesson.task.answer}
            explanation={lesson.task.explanation}
            selected={quizAnswer}
            revealed={quizRevealed}
            onSelect={(i) => {
              if (quizRevealed) return;
              setQuizAnswer(i);
              setQuizRevealed(true);
            }}
          />
        )}
      </Card>

      {/* Final quiz */}
      <Card className="mb-4 p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <Award className="size-4" /> Final Quiz
          </h2>
          {finalDone && <Pill tone="up"><Check className="size-3" /> Correct</Pill>}
        </div>
        <QuizBlock
          question={lesson.finalQuiz.question}
          options={lesson.finalQuiz.options}
          answer={lesson.finalQuiz.answer}
          explanation={lesson.finalQuiz.explanation}
          selected={finalAnswer}
          revealed={finalRevealed}
          onSelect={(i) => {
            if (finalRevealed) return;
            setFinalAnswer(i);
            setFinalRevealed(true);
          }}
        />
      </Card>

      {/* Complete */}
      <Card className="p-5">
        {justCompleted ? (
          <div className="flex flex-col items-center py-4 text-center">
            <div className="flex size-14 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
              <Award className="size-7" />
            </div>
            <h3 className="mt-3 text-lg font-bold text-foreground">Lesson Complete!</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              You earned <span className="font-bold text-emerald-400">+{lesson.xp} XP</span> and moved closer to your next rank.
            </p>
            <Button className="mt-4" onClick={onBack}>
              Back to Academy
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
            <div className="text-sm text-muted-foreground">
              {readyToComplete
                ? "You've mastered this lesson. Claim your XP!"
                : "Complete the interactive task and final quiz to finish this lesson."}
            </div>
            <div className="flex items-center gap-2">
              <Step done={taskDone} label="Task" />
              <Step done={finalDone} label="Quiz" />
              <Button
                disabled={!readyToComplete || completing}
                onClick={completeLesson}
                className="bg-emerald-600 hover:bg-emerald-500 text-white"
              >
                {completing ? "Completing..." : `Complete & Earn ${lesson.xp} XP`}
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

function Target2() {
  return <span className="size-2 rounded-full bg-emerald-400" />;
}

function Step({ done, label }: { done: boolean; label: string }) {
  return (
    <span
      className={
        "hidden items-center gap-1 rounded-full px-2 py-0.5 text-xs sm:inline-flex " +
        (done ? "bg-emerald-500/15 text-emerald-400" : "bg-muted text-muted-foreground")
      }
    >
      {done && <Check className="size-3" />} {label}
    </span>
  );
}

function QuizBlock({
  question,
  options,
  answer,
  explanation,
  selected,
  revealed,
  onSelect,
}: {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
  selected: number | null;
  revealed: boolean;
  onSelect: (i: number) => void;
}) {
  return (
    <div>
      <p className="mb-3 text-sm font-medium text-foreground">{question}</p>
      <div className="space-y-2">
        {options.map((opt, i) => {
          const isSelected = selected === i;
          const isCorrect = i === answer;
          let cls =
            "flex w-full items-center gap-3 rounded-lg border p-3 text-left text-sm transition-all ";
          if (!revealed) {
            cls += "border-border/60 hover:border-emerald-500/40 hover:bg-muted/40 cursor-pointer";
          } else if (isCorrect) {
            cls += "border-emerald-500/50 bg-emerald-500/10 text-emerald-300";
          } else if (isSelected) {
            cls += "border-rose-500/50 bg-rose-500/10 text-rose-300";
          } else {
            cls += "border-border/40 opacity-60";
          }
          return (
            <button
              key={i}
              className={cls}
              onClick={() => onSelect(i)}
              disabled={revealed}
            >
              <span
                className={
                  "flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-bold " +
                  (revealed && isCorrect
                    ? "bg-emerald-500 text-white"
                    : revealed && isSelected
                    ? "bg-rose-500 text-white"
                    : "bg-muted text-muted-foreground")
                }
              >
                {String.fromCharCode(65 + i)}
              </span>
              <span className="flex-1 text-foreground">{opt}</span>
              {revealed && isCorrect && <Check className="size-4 text-emerald-400" />}
              {revealed && isSelected && !isCorrect && <X className="size-4 text-rose-400" />}
            </button>
          );
        })}
      </div>
      {revealed && (
        <div className="mt-3 rounded-lg bg-muted/50 p-3 text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">Explanation: </span>
          {explanation}
        </div>
      )}
    </div>
  );
}
