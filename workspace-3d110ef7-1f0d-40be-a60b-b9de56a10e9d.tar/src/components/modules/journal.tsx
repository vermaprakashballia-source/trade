"use client";

import * as React from "react";
import {
  BookMarked,
  Bot,
  Trash2,
  TrendingUp,
  TrendingDown,
  Filter,
  RefreshCw,
  Loader2,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ModuleHeader, StatCard, Pill, EmptyState } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { fmtINR, fmtINRCompact, fmtPrice } from "@/lib/market";
import { computeMetrics } from "@/lib/trade-metrics";
import { useTraderApi } from "@/lib/client-api";
import type { Trade } from "@/lib/types";

type FilterKey = "all" | "open" | "closed" | "wins" | "losses";

export function JournalModule() {
  const trades = useStore((s) => s.trades);
  const trader = useStore((s) => s.trader);
  const api = useTraderApi();
  const [filter, setFilter] = React.useState<FilterKey>("all");
  const [detail, setDetail] = React.useState<{ open: boolean; trade: Trade | null; feedback: string; loadingFb: boolean }>({
    open: false,
    trade: null,
    feedback: "",
    loadingFb: false,
  });

  const metrics = computeMetrics(trades);

  const filtered = trades.filter((t) => {
    if (filter === "all") return true;
    if (filter === "open") return t.status === "OPEN";
    if (filter === "closed") return t.status === "CLOSED";
    if (filter === "wins") return t.status === "CLOSED" && (t.pnl ?? 0) >= 0;
    if (filter === "losses") return t.status === "CLOSED" && (t.pnl ?? 0) < 0;
    return true;
  });

  const openDetail = async (t: Trade) => {
    setDetail({ open: true, trade: t, feedback: t.aiFeedback ?? "", loadingFb: false });
    if (!t.aiFeedback && t.status === "CLOSED") {
      setDetail((d) => ({ ...d, loadingFb: true }));
      try {
        const res = await fetch("/api/ai/trade-feedback", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ trade: t }),
        });
        if (res.ok) {
          const data = await res.json();
          setDetail((d) => ({ ...d, feedback: data.content, loadingFb: false }));
        } else {
          setDetail((d) => ({ ...d, loadingFb: false }));
        }
      } catch {
        setDetail((d) => ({ ...d, loadingFb: false }));
      }
    }
  };

  const resetJournal = async () => {
    // delete all trades
    for (const t of trades) {
      await api.deleteTrade(t.id);
    }
  };

  const filters: { key: FilterKey; label: string; count: number }[] = [
    { key: "all", label: "All", count: trades.length },
    { key: "open", label: "Open", count: trades.filter((t) => t.status === "OPEN").length },
    { key: "closed", label: "Closed", count: metrics.closed },
    { key: "wins", label: "Wins", count: metrics.wins },
    { key: "losses", label: "Losses", count: metrics.losses },
  ];

  return (
    <div>
      <ModuleHeader
        title="AI Trade Journal"
        description="Every trade auto-tracked with AI feedback. Review your metrics and learn from each decision."
        icon={<BookMarked className="size-5" />}
        actions={
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" disabled={trades.length === 0}>
                <Trash2 className="size-4" /> Reset
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Reset journal?</AlertDialogTitle>
                <AlertDialogDescription>
                  This permanently deletes all {trades.length} trades. Your capital and stats will revert to their pre-trade state (capital adjusts by realized P&L already booked). This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={resetJournal} className="bg-rose-600 hover:bg-rose-500 text-white">
                  Delete all trades
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        }
      />

      {/* Metrics */}
      <div className="mb-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
        <StatCard
          label="Net P&L"
          value={`${metrics.netPnl >= 0 ? "+" : ""}${fmtINRCompact(metrics.netPnl)}`}
          tone={metrics.netPnl >= 0 ? "up" : "down"}
          icon={metrics.netPnl >= 0 ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
        />
        <StatCard label="Win Rate" value={`${metrics.closed ? metrics.winRate.toFixed(0) : 0}%`} sub={`${metrics.wins}W / ${metrics.losses}L`} tone="emerald" />
        <StatCard
          label="Profit Factor"
          value={isFinite(metrics.profitFactor) ? metrics.profitFactor.toFixed(2) : "∞"}
          sub={metrics.profitFactor >= 1.5 ? "Healthy" : metrics.profitFactor >= 1 ? "Marginal" : "Needs work"}
          tone={metrics.profitFactor >= 1.5 ? "up" : "amber"}
        />
        <StatCard label="Avg R" value={`${metrics.avgR >= 0 ? "+" : ""}${metrics.avgR.toFixed(2)}R`} sub="Per closed trade" />
        <StatCard label="Max Drawdown" value={fmtINRCompact(metrics.maxDrawdown)} sub="Peak-to-trough" tone="down" />
      </div>

      {/* Filters */}
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Filter className="size-3.5" /> Filter:
        </span>
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={
              "rounded-full px-3 py-1 text-xs font-medium transition-colors " +
              (filter === f.key
                ? "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/20"
                : "bg-muted text-muted-foreground hover:text-foreground")
            }
          >
            {f.label} <span className="opacity-70">({f.count})</span>
          </button>
        ))}
      </div>

      {/* Table */}
      <Card className="p-0 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={<BookMarked className="size-5" />}
              title="No trades to show"
              description="Place trades in the Simulator or Replay Lab to populate your journal."
            />
          </div>
        ) : (
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-medium">Symbol</th>
                  <th className="px-4 py-3 font-medium">Side</th>
                  <th className="px-4 py-3 text-right font-medium">Entry</th>
                  <th className="px-4 py-3 text-right font-medium">Exit</th>
                  <th className="px-4 py-3 text-right font-medium">Size</th>
                  <th className="px-4 py-3 text-right font-medium">P&L</th>
                  <th className="px-4 py-3 text-right font-medium">R</th>
                  <th className="px-4 py-3 font-medium">Context</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {filtered.map((t) => {
                  const pnl = t.pnl ?? 0;
                  const isOpen = t.status === "OPEN";
                  return (
                    <tr key={t.id} className="hover:bg-muted/30">
                      <td className="px-4 py-3 font-medium text-foreground">{t.symbol}</td>
                      <td className="px-4 py-3">
                        <span className={"rounded px-1.5 py-0.5 text-xs font-bold " + (t.side === "LONG" ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400")}>
                          {t.side}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{fmtPrice(t.entry)}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{t.exit != null ? fmtPrice(t.exit) : "—"}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{t.size}</td>
                      <td className={"px-4 py-3 text-right font-semibold tabular-nums " + (isOpen ? "text-muted-foreground" : pnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {isOpen ? "—" : `${pnl >= 0 ? "+" : ""}${fmtINRCompact(pnl)}`}
                      </td>
                      <td className={"px-4 py-3 text-right tabular-nums " + (isOpen ? "text-muted-foreground" : (t.rMultiple ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {isOpen || t.rMultiple == null || !isFinite(t.rMultiple) ? "—" : `${t.rMultiple >= 0 ? "+" : ""}${t.rMultiple.toFixed(2)}R`}
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="text-[10px] font-normal text-muted-foreground">{t.context}</Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(t.openedAt).toLocaleDateString()}</td>
                      <td className="px-4 py-3 text-right">
                        <Button size="sm" variant="ghost" onClick={() => openDetail(t)}>
                          <Bot className="size-3.5" /> AI
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Detail / feedback dialog */}
      <Dialog open={detail.open} onOpenChange={(o) => setDetail((d) => ({ ...d, open: o }))}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> AI Trade Review
            </DialogTitle>
            <DialogDescription>
              {detail.trade ? `${detail.trade.side} ${detail.trade.symbol} · ${detail.trade.size} units @ ${fmtPrice(detail.trade.entry)}` : ""}
            </DialogDescription>
          </DialogHeader>
          {detail.trade && (
            <div className="mb-3 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">P&L</div>
                <div className={"font-bold " + ((detail.trade.pnl ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400")}>
                  {detail.trade.pnl != null ? `${detail.trade.pnl >= 0 ? "+" : ""}${fmtINR(detail.trade.pnl)}` : "Open"}
                </div>
              </div>
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">R-Multiple</div>
                <div className="font-bold text-foreground">
                  {detail.trade.rMultiple != null && isFinite(detail.trade.rMultiple) ? `${detail.trade.rMultiple.toFixed(2)}R` : "—"}
                </div>
              </div>
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">Exit</div>
                <div className="font-bold text-foreground">{detail.trade.exit != null ? fmtPrice(detail.trade.exit) : "Open"}</div>
              </div>
            </div>
          )}
          {detail.loadingFb ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin text-emerald-400" /> Generating review…
            </div>
          ) : detail.feedback ? (
            <Markdown>{detail.feedback}</Markdown>
          ) : (
            <p className="text-sm text-muted-foreground">No AI feedback available for this trade yet.</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
