"use client";

import * as React from "react";
import {
  History,
  Play,
  Pause,
  SkipForward,
  Flag,
  TrendingUp,
  TrendingDown,
  Bot,
  RotateCcw,
  Trophy,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import CandleChart, { type PriceLine } from "@/components/candle-chart";
import { generateSeries, fmtPrice, fmtINR, fmtINRCompact, rMultiple, type Candle } from "@/lib/market";
import { findSupportLevels, findResistanceLevels } from "@/lib/patterns";
import { useTraderApi } from "@/lib/client-api";

const REPLAYS = [
  { id: "r1", title: "Bull Trend Continuation", desc: "A clean uptrend with pullbacks. Find your entry.", seed: 7142, startPrice: 22000, count: 140 },
  { id: "r2", title: "Range Breakout", desc: "Tight range, then expansion. Don't chase the fakeout.", seed: 3351, startPrice: 1480, count: 140 },
  { id: "r3", title: "Reversal at Support", desc: "Downtrend exhausting into support. Time the turn.", seed: 9023, startPrice: 2850, count: 140 },
  { id: "r4", title: "Volatile Whipsaw", desc: "Choppy, dangerous conditions. Sometimes the best trade is no trade.", seed: 5577, startPrice: 3650, count: 140 },
];

export function ReplayModule() {
  const trader = useStore((s) => s.trader);
  const { toast } = useToast();
  const api = useTraderApi();

  const [replayId, setReplayId] = React.useState(REPLAYS[0].id);
  const replay = REPLAYS.find((r) => r.id === replayId)!;
  const data = React.useMemo(() => generateSeries(replay.seed, replay.count, replay.startPrice), [replay]);

  const [visible, setVisible] = React.useState(40);
  const [playing, setPlaying] = React.useState(false);
  const [position, setPosition] = React.useState<{ side: "LONG" | "SHORT"; entry: number; sl: number | null; tp: number | null } | null>(null);
  const [closed, setClosed] = React.useState<{ exit: number; pnl: number; r: number; side: "LONG" | "SHORT"; entry: number } | null>(null);
  const [finished, setFinished] = React.useState(false);
  const [slStr, setSlStr] = React.useState("");
  const [tpStr, setTpStr] = React.useState("");
  const [debrief, setDebrief] = React.useState<{ open: boolean; content: string }>({ open: false, content: "" });
  const [loadingDebrief, setLoadingDebrief] = React.useState(false);

  // reset on replay change
  React.useEffect(() => {
    setVisible(40);
    setPlaying(false);
    setPosition(null);
    setClosed(null);
    setFinished(false);
    setSlStr("");
    setTpStr("");
    setDebrief({ open: false, content: "" });
  }, [replayId]);

  // auto-play
  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setVisible((v) => {
        if (v >= data.length) {
          setPlaying(false);
          return v;
        }
        return v + 1;
      });
    }, 700);
    return () => clearInterval(id);
  }, [playing, data.length]);

  const currentPrice = data[Math.min(visible, data.length) - 1].close;

  const lines: PriceLine[] = [];
  if (position) {
    lines.push({ price: position.entry, type: "entry", label: `${position.side} entry` });
    if (position.sl) lines.push({ price: position.sl, type: "sl", label: "SL" });
    if (position.tp) lines.push({ price: position.tp, type: "tp", label: "TP" });
  }
  if (closed) {
    lines.push({ price: closed.exit, type: "target", label: "Exit" });
  }

  const enter = (side: "LONG" | "SHORT") => {
    if (position || closed) return;
    const sl = slStr ? parseFloat(slStr) : null;
    const tp = tpStr ? parseFloat(tpStr) : null;
    setPosition({ side, entry: currentPrice, sl, tp });
    toast({ title: `${side} entered at ${fmtPrice(currentPrice)}`, description: "Manage your trade as candles reveal." });
  };

  const closePos = () => {
    if (!position) return;
    const exit = currentPrice;
    const pnl = position.side === "LONG" ? (exit - position.entry) * 100 : (position.entry - exit) * 100;
    const r = position.sl ? rMultiple(position.entry, position.sl, exit, position.side) : 0;
    setClosed({ exit, pnl, r, side: position.side, entry: position.entry });
    setPosition(null);
    setPlaying(false);
    toast({
      title: pnl >= 0 ? `Closed: +${fmtINRCompact(pnl)}` : `Closed: ${fmtINRCompact(pnl)}`,
      description: `${r.toFixed(2)}R`,
    });
  };

  const finish = async () => {
    setPlaying(false);
    setVisible(data.length);
    let finalClosed = closed;
    if (position) {
      const exit = data[data.length - 1].close;
      const pnl = position.side === "LONG" ? (exit - position.entry) * 100 : (position.entry - exit) * 100;
      const r = position.sl ? rMultiple(position.entry, position.sl, exit, position.side) : 0;
      finalClosed = { exit, pnl, r, side: position.side, entry: position.entry };
      setClosed(finalClosed);
      setPosition(null);
    }
    setFinished(true);

    // Compute "pro" reference: enter at first support, exit at next resistance.
    const sups = findSupportLevels(data.slice(0, Math.floor(data.length * 0.4)));
    const ress = findResistanceLevels(data);
    const proEntry = sups.length ? sups[0].price : data[0].close;
    const proExit = ress.length ? ress[ress.length - 1].price : data[data.length - 1].close;
    const proPnl = proExit - proEntry;
    const proR = sups.length ? (proExit - proEntry) / (proEntry * 0.02) : 0;

    setLoadingDebrief(true);
    setDebrief({ open: true, content: "" });
    // Award a small XP for completing a replay (once per finish click).
    if (trader) {
      await api.awardXp({ xp: 30, disciplineDelta: finalClosed && finalClosed.r >= 0 ? 1 : -1 });
    }
    try {
      const res = await fetch("/api/ai/trade-feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trade: {
            symbol: replay.title,
            side: finalClosed?.side ?? "LONG",
            entry: finalClosed?.entry ?? currentPrice,
            exit: finalClosed?.exit ?? data[data.length - 1].close,
            size: 100,
            stopLoss: null,
            takeProfit: null,
            pnl: finalClosed?.pnl ?? 0,
            rMultiple: finalClosed?.r ?? 0,
            context: "Trade Replay Lab",
            reason: `Replay scenario: ${replay.title}. User R: ${finalClosed?.r.toFixed(2) ?? "n/a"}. Professional reference: entering at support ${fmtPrice(proEntry)} and exiting at resistance ${fmtPrice(proExit)} would have yielded ~${proR.toFixed(2)}R (${fmtINRCompact(proPnl)} on 100 units).`,
          },
        }),
      });
      if (res.ok) {
        const d = await res.json();
        setDebrief({ open: true, content: d.content });
      }
    } catch {
      /* ignore */
    }
    setLoadingDebrief(false);
  };

  const reset = () => {
    setVisible(40);
    setPosition(null);
    setClosed(null);
    setFinished(false);
    setPlaying(false);
    setSlStr("");
    setTpStr("");
  };

  return (
    <div>
      <ModuleHeader
        title="Trade Replay Lab"
        description="Trade historical charts candle-by-candle without seeing the future. Then get an AI debrief against professional standards."
        icon={<History className="size-5" />}
        actions={
          <Button variant="outline" size="sm" onClick={reset}>
            <RotateCcw className="size-4" /> Reset
          </Button>
        }
      />

      {/* Replay selector */}
      <div className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {REPLAYS.map((r) => (
          <button
            key={r.id}
            onClick={() => setReplayId(r.id)}
            className={
              "rounded-lg border p-3 text-left transition-all " +
              (r.id === replayId
                ? "border-emerald-500/50 bg-emerald-500/10"
                : "border-border/60 hover:bg-muted/40")
            }
          >
            <div className="text-sm font-semibold text-foreground">{r.title}</div>
            <div className="mt-0.5 text-xs text-muted-foreground">{r.desc}</div>
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-0 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 p-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-foreground">{replay.title}</h3>
                  <Pill tone={finished ? "up" : "amber"}>
                    {finished ? "Revealed" : `Candle ${visible}/${data.length}`}
                  </Pill>
                </div>
                <div className="mt-0.5 text-sm tabular-nums text-muted-foreground">
                  Current price: <span className="font-semibold text-foreground">{fmtPrice(currentPrice)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant={playing ? "default" : "outline"} onClick={() => setPlaying((p) => !p)} className={playing ? "bg-emerald-600 hover:bg-emerald-500 text-white" : ""}>
                  {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
                  {playing ? "Pause" : "Play"}
                </Button>
                <Button size="sm" variant="outline" disabled={visible >= data.length} onClick={() => setVisible((v) => Math.min(data.length, v + 1))}>
                  <SkipForward className="size-4" /> Next
                </Button>
              </div>
            </div>
            <CandleChart
              data={data}
              visibleCount={visible}
              height={440}
              symbol={replay.title}
              interactive={false}
              lines={lines}
            />
          </Card>

          {/* Outcome / pro comparison */}
          {(closed || finished) && (
            <Card className="p-5">
              <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
                <Trophy className="size-4 text-amber-400" /> Your Result vs. Professional Reference
              </h3>
              {closed ? (
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="rounded-lg bg-muted/40 p-3">
                    <div className="text-xs text-muted-foreground">Your P&L</div>
                    <div className={"text-lg font-bold " + (closed.pnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
                      {closed.pnl >= 0 ? "+" : ""}
                      {fmtINRCompact(closed.pnl)}
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted/40 p-3">
                    <div className="text-xs text-muted-foreground">Your R</div>
                    <div className={"text-lg font-bold " + (closed.r >= 0 ? "text-emerald-400" : "text-rose-400")}>
                      {closed.r.toFixed(2)}R
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted/40 p-3">
                    <div className="text-xs text-muted-foreground">Entry / Exit</div>
                    <div className="text-sm font-semibold text-foreground">
                      {fmtPrice(closed.entry)} → {fmtPrice(closed.exit)}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">You didn't take a trade this session. Sometimes patience is the right call — but review whether a setup existed.</p>
              )}
              <Button className="mt-4 w-full bg-emerald-600 hover:bg-emerald-500 text-white" onClick={() => setDebrief({ open: true, content: debrief.content })}>
                <Bot className="size-4" /> View AI Debrief
              </Button>
            </Card>
          )}
        </div>

        {/* Trade panel */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Flag className="size-4 text-emerald-400" /> Your Trade
            </h3>
            {!position && !closed && (
              <>
                <p className="mb-3 text-sm text-muted-foreground">
                  Analyze the revealed candles. Enter when you spot an edge — or stay flat.
                </p>
                <div className="mb-3 grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">Stop Loss</Label>
                    <Input type="number" placeholder={fmtPrice(currentPrice * 0.98)} value={slStr} onChange={(e) => setSlStr(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Take Profit</Label>
                    <Input type="number" placeholder={fmtPrice(currentPrice * 1.04)} value={tpStr} onChange={(e) => setTpStr(e.target.value)} className="mt-1" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button className="bg-emerald-600 hover:bg-emerald-500 text-white" disabled={finished || visible >= data.length} onClick={() => enter("LONG")}>
                    <TrendingUp className="size-4" /> Enter Long
                  </Button>
                  <Button className="bg-rose-600 hover:bg-rose-500 text-white" disabled={finished || visible >= data.length} onClick={() => enter("SHORT")}>
                    <TrendingDown className="size-4" /> Enter Short
                  </Button>
                </div>
                <Button variant="ghost" className="mt-2 w-full" disabled={finished} onClick={() => setVisible((v) => Math.min(data.length, v + 1))}>
                  Stay flat, reveal next →
                </Button>
              </>
            )}
            {position && (
              <div className="space-y-3">
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
                  <div className="flex items-center justify-between">
                    <Pill tone={position.side === "LONG" ? "up" : "down"}>{position.side}</Pill>
                    <span className="text-sm font-semibold text-foreground">@ {fmtPrice(position.entry)}</span>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    SL {position.sl ? fmtPrice(position.sl) : "—"} · TP {position.tp ? fmtPrice(position.tp) : "—"}
                  </div>
                  {(() => {
                    const upnl = position.side === "LONG" ? (currentPrice - position.entry) * 100 : (position.entry - currentPrice) * 100;
                    return (
                      <div className="mt-1 text-lg font-bold tabular-nums">
                        <span className={upnl >= 0 ? "text-emerald-400" : "text-rose-400"}>
                          {upnl >= 0 ? "+" : ""}
                          {fmtINRCompact(upnl)}
                        </span>
                      </div>
                    );
                  })()}
                </div>
                <Button className="w-full" variant="outline" onClick={closePos} disabled={finished}>
                  Close at {fmtPrice(currentPrice)}
                </Button>
              </div>
            )}
            {closed && !finished && (
              <div className="rounded-lg border border-border/60 p-3 text-sm text-muted-foreground">
                Trade closed. Reveal more or finish to see your full debrief.
              </div>
            )}
            {!finished && (
              <Button className="mt-3 w-full bg-emerald-600 hover:bg-emerald-500 text-white" onClick={finish}>
                <Flag className="size-4" /> Finish Replay & Debrief
              </Button>
            )}
          </Card>

          <Card className="p-5">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Replay Progress</h3>
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div className="h-full bg-emerald-500 transition-all" style={{ width: `${(visible / data.length) * 100}%` }} />
            </div>
            <div className="mt-2 text-xs text-muted-foreground">{Math.round((visible / data.length) * 100)}% revealed</div>
          </Card>
        </div>
      </div>

      {/* AI debrief */}
      <Dialog open={debrief.open} onOpenChange={(o) => setDebrief((d) => ({ ...d, open: o }))}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> AI Replay Debrief
            </DialogTitle>
            <DialogDescription>How your decisions compare to professional standards</DialogDescription>
          </DialogHeader>
          {loadingDebrief ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="typing-dot">●</span><span className="typing-dot">●</span><span className="typing-dot">●</span> Comparing to pro play…
            </div>
          ) : (
            <Markdown>{debrief.content}</Markdown>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
