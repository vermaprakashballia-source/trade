"use client";

import * as React from "react";
import { Bot, Send, Sparkles, Trash2, User } from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { rankForXp } from "@/lib/ranks";
import type { ChatMessage } from "@/lib/types";

const SUGGESTIONS = [
  "Review my recent trading performance",
  "How do I stop revenge trading?",
  "Explain risk-to-reward with an example",
  "What's the best setup for a beginner?",
  "How do I handle a losing streak?",
];

export function MentorModule() {
  const trader = useStore((s) => s.trader);
  const [messages, setMessages] = React.useState<ChatMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [loaded, setLoaded] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  // Load history.
  React.useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/chat?module=mentor");
        if (res.ok) {
          const data = await res.json();
          setMessages(data);
        }
      } catch {
        /* ignore */
      } finally {
        setLoaded(true);
      }
    }
    load();
  }, []);

  // Auto-scroll.
  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const send = async (text: string) => {
    const content = text.trim();
    if (!content || loading) return;
    setInput("");
    const userMsg: ChatMessage = {
      id: "tmp-" + Date.now(),
      traderId: "me",
      role: "user",
      content,
      module: "mentor",
      createdAt: new Date().toISOString(),
    };
    setMessages((m) => [...m, userMsg]);
    setLoading(true);

    // Persist user message.
    try {
      await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: "user", content, module: "mentor" }),
      });
    } catch {
      /* ignore */
    }

    // Build history for AI (last 8 messages).
    const history = messages.slice(-8).map((m) => ({ role: m.role, content: m.content }));
    const ctx = trader
      ? `Name: ${trader.name}, Rank: ${rankForXp(trader.xp).name} (rank ${trader.rank}), XP: ${trader.xp}, Capital: ₹${Math.round(trader.capital).toLocaleString("en-IN")}, Trades: ${trader.tradesDone}, Win rate: ${trader.tradesDone ? Math.round((trader.wins / trader.tradesDone) * 100) : 0}%, Lessons: ${trader.lessonsCompleted}, Rooms: ${trader.roomsCompleted}, Discipline: ${Math.round(trader.disciplineScore)}/100.`
      : "";

    try {
      const res = await fetch("/api/ai/mentor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content, history, traderContext: ctx }),
      });
      const data = await res.json();
      const reply: string = data.content;
      const aiMsg: ChatMessage = {
        id: "tmp-ai-" + Date.now(),
        traderId: "me",
        role: "assistant",
        content: reply,
        module: "mentor",
        createdAt: new Date().toISOString(),
      };
      setMessages((m) => [...m, aiMsg]);
      // Persist assistant message.
      try {
        await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ role: "assistant", content: reply, module: "mentor" }),
        });
      } catch {
        /* ignore */
      }
    } catch {
      setMessages((m) => [
        ...m,
        {
          id: "err",
          traderId: "me",
          role: "assistant",
          content: "I couldn't reach my reasoning engine. Please try again.",
          module: "mentor",
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = async () => {
    // Clear local; (server history remains but we just reset the view)
    setMessages([]);
  };

  return (
    <div className="flex flex-col" style={{ height: "calc(100vh - 180px)", minHeight: 480 }}>
      <ModuleHeader
        title="AI Trading Mentor"
        description="Your personal coach — analyzes your progress, behavior, and weak spots. Ask anything."
        icon={<Bot className="size-5" />}
        actions={
          <Button variant="ghost" size="sm" onClick={clearChat}>
            <Trash2 className="size-4" /> Clear
          </Button>
        }
      />

      <Card className="flex min-h-0 flex-1 flex-col p-0 overflow-hidden">
        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin p-4 space-y-4">
          {loaded && messages.length === 0 && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-3 flex size-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
                <Bot className="size-7" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Ask your mentor anything</h3>
              <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                I know your rank, trades, and progress. I'll give you candid, risk-first guidance.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="rounded-full border border-border/60 px-3 py-1.5 text-xs text-muted-foreground hover:border-emerald-500/40 hover:text-emerald-400"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className={"flex gap-3 " + (m.role === "user" ? "flex-row-reverse" : "")}>
              <div
                className={
                  "flex size-8 shrink-0 items-center justify-center rounded-full " +
                  (m.role === "user"
                    ? "bg-sky-500/15 text-sky-400"
                    : "bg-emerald-500/15 text-emerald-400")
                }
              >
                {m.role === "user" ? <User className="size-4" /> : <Bot className="size-4" />}
              </div>
              <div
                className={
                  "max-w-[80%] rounded-2xl px-4 py-2.5 text-sm " +
                  (m.role === "user"
                    ? "bg-sky-500/10 text-foreground"
                    : "bg-muted/60 text-foreground")
                }
              >
                {m.role === "assistant" ? <Markdown>{m.content}</Markdown> : <p className="leading-relaxed">{m.content}</p>}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
                <Bot className="size-4" />
              </div>
              <div className="rounded-2xl bg-muted/60 px-4 py-3">
                <div className="flex gap-1">
                  <span className="typing-dot text-emerald-400">●</span>
                  <span className="typing-dot text-emerald-400">●</span>
                  <span className="typing-dot text-emerald-400">●</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-border/60 p-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-center gap-2"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask your mentor…"
              className="flex-1"
              disabled={loading}
            />
            <Button type="submit" size="icon" disabled={loading || !input.trim()} className="bg-emerald-600 hover:bg-emerald-500 text-white">
              <Send className="size-4" />
            </Button>
          </form>
          <div className="mt-1.5 flex items-center gap-1 px-1 text-[10px] text-muted-foreground">
            <Sparkles className="size-3 text-emerald-400" />
            Context-aware: your rank, trades & progress are shared with the mentor.
          </div>
        </div>
      </Card>
    </div>
  );
}
