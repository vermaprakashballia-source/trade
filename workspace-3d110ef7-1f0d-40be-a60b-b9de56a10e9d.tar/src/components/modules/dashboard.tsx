"use client";

import * as React from "react";
import {
  LayoutDashboard,
  Trophy,
  Wallet,
  Target,
  Flame,
  BookOpen,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ModuleHeader,
  StatCard,
  RankBadge,
  Pill,
  EmptyState,
} from "@/components/ui-bits";
import {
  fmtINR,
  fmtINRCompact,
} from "@/lib/market";
import { rankForXp, rankProgress, nextRank } from "@/lib/ranks";
import { computeMetrics, equityCurve } from "@/lib/trade-metrics";
import { LESSONS } from "@/lib/content";
import type { ViewKey } from "@/lib/types";

export function DashboardModule() {
  const trader = useStore((s) => s.trader);
  const trades = useStore((s) => s.trades);
  const progress = useStore((s) => s.progress);
  const dataLoaded = useStore((s) => s.dataLoaded);
  const setActiveView = useStore((s) => s.setActiveView);

  const [greeting, setGreeting] = React.useState<string>("");
  const [loadingGreeting, setLoadingGreeting] = React.useState(true);

  const go = (v: ViewKey) => setActiveView(v);

  React.useEffect(() => {
    let cancelled = false;
    async function loadGreeting() {
      if (!trader) return;
      setLoadingGreeting(true);
      const wr = trader.tradesDone
        ? Math.round((trader.wins / trader.tradesDone) * 100)
        : 0;
      const ctx = `Trader profile — Name: ${trader.name}, Rank: ${rankForXp(trader.xp).name} (rank ${trader.rank}), XP: ${trader.xp}, Capital: ₹${Math.round(trader.capital).toLocaleString("en-IN")}, Trades done: ${trader.tradesDone}, Wins: ${trader.wins}, Losses: ${trader.losses}, Win rate: ${wr}%, Best streak: ${trader.bestStreak}, Lessons completed: ${trader.lessonsCompleted}, Rooms completed: ${trader.roomsCompleted}, Discipline score: ${Math.round(trader.disciplineScore)}/100.`;
      try {
        const res = await fetch("/api/ai/mentor", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message:
              "Give me a brief 2-3 sentence personalized greeting as my trading mentor, acknowledge my rank and progress, and recommend ONE specific next action to grow. Be warm but candid.",
            traderContext: ctx,
          }),
        });
        const data = await res.json();
        if (!cancelled) setGreeting(data.content);
      } catch {
        if (!cancelled)
          setGreeting(
            "Welcome back, trader. Keep your risk tight and your process tighter — that's the whole game."
          );
      } finally {
        if (!cancelled) setLoadingGreeting(false);
      }
    }
    loadGreeting();
    return () => {
      cancelled = true;
    };
  }, [trader?.id, trader?.xp, trader?.tradesDone]);

  if (!dataLoaded || !trader) {
    return (
      <div>
        <ModuleHeader
          title="Dashboard"
          description="Your trading command center."
          icon={<LayoutDashboard className="size-5" />}
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <Skeleton className="mt-4 h-64 rounded-xl" />
      </div>
    );
  }

  const metrics = computeMetrics(trades);
  const rank = rankForXp(trader.xp);
  const prog = rankProgress(trader.xp);
  const nxt = nextRank(trader.xp);
  const pnl = trader.capital - trader.startingCapital;
  const pnlPctTotal = (pnl / trader.startingCapital) * 100;
  const eqData = equityCurve(trades, trader.startingCapital);

  const completedIds = new Set(
    progress.filter((p) => p.status === "completed").map((p) => p.lessonId)
  );
  const nextLesson = LESSONS.find((l) => !completedIds.has(l.id)) ?? LESSONS[0];

  const recent = trades.slice(0, 5);

  return (
    <div>
      <ModuleHeader
        title="Dashboard"
        description="Your trading command center — progress, capital, and AI mentorship in one view."
        icon={<LayoutDashboard className="size-5" />}
        actions={
          <Button onClick={() => go("simulation")} className="bg-emerald-600 hover:bg-emerald-500 text-white">
            <TrendingUp className="size-4" /> Open Simulator
          </Button>
        }
      />

      {/* Hero: rank + capital + AI greeting */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Your Rank
            </span>
            <Pill tone="emerald">
              <Sparkles className="size-3" /> Rank {rank.rank}
            </Pill>
          </div>
          <div className="mt-4">
            <RankBadge trader={trader} />
          </div>
          {nxt && (
            <div className="mt-4">
              <div className="mb-1.5 flex justify-between text-xs text-muted-foreground">
                <span>Progress to {nxt.name}</span>
                <span>{Math.round(prog.pct * 100)}%</span>
              </div>
              <Progress value={prog.pct * 100} className="h-2" />
            </div>
          )}
          <div className="mt-4 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-lg bg-muted/50 p-2">
              <div className="text-lg font-bold text-foreground">{trader.xp.toLocaleString()}</div>
              <div className="text-[10px] uppercase text-muted-foreground">Total XP</div>
            </div>
            <div className="rounded-lg bg-muted/50 p-2">
              <div className="text-lg font-bold text-foreground">{trader.lessonsCompleted}</div>
              <div className="text-[10px] uppercase text-muted-foreground">Lessons</div>
            </div>
          </div>
        </Card>

        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Sparkles className="size-3.5 text-emerald-400" /> AI Mentor Insight
          </div>
          {loadingGreeting ? (
            <div className="mt-3 space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          ) : (
            <div className="mt-3 text-sm leading-relaxed text-foreground">{greeting}</div>
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => go("mentor")}>
              Ask Mentor <ArrowRight className="size-3.5" />
            </Button>
            <Button size="sm" variant="outline" onClick={() => go("academy")}>
              <BookOpen className="size-3.5" /> Continue Learning
            </Button>
            <Button size="sm" variant="outline" onClick={() => go("rooms")}>
              <Target className="size-3.5" /> Trading Rooms
            </Button>
          </div>
        </Card>
      </div>

      {/* Stat grid */}
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Virtual Capital"
          value={fmtINRCompact(trader.capital)}
          sub={
            <span className={pnl >= 0 ? "text-emerald-400" : "text-rose-400"}>
              {pnl >= 0 ? "+" : ""}
              {fmtINRCompact(pnl)} ({pnlPctTotal >= 0 ? "+" : ""}
              {pnlPctTotal.toFixed(2)}%)
            </span>
          }
          icon={<Wallet className="size-4" />}
          tone={pnl >= 0 ? "up" : "down"}
        />
        <StatCard
          label="Win Rate"
          value={`${metrics.closed ? metrics.winRate.toFixed(0) : 0}%`}
          sub={`${metrics.wins}W / ${metrics.losses}L`}
          icon={<Target className="size-4" />}
          tone="emerald"
        />
        <StatCard
          label="Trades"
          value={trader.tradesDone}
          sub={`${metrics.open} open now`}
          icon={<TrendingUp className="size-4" />}
        />
        <StatCard
          label="Best Streak"
          value={`${trader.bestStreak} 🔥`}
          sub={`Discipline ${Math.round(trader.disciplineScore)}/100`}
          icon={<Flame className="size-4" />}
          tone="amber"
        />
      </div>

      {/* Equity curve + continue learning */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 p-5">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Equity Curve</h3>
              <p className="text-xs text-muted-foreground">Closed-trade P&L over time</p>
            </div>
            <Pill tone={metrics.netPnl >= 0 ? "up" : "down"}>
              {metrics.netPnl >= 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
              {metrics.netPnl >= 0 ? "+" : ""}
              {fmtINRCompact(metrics.netPnl)}
            </Pill>
          </div>
          {eqData.length > 1 ? (
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={eqData} margin={{ top: 5, right: 8, left: 8, bottom: 0 }}>
                  <defs>
                    <linearGradient id="eq" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis
                    tick={{ fontSize: 10, fill: "#94a3b8" }}
                    axisLine={false}
                    tickLine={false}
                    width={56}
                    tickFormatter={(v) => fmtINRCompact(v)}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "oklch(0.21 0.013 250)",
                      border: "1px solid oklch(1 0 0 / 10%)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                    labelStyle={{ color: "#94a3b8" }}
                    formatter={(v: number) => [fmtINR(v), "Equity"]}
                  />
                  <Area
                    type="monotone"
                    dataKey="equity"
                    stroke="#10b981"
                    strokeWidth={2}
                    fill="url(#eq)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex h-52 flex-col items-center justify-center text-center text-sm text-muted-foreground">
              <TrendingUp className="mb-2 size-8 text-muted-foreground/50" />
              Close a trade to start building your equity curve.
              <Button size="sm" variant="outline" className="mt-3" onClick={() => go("simulation")}>
                Place a trade
              </Button>
            </div>
          )}
        </Card>

        <Card className="p-5">
          <div className="mb-3 flex items-center gap-2">
            <BookOpen className="size-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-foreground">Continue Learning</h3>
          </div>
          <div className="rounded-lg border border-border/60 p-3">
            <div className="flex items-center justify-between">
              <Pill tone="sky">{nextLesson.level}</Pill>
              <span className="text-xs text-muted-foreground">+{nextLesson.xp} XP</span>
            </div>
            <h4 className="mt-2 font-semibold text-foreground">{nextLesson.title}</h4>
            <p className="mt-1 text-xs text-muted-foreground">{nextLesson.blurb}</p>
            <Button
              size="sm"
              className="mt-3 w-full bg-emerald-600 hover:bg-emerald-500 text-white"
              onClick={() => go("academy")}
            >
              Start Lesson <ArrowRight className="size-3.5" />
            </Button>
          </div>
          <div className="mt-3 space-y-1.5">
            {LESSONS.slice(0, 4).map((l) => {
              const done = completedIds.has(l.id);
              return (
                <button
                  key={l.id}
                  onClick={() => go("academy")}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-muted/60"
                >
                  <span
                    className={
                      "flex size-4 shrink-0 items-center justify-center rounded-full text-[9px] " +
                      (done
                        ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-muted text-muted-foreground")
                    }
                  >
                    {done ? "✓" : ""}
                  </span>
                  <span className={done ? "text-muted-foreground line-through" : "text-foreground"}>
                    {l.title}
                  </span>
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Recent trades */}
      <Card className="mt-4 p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">Recent Trades</h3>
          <Button size="sm" variant="ghost" onClick={() => go("journal")}>
            View all <ArrowRight className="size-3.5" />
          </Button>
        </div>
        {recent.length === 0 ? (
          <EmptyState
            icon={<TrendingUp className="size-5" />}
            title="No trades yet"
            description="Place your first simulated trade to start building your track record."
            action={
              <Button size="sm" onClick={() => go("simulation")} className="bg-emerald-600 hover:bg-emerald-500 text-white">
                Open Simulator
              </Button>
            }
          />
        ) : (
          <div className="divide-y divide-border/60">
            {recent.map((t) => {
              const pnlVal = t.pnl ?? 0;
              const isOpen = t.status === "OPEN";
              return (
                <div key={t.id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <div
                      className={
                        "flex size-9 items-center justify-center rounded-lg text-xs font-bold " +
                        (t.side === "LONG"
                          ? "bg-emerald-500/15 text-emerald-400"
                          : "bg-rose-500/15 text-rose-400")
                      }
                    >
                      {t.side === "LONG" ? "L" : "S"}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-foreground">{t.symbol}</span>
                        {isOpen && <Pill tone="amber">OPEN</Pill>}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {t.side} @ {fmtINR(t.entry)} · {t.size} units ·{" "}
                        {new Date(t.openedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  {!isOpen && (
                    <div className="text-right">
                      <div className={"font-semibold tabular-nums " + (pnlVal >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {pnlVal >= 0 ? "+" : ""}
                        {fmtINRCompact(pnlVal)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {t.rMultiple != null && isFinite(t.rMultiple)
                          ? `${t.rMultiple >= 0 ? "+" : ""}${t.rMultiple.toFixed(2)}R`
                          : "—"}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
