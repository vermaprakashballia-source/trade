"use client";

import * as React from "react";
import {
  Zap,
  ArrowRight,
  Check,
  X,
  Bot,
  RotateCcw,
  Newspaper,
  TrendingUp,
  TrendingDown,
  Pause,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { SCENARIOS } from "@/lib/content";
import { useTraderApi } from "@/lib/client-api";

export function ScenariosModule() {
  const { toast } = useToast();
  const api = useTraderApi();

  const [step, setStep] = React.useState(0);
  const [picked, setPicked] = React.useState<string | null>(null);
  const [aiContent, setAiContent] = React.useState<string>("");
  const [loadingAi, setLoadingAi] = React.useState(false);
  const [showAi, setShowAi] = React.useState(false);
  const [correctCount, setCorrectCount] = React.useState(0);
  const [finished, setFinished] = React.useState(false);

  const total = SCENARIOS.length;
  const current = SCENARIOS[step];
  const done = step >= total;

  const tagIcon = (tag: "Buy" | "Sell" | "Wait") =>
    tag === "Buy" ? <TrendingUp className="size-4" /> : tag === "Sell" ? <TrendingDown className="size-4" /> : <Pause className="size-4" />;
  const tagTone = (tag: "Buy" | "Sell" | "Wait") =>
    tag === "Buy" ? "up" : tag === "Sell" ? "down" : "amber";

  const choose = async (choiceId: string) => {
    if (picked) return;
    setPicked(choiceId);
    const choice = current.choices.find((c) => c.id === choiceId)!;
    const isCorrect = choiceId === current.bestChoice;
    if (isCorrect) setCorrectCount((c) => c + 1);
    toast({
      title: isCorrect ? "✓ Matches pro choice" : "✗ Different from pro",
      description: `You chose ${choice.label}.`,
      variant: isCorrect ? "default" : "destructive",
    });
    // Award XP for engaging (small) + bonus if correct.
    await api.awardXp({ xp: isCorrect ? 25 : 10, disciplineDelta: isCorrect ? 1 : 0 });
    // Fetch AI debrief.
    setLoadingAi(true);
    setShowAi(true);
    setAiContent("");
    try {
      const res = await fetch("/api/ai/scenario", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scenarioTitle: current.title,
          setup: current.setup,
          userChoiceLabel: choice.label,
          bestChoiceLabel: current.choices.find((c) => c.id === current.bestChoice)!.label,
          proReasoning: current.proReasoning,
        }),
      });
      if (res.ok) {
        const d = await res.json();
        setAiContent(d.content);
      }
    } catch {
      /* ignore */
    }
    setLoadingAi(false);
  };

  const next = () => {
    setPicked(null);
    setAiContent("");
    setShowAi(false);
    setStep((s) => s + 1);
  };

  React.useEffect(() => {
    if (step >= total && !finished) {
      setFinished(true);
    }
  }, [step, total, finished]);

  const restart = () => {
    setStep(0);
    setPicked(null);
    setCorrectCount(0);
    setFinished(false);
    setAiContent("");
    setShowAi(false);
  };

  if (done) {
    return (
      <div>
        <ModuleHeader title="Scenario Trainer" description="Train your decision-making against real market events." icon={<Zap className="size-5" />} />
        <Card className="mx-auto max-w-2xl p-8 text-center">
          <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
            <Zap className="size-8" />
          </div>
          <h2 className="mt-4 text-xl font-bold text-foreground">Training Complete</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            You matched the professional choice <span className="font-bold text-emerald-400">{correctCount}</span> out of {total} times.
          </p>
          <Button className="mt-5 bg-emerald-600 hover:bg-emerald-500 text-white" onClick={restart}>
            <RotateCcw className="size-4" /> Train Again
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <ModuleHeader
        title="Scenario Trainer"
        description="Face realistic market events and decide: Buy, Sell, or Wait. Then learn the professional reasoning."
        icon={<Zap className="size-5" />}
      />

      <div className="mx-auto max-w-3xl">
        <div className="mb-4 flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Scenario {step + 1} of {total}</span>
          <Progress value={(step / total) * 100} className="h-1.5 flex-1" />
          <Pill tone="up">{correctCount} correct</Pill>
        </div>

        <Card className="p-6">
          <div className="flex items-center gap-2">
            <Pill tone="sky"><Newspaper className="size-3" /> {current.category}</Pill>
          </div>
          <h2 className="mt-2 text-xl font-bold text-foreground">{current.title}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{current.blurb}</p>

          <div className="mt-4 rounded-lg border border-border/60 bg-muted/30 p-4">
            <p className="text-sm leading-relaxed text-foreground">{current.setup}</p>
          </div>

          <div className="mt-5">
            <p className="mb-3 text-sm font-medium text-foreground">What would you do?</p>
            <div className="grid grid-cols-3 gap-2">
              {current.choices.map((c) => {
                const isPicked = picked === c.id;
                const isBest = c.id === current.bestChoice;
                let cls = "flex flex-col items-center gap-1 rounded-lg border py-4 text-sm font-semibold transition-all ";
                if (!picked) {
                  cls += "border-border/60 hover:border-emerald-500/40 hover:bg-muted/40 cursor-pointer";
                } else if (isBest) {
                  cls += "border-emerald-500/50 bg-emerald-500/10 text-emerald-400";
                } else if (isPicked) {
                  cls += "border-rose-500/50 bg-rose-500/10 text-rose-400";
                } else {
                  cls += "border-border/40 opacity-50 text-muted-foreground";
                }
                return (
                  <button key={c.id} className={cls} onClick={() => choose(c.id)} disabled={!!picked}>
                    {tagIcon(c.tag)}
                    {c.tag}
                    {picked && isBest && <Check className="size-3" />}
                    {picked && isPicked && !isBest && <X className="size-3" />}
                  </button>
                );
              })}
            </div>
          </div>

          {picked && (
            <div className="mt-5 space-y-3">
              <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-4">
                <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-emerald-400">
                  <TrendingUp className="size-3.5" /> Professional Reasoning
                </div>
                <p className="text-sm leading-relaxed text-foreground">{current.proReasoning}</p>
              </div>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white" onClick={next}>
                {step < total - 1 ? "Next Scenario" : "Finish"} <ArrowRight className="size-4" />
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* AI debrief */}
      <Dialog open={showAi} onOpenChange={(o) => setShowAi(o)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> AI Debrief
            </DialogTitle>
            <DialogDescription>{current.title}</DialogDescription>
          </DialogHeader>
          {loadingAi ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="typing-dot text-emerald-400">●</span>
              <span className="typing-dot text-emerald-400">●</span>
              <span className="typing-dot text-emerald-400">●</span> Reasoning through your choice…
            </div>
          ) : (
            <Markdown>{aiContent || current.proReasoning}</Markdown>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
