"use client";

import * as React from "react";
import {
  Brain,
  HeartPulse,
  ArrowRight,
  Check,
  AlertTriangle,
  Bot,
  RotateCcw,
  Gauge,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { PSYCH_SCENARIOS, type PsychChoice } from "@/lib/content";
import { useTraderApi } from "@/lib/client-api";

export function PsychologyModule() {
  const trader = useStore((s) => s.trader);
  const { toast } = useToast();
  const api = useTraderApi();

  const [step, setStep] = React.useState(0);
  const [picks, setPicks] = React.useState<Record<string, string>>({});
  const [revealed, setRevealed] = React.useState<string | null>(null);
  const [report, setReport] = React.useState<{ open: boolean; content: string }>({ open: false, content: "" });
  const [loadingReport, setLoadingReport] = React.useState(false);
  const [finished, setFinished] = React.useState(false);

  const total = PSYCH_SCENARIOS.length;
  const current = PSYCH_SCENARIOS[step];
  const done = step >= total;

  const disciplineDeltas = () =>
    PSYCH_SCENARIOS.map((s) => {
      const pickId = picks[s.id];
      const choice = s.choices.find((c) => c.id === pickId);
      return { title: s.title, chosen: choice, discipline: choice?.discipline ?? 0, tag: choice?.tag ?? "neutral" };
    });

  const totalDelta = disciplineDeltas().reduce((a, b) => a + b.discipline, 0);

  const choose = (choice: PsychChoice) => {
    if (revealed) return;
    setPicks((p) => ({ ...p, [current.id]: choice.id }));
    setRevealed(choice.id);
  };

  const next = () => {
    setRevealed(null);
    const ns = step + 1;
    setStep(ns);
    if (ns >= total) {
      finish();
    }
  };

  const finish = async () => {
    setFinished(true);
    const choices = disciplineDeltas();
    // Update discipline score and award XP.
    await api.awardXp({ xp: 80, disciplineDelta: totalDelta });
    setLoadingReport(true);
    setReport({ open: true, content: "" });
    try {
      const res = await fetch("/api/ai/psychology", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          choices: choices.map((c) => ({
            title: c.title,
            chosenLabel: c.chosen?.label ?? "—",
            tag: c.tag,
            discipline: c.discipline,
          })),
          disciplineScore: trader ? Math.max(0, Math.min(100, trader.disciplineScore + totalDelta)) : 50,
        }),
      });
      if (res.ok) {
        const d = await res.json();
        setReport({ open: true, content: d.content });
      }
    } catch {
      /* ignore */
    }
    setLoadingReport(false);
    toast({ title: "Psychology session complete", description: `+80 XP · Discipline ${totalDelta >= 0 ? "+" : ""}${totalDelta}` });
  };

  const restart = () => {
    setStep(0);
    setPicks({});
    setRevealed(null);
    setFinished(false);
    setReport({ open: false, content: "" });
  };

  const disciplinedCount = disciplineDeltas().filter((c) => c.tag === "disciplined").length;

  return (
    <div>
      <ModuleHeader
        title="Psychology Simulator"
        description="Master your emotions. Face high-pressure scenarios and build the discipline that separates pros from gamblers."
        icon={<Brain className="size-5" />}
        actions={
          finished ? (
            <Button variant="outline" size="sm" onClick={restart}>
              <RotateCcw className="size-4" /> Restart
            </Button>
          ) : null
        }
      />

      {!done ? (
        <div className="mx-auto max-w-3xl">
          {/* Progress */}
          <div className="mb-4 flex items-center gap-3">
            <span className="text-xs text-muted-foreground">Scenario {step + 1} of {total}</span>
            <Progress value={(step / total) * 100} className="h-1.5 flex-1" />
            <Pill tone="amber"><Gauge className="size-3" /> {disciplinedCount} disciplined</Pill>
          </div>

          <Card className="p-6">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-rose-400">
              <HeartPulse className="size-3.5" /> {current.emotionalTrigger}
            </div>
            <h2 className="mt-2 text-xl font-bold text-foreground">{current.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{current.blurb}</p>

            <div className="mt-4 rounded-lg border border-border/60 bg-muted/30 p-4">
              <p className="text-sm leading-relaxed text-foreground">{current.situation}</p>
            </div>

            <div className="mt-5 space-y-2.5">
              <p className="text-sm font-medium text-foreground">What do you do?</p>
              {current.choices.map((c) => {
                const isPicked = revealed === c.id;
                let cls = "flex w-full items-center gap-3 rounded-lg border p-3.5 text-left text-sm transition-all ";
                if (!revealed) {
                  cls += "border-border/60 hover:border-emerald-500/40 hover:bg-muted/40 cursor-pointer";
                } else if (isPicked) {
                  if (c.tag === "disciplined") cls += "border-emerald-500/50 bg-emerald-500/10";
                  else if (c.tag === "impulsive") cls += "border-rose-500/50 bg-rose-500/10";
                  else cls += "border-amber-500/50 bg-amber-500/10";
                } else {
                  cls += "border-border/40 opacity-50";
                }
                return (
                  <button key={c.id} className={cls} onClick={() => choose(c)} disabled={!!revealed}>
                    <span className="flex-1 text-foreground">{c.label}</span>
                    {revealed && isPicked && (
                      <Pill tone={c.tag === "disciplined" ? "up" : c.tag === "impulsive" ? "down" : "amber"}>
                        {c.tag === "disciplined" ? <Check className="size-3" /> : <AlertTriangle className="size-3" />}
                        {c.tag}
                      </Pill>
                    )}
                  </button>
                );
              })}
            </div>

            {revealed && (
              <div className="mt-4 rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-4">
                <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-emerald-400">
                  <Brain className="size-3.5" /> Coach's Reflection
                </div>
                <p className="text-sm leading-relaxed text-foreground">{current.reflection}</p>
                {step < total - 1 ? (
                  <Button className="mt-3 bg-emerald-600 hover:bg-emerald-500 text-white" onClick={next}>
                    Next Scenario <ArrowRight className="size-4" />
                  </Button>
                ) : (
                  <Button className="mt-3 bg-emerald-600 hover:bg-emerald-500 text-white" onClick={next}>
                    See My Psychology Report <ArrowRight className="size-4" />
                  </Button>
                )}
              </div>
            )}
          </Card>
        </div>
      ) : (
        <Card className="mx-auto max-w-2xl p-8 text-center">
          <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
            <Brain className="size-8" />
          </div>
          <h2 className="mt-4 text-xl font-bold text-foreground">Session Complete</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            You made <span className="font-bold text-emerald-400">{disciplinedCount}</span> disciplined decisions out of {total}.
            Discipline score change: <span className={totalDelta >= 0 ? "text-emerald-400" : "text-rose-400"}>{totalDelta >= 0 ? "+" : ""}{totalDelta}</span>
          </p>
          <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button className="bg-emerald-600 hover:bg-emerald-500 text-white" onClick={() => setReport({ open: true, content: report.content })}>
              <Bot className="size-4" /> View Psychology Report
            </Button>
            <Button variant="outline" onClick={restart}>
              <RotateCcw className="size-4" /> Run Again
            </Button>
          </div>
        </Card>
      )}

      {/* AI report */}
      <Dialog open={report.open} onOpenChange={(o) => setReport((r) => ({ ...r, open: o }))}>
        <DialogContent className="max-h-[88vh] overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="size-5 text-emerald-400" /> Psychology Report
            </DialogTitle>
            <DialogDescription>AI-generated assessment of your trading mindset</DialogDescription>
          </DialogHeader>
          {loadingReport ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="typing-dot text-emerald-400">●</span>
              <span className="typing-dot text-emerald-400">●</span>
              <span className="typing-dot text-emerald-400">●</span> Analyzing your decisions…
            </div>
          ) : (
            <Markdown>{report.content}</Markdown>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
