"use client";

import * as React from "react";
import { Trophy, Crown, Medal, Flame, Users, Calendar, Target, TrendingUp } from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { rankForXp, RANKS } from "@/lib/ranks";
import { fmtINRCompact } from "@/lib/market";

const COMMUNITY = [
  { name: "Aarav Mehta", xp: 14200, trades: 312, winRate: 61 },
  { name: "Priya Sharma", xp: 11850, trades: 268, winRate: 58 },
  { name: "Rohan Verma", xp: 9640, trades: 224, winRate: 55 },
  { name: "Ananya Iyer", xp: 7800, trades: 198, winRate: 57 },
  { name: "Kabir Singh", xp: 6200, trades: 176, winRate: 52 },
  { name: "Diya Patel", xp: 4900, trades: 154, winRate: 54 },
  { name: "Vivaan Reddy", xp: 3800, trades: 132, winRate: 49 },
  { name: "Ishaan Gupta", xp: 2700, trades: 108, winRate: 47 },
  { name: "Saanvi Rao", xp: 1900, trades: 86, winRate: 51 },
  { name: "Arjun Nair", xp: 1200, trades: 64, winRate: 44 },
  { name: "Myra Kapoor", xp: 650, trades: 42, winRate: 48 },
  { name: "Reyansh Das", xp: 280, trades: 18, winRate: 40 },
];

const COMPETITIONS = [
  { title: "Weekly Breakout Challenge", desc: "Identify & trade 5 breakout setups. Top 3 win XP boosts.", prize: "+500 XP", participants: 1240, daysLeft: 3, status: "live" },
  { title: "Risk Management Cup", desc: "Survive 20 simulated trades without breaching 2% daily risk.", prize: "Pro Rank Unlock", participants: 856, daysLeft: 6, status: "live" },
  { title: "Psychology Gauntlet", desc: "Complete 10 emotional scenarios with 80%+ discipline.", prize: "+300 XP", participants: 612, daysLeft: 9, status: "soon" },
];

export function LeaderboardModule() {
  const trader = useStore((s) => s.trader);
  const setActiveView = useStore((s) => s.setActiveView);

  // Build leaderboard including the current trader.
  const board = React.useMemo(() => {
    const me = trader
      ? { name: trader.name || "You", xp: trader.xp, trades: trader.tradesDone, winRate: trader.tradesDone ? Math.round((trader.wins / trader.tradesDone) * 100) : 0, isYou: true }
      : { name: "You", xp: 0, trades: 0, winRate: 0, isYou: true };
    return [...COMMUNITY.map((c) => ({ ...c, isYou: false })), me].sort((a, b) => b.xp - a.xp);
  }, [trader]);

  const myRank = board.findIndex((b) => b.isYou) + 1;
  const top3 = board.slice(0, 3);

  return (
    <div>
      <ModuleHeader
        title="Community & Leaderboards"
        description="Compete, learn, and climb the ranks. Education-first — no signal selling."
        icon={<Trophy className="size-5" />}
      />

      {/* Your position */}
      {trader && (
        <Card className="mb-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex size-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
                <Trophy className="size-7" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-muted-foreground">Your Global Rank</div>
                <div className="text-2xl font-bold text-foreground">#{myRank} <span className="text-base font-normal text-muted-foreground">of {board.length}k+ traders</span></div>
                <div className="mt-0.5 text-sm text-emerald-400">{rankForXp(trader.xp).name} · {trader.xp.toLocaleString()} XP</div>
              </div>
            </div>
            <div className="flex gap-6 text-center">
              <div>
                <div className="text-xl font-bold text-foreground">{trader.tradesDone}</div>
                <div className="text-xs text-muted-foreground">Trades</div>
              </div>
              <div>
                <div className="text-xl font-bold text-foreground">{trader.tradesDone ? Math.round((trader.wins / trader.tradesDone) * 100) : 0}%</div>
                <div className="text-xs text-muted-foreground">Win Rate</div>
              </div>
              <div>
                <div className="text-xl font-bold text-amber-400">{trader.bestStreak}</div>
                <div className="text-xs text-muted-foreground">Best Streak</div>
              </div>
            </div>
          </div>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Leaderboard */}
        <Card className="lg:col-span-2 p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-foreground">
            <Users className="size-4 text-emerald-400" /> Global Leaderboard
          </h3>

          {/* Podium */}
          <div className="mb-5 grid grid-cols-3 gap-2">
            {[1, 0, 2].map((podiumIdx) => {
              const t = top3[podiumIdx];
              if (!t) return <div key={podiumIdx} />;
              const medal = podiumIdx === 0 ? <Crown className="size-5 text-amber-400" /> : podiumIdx === 1 ? <Medal className="size-5 text-slate-300" /> : <Medal className="size-5 text-amber-700" />;
              const h = podiumIdx === 0 ? "h-32" : "h-24";
              return (
                <div key={podiumIdx} className="flex flex-col items-center">
                  <div className={"flex w-full flex-col items-center justify-end rounded-xl border " + (t.isYou ? "border-emerald-500/50 bg-emerald-500/10" : "border-border/60 bg-muted/30") + " " + h + " pb-3 pt-2"}>
                    {medal}
                    <div className="mt-1 text-xs font-semibold text-foreground truncate max-w-full px-1">{t.isYou ? "You" : t.name.split(" ")[0]}</div>
                    <div className="text-[10px] text-emerald-400">{t.xp.toLocaleString()} XP</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full list */}
          <div className="max-h-96 space-y-1 overflow-y-auto scrollbar-thin">
            {board.map((t, i) => (
              <div
                key={i}
                className={
                  "flex items-center gap-3 rounded-lg px-3 py-2 " +
                  (t.isYou ? "bg-emerald-500/10 ring-1 ring-emerald-500/30" : i % 2 ? "bg-muted/20" : "")
                }
              >
                <span className={"w-7 text-center text-sm font-bold " + (i < 3 ? "text-amber-400" : "text-muted-foreground")}>
                  {i + 1}
                </span>
                <div
                  className="flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-bold text-background"
                  style={{ backgroundColor: rankForXp(t.xp).accent }}
                >
                  {rankForXp(t.xp).rank}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium text-foreground">{t.isYou ? "You" : t.name}</span>
                    {t.isYou && <Pill tone="up">You</Pill>}
                  </div>
                  <div className="text-xs text-muted-foreground">{rankForXp(t.xp).name}</div>
                </div>
                <div className="hidden text-right sm:block">
                  <div className="text-xs text-muted-foreground">{t.trades} trades</div>
                  <div className="text-xs text-muted-foreground">{t.winRate}% WR</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold tabular-nums text-foreground">{t.xp.toLocaleString()}</div>
                  <div className="text-[10px] text-muted-foreground">XP</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Competitions */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Calendar className="size-4 text-emerald-400" /> Live Competitions
            </h3>
            <div className="space-y-3">
              {COMPETITIONS.map((c) => (
                <div key={c.title} className="rounded-lg border border-border/60 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-sm font-semibold text-foreground">{c.title}</h4>
                    <Pill tone={c.status === "live" ? "up" : "amber"}>{c.status === "live" ? "LIVE" : "Soon"}</Pill>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{c.desc}</p>
                  <div className="mt-2 flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Users className="size-3" /> {c.participants.toLocaleString()}
                    </span>
                    <span className="font-semibold text-emerald-400">{c.prize}</span>
                    <span className="text-muted-foreground">{c.daysLeft}d left</span>
                  </div>
                  <Button size="sm" variant="outline" className="mt-2 w-full" onClick={() => setActiveView("rooms")}>
                    <Target className="size-3.5" /> {c.status === "live" ? "Join Challenge" : "Get Ready"}
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Flame className="size-4 text-amber-400" /> Rank Ladder
            </h3>
            <div className="space-y-1.5">
              {RANKS.map((r) => {
                const isMe = trader && rankForXp(trader.xp).rank === r.rank;
                const achieved = trader && trader.xp >= r.minXp;
                return (
                  <div
                    key={r.rank}
                    className={
                      "flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs " +
                      (isMe ? "bg-emerald-500/10 ring-1 ring-emerald-500/30" : "")
                    }
                  >
                    <span
                      className="flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-background"
                      style={{ backgroundColor: r.accent, opacity: achieved ? 1 : 0.35 }}
                    >
                      {r.rank}
                    </span>
                    <span className={"flex-1 " + (achieved ? "text-foreground" : "text-muted-foreground")}>{r.name}</span>
                    <span className="text-muted-foreground">{r.minXp.toLocaleString()} XP</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
