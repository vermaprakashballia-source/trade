"use client";

import * as React from "react";
import {
  Gauge,
  TrendingUp,
  TrendingDown,
  Bot,
  Loader2,
  Sparkles,
  Award,
  AlertTriangle,
  Target,
  Brain,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ModuleHeader, Pill, EmptyState } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { fmtINRCompact, fmtINR } from "@/lib/market";
import { computeMetrics } from "@/lib/trade-metrics";
import { rankForXp } from "@/lib/ranks";
import type { ViewKey } from "@/lib/types";

export function AnalyticsModule() {
  const trades = useStore((s) => s.trades);
  const trader = useStore((s) => s.trader);
  const setActiveView = useStore((s) => s.setActiveView);
  const [aiDeep, setAiDeep] = React.useState<string>("");
  const [loadingAi, setLoadingAi] = React.useState(false);
  const [requested, setRequested] = React.useState(false);

  const metrics = computeMetrics(trades);
  const closed = trades.filter((t) => t.status === "CLOSED" && t.rMultiple != null);

  const rData = closed.slice(-20).map((t, i) => ({
    name: `T${i + 1}`,
    r: Number((t.rMultiple ?? 0).toFixed(2)),
  }));

  const pieData = [
    { name: "Wins", value: metrics.wins, color: "#10b981" },
    { name: "Losses", value: metrics.losses, color: "#f43f5e" },
  ];

  // Heuristic strengths & weaknesses.
  const strengths: { label: string; detail: string }[] = [];
  const weaknesses: { label: string; detail: string }[] = [];
  let style = "Developing";

  if (metrics.closed >= 3) {
    if (metrics.winRate >= 50)
      strengths.push({ label: "Pattern Recognition", detail: `${metrics.winRate.toFixed(0)}% win rate — your entries are finding edges.` });
    else
      weaknesses.push({ label: "Entry Timing", detail: `${metrics.winRate.toFixed(0)}% win rate suggests entries need refinement.` });

    if (metrics.avgR >= 1.2)
      strengths.push({ label: "Letting Winners Run", detail: `Avg ${metrics.avgR.toFixed(2)}R — you're not cutting winners too early.` });
    else
      weaknesses.push({ label: "Trade Management", detail: `Avg ${metrics.avgR.toFixed(2)}R — review whether you cut winners or hold losers.` });

    if (isFinite(metrics.profitFactor) && metrics.profitFactor >= 1.5)
      strengths.push({ label: "Positive Edge", detail: `Profit factor ${metrics.profitFactor.toFixed(2)} — your system has a real edge.` });
    else if (isFinite(metrics.profitFactor) && metrics.profitFactor < 1)
      weaknesses.push({ label: "Negative Edge", detail: `Profit factor ${metrics.profitFactor.toFixed(2)} — your system currently loses money. Refine before scaling.` });

    const ddPct = trader ? (metrics.maxDrawdown / trader.startingCapital) * 100 : 0;
    if (ddPct < 5)
      strengths.push({ label: "Risk Control", detail: `Max drawdown ${fmtINRCompact(metrics.maxDrawdown)} (${ddPct.toFixed(1)}%) — disciplined sizing.` });
    else
      weaknesses.push({ label: "Risk Control", detail: `Max drawdown ${fmtINRCompact(metrics.maxDrawdown)} (${ddPct.toFixed(1)}%) — tighten your 1% rule.` });

    if (trader && trader.disciplineScore >= 65)
      strengths.push({ label: "Emotional Control", detail: `Discipline score ${Math.round(trader.disciplineScore)}/100 — strong mindset.` });
    else if (trader && trader.disciplineScore < 45)
      weaknesses.push({ label: "Emotional Control", detail: `Discipline score ${Math.round(trader.disciplineScore)}/100 — psychology work needed.` });

    // Trading style inference.
    if (metrics.avgWin > Math.abs(metrics.avgLoss) * 1.5 && metrics.winRate < 55) style = "Trend Follower";
    else if (metrics.winRate >= 55 && metrics.avgR < 1.2) style = "Scalper / High-Frequency";
    else if (metrics.avgR >= 1.5) style = "Swing Trader";
  }

  const getAiDeep = async () => {
    setLoadingAi(true);
    setRequested(true);
    setAiDeep("");
    const ctx = trader
      ? `Metrics — Trades: ${metrics.total} (${metrics.closed} closed), Wins: ${metrics.wins}, Losses: ${metrics.losses}, Win rate: ${metrics.winRate.toFixed(1)}%, Profit factor: ${isFinite(metrics.profitFactor) ? metrics.profitFactor.toFixed(2) : "∞"}, Avg R: ${metrics.avgR.toFixed(2)}, Avg win: ${fmtINR(metrics.avgWin)}, Avg loss: ${fmtINR(Math.abs(metrics.avgLoss))}, Net P&L: ${fmtINR(metrics.netPnl)}, Max drawdown: ${fmtINR(metrics.maxDrawdown)}, Best streak: ${trader.bestStreak}, Discipline: ${Math.round(trader.disciplineScore)}/100, Rank: ${rankForXp(trader.xp).name}.`
      : "";
    try {
      const res = await fetch("/api/ai/mentor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message:
            "Act as my performance analyst. Based on my metrics, identify my dominant trading style, my #1 strength to keep exploiting, my #1 weakness to fix first, and give me a specific 3-step improvement plan for the next 2 weeks. Be concrete and numeric.",
          traderContext: ctx,
        }),
      });
      const data = await res.json();
      setAiDeep(data.content);
    } catch {
      setAiDeep("Analysis unavailable right now. Focus on your lowest-scoring area first and journal every trade.");
    } finally {
      setLoadingAi(false);
    }
  };

  if (metrics.closed === 0) {
    return (
      <div>
        <ModuleHeader title="Performance Analytics" description="Data-driven insights into your trading edge." icon={<Gauge className="size-5" />} />
        <EmptyState
          icon={<Gauge className="size-5" />}
          title="Not enough data yet"
          description="Close at least a few trades to unlock analytics, strengths/weaknesses, and AI recommendations."
          action={<Button onClick={() => setActiveView("simulation" as ViewKey)} className="bg-emerald-600 hover:bg-emerald-500 text-white">Open Simulator</Button>}
        />
      </div>
    );
  }

  return (
    <div>
      <ModuleHeader
        title="Performance Analytics"
        description="AI-analyzed strengths, weaknesses, and a personalized improvement plan based on your real trades."
        icon={<Gauge className="size-5" />}
        actions={
          <Button onClick={getAiDeep} disabled={loadingAi} className="bg-emerald-600 hover:bg-emerald-500 text-white">
            {loadingAi ? <><Loader2 className="size-4 animate-spin" /> Analyzing…</> : <><Bot className="size-4" /> AI Deep-Dive</>}
          </Button>
        }
      />

      {/* Style + discipline */}
      <div className="mb-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Target className="size-3.5" /> Trading Style
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-400">{style}</div>
          <div className="mt-1 text-xs text-muted-foreground">Inferred from your stats</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Brain className="size-3.5" /> Discipline
          </div>
          <div className="mt-2 text-2xl font-bold text-foreground">{Math.round(trader?.disciplineScore ?? 0)}<span className="text-base text-muted-foreground">/100</span></div>
          <Progress value={trader?.disciplineScore ?? 0} className="mt-2 h-1.5" />
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <TrendingUp className="size-3.5" /> Expectancy
          </div>
          <div className={"mt-2 text-2xl font-bold " + (metrics.expectancy >= 0 ? "text-emerald-400" : "text-rose-400")}>
            {metrics.expectancy >= 0 ? "+" : ""}{fmtINRCompact(metrics.expectancy)}
          </div>
          <div className="mt-1 text-xs text-muted-foreground">Avg per trade</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Award className="size-3.5" /> Best Streak
          </div>
          <div className="mt-2 text-2xl font-bold text-amber-400">{trader?.bestStreak ?? 0} 🔥</div>
          <div className="mt-1 text-xs text-muted-foreground">Consecutive wins</div>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Strengths */}
        <Card className="p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
            <TrendingUp className="size-4 text-emerald-400" /> Strengths
          </h3>
          {strengths.length === 0 ? (
            <p className="text-sm text-muted-foreground">Keep trading — strengths will surface as data builds.</p>
          ) : (
            <div className="space-y-2">
              {strengths.map((s, i) => (
                <div key={i} className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
                  <div className="flex items-center gap-2">
                    <Award className="size-4 text-emerald-400" />
                    <span className="font-medium text-foreground">{s.label}</span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{s.detail}</p>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Weaknesses */}
        <Card className="p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
            <AlertTriangle className="size-4 text-rose-400" /> Weaknesses
          </h3>
          {weaknesses.length === 0 ? (
            <p className="text-sm text-muted-foreground">No glaring weaknesses detected — keep refining.</p>
          ) : (
            <div className="space-y-2">
              {weaknesses.map((w, i) => (
                <div key={i} className="rounded-lg border border-rose-500/20 bg-rose-500/5 p-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="size-4 text-rose-400" />
                    <span className="font-medium text-foreground">{w.label}</span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{w.detail}</p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Charts */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 p-5">
          <h3 className="mb-3 text-sm font-semibold text-foreground">R-Multiple per Trade (last 20)</h3>
          {rData.length ? (
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={rData} margin={{ top: 5, right: 8, left: 0, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={32} />
                  <Tooltip
                    contentStyle={{ background: "oklch(0.21 0.013 250)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 8, fontSize: 12 }}
                    cursor={{ fill: "oklch(1 0 0 / 4%)" }}
                  />
                  <Bar dataKey="r" radius={[3, 3, 0, 0]}>
                    {rData.map((d, i) => (
                      <Cell key={i} fill={d.r >= 0 ? "#10b981" : "#f43f5e"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="py-10 text-center text-sm text-muted-foreground">No R-multiple data yet.</p>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="mb-3 text-sm font-semibold text-foreground">Win / Loss Split</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={48} outerRadius={72} paddingAngle={2}>
                  {pieData.map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: "oklch(0.21 0.013 250)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 8, fontSize: 12 }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 text-xs">
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-emerald-500" /> Wins {metrics.wins}</span>
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-rose-500" /> Losses {metrics.losses}</span>
          </div>
        </Card>
      </div>

      {/* AI deep dive */}
      {(requested || aiDeep) && (
        <Card className="mt-4 p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
            <Sparkles className="size-4 text-emerald-400" /> AI Deep-Dive
          </h3>
          {loadingAi ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin text-emerald-400" /> Crunching your numbers…
            </div>
          ) : (
            <Markdown>{aiDeep}</Markdown>
          )}
        </Card>
      )}
    </div>
  );
}
