"use client";

import * as React from "react";
import {
  ScanEye,
  Upload,
  Image as ImageIcon,
  Bot,
  Loader2,
  Sparkles,
  RefreshCw,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ModuleHeader, Pill } from "@/components/ui-bits";
import { Markdown } from "@/components/markdown";
import { SYMBOLS, generateSeries, type Candle } from "@/lib/market";

// Render a sample candlestick chart to a PNG data URL.
function renderSampleChart(candles: Candle[], w = 820, h = 460): string {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#0b0f14";
  ctx.fillRect(0, 0, w, h);

  const padL = 12;
  const padR = 70;
  const padT = 16;
  const padB = 26;
  const cw = w - padL - padR;
  const ch = h - padT - padB;

  let min = Infinity;
  let max = -Infinity;
  for (const c of candles) {
    if (c.low < min) min = c.low;
    if (c.high > max) max = c.high;
  }
  const pad = (max - min) * 0.06;
  min -= pad;
  max += pad;
  const range = max - min || 1;

  const slot = cw / candles.length;
  const bodyW = Math.max(1.5, Math.min(12, slot * 0.7));
  const yFor = (p: number) => padT + (1 - (p - min) / range) * ch;

  // grid
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px ui-monospace, monospace";
  ctx.textBaseline = "middle";
  for (let i = 0; i <= 4; i++) {
    const y = padT + (i / 4) * ch;
    const p = max - (i / 4) * range;
    ctx.beginPath();
    ctx.moveTo(padL, y);
    ctx.lineTo(padL + cw, y);
    ctx.stroke();
    ctx.textAlign = "left";
    ctx.fillText(p.toFixed(2), padL + cw + 6, y);
  }

  // candles
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const x = padL + i * slot + slot / 2;
    const up = c.close >= c.open;
    const color = up ? "#22c55e" : "#f43f5e";
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(Math.round(x) + 0.5, yFor(c.high));
    ctx.lineTo(Math.round(x) + 0.5, yFor(c.low));
    ctx.stroke();
    ctx.fillStyle = color;
    const yO = yFor(c.open);
    const yC = yFor(c.close);
    ctx.fillRect(Math.round(x - bodyW / 2), Math.min(yO, yC), bodyW, Math.max(1, Math.abs(yC - yO)));
  }
  return canvas.toDataURL("image/png");
}

export function ChartAiModule() {
  const [image, setImage] = React.useState<string | null>(null);
  const [symbol, setSymbol] = React.useState("");
  const [analysis, setAnalysis] = React.useState<string>("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string>("");
  const fileRef = React.useRef<HTMLInputElement>(null);

  const onFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (PNG, JPG, WebP).");
      return;
    }
    setError("");
    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result as string);
      setAnalysis("");
    };
    reader.readAsDataURL(file);
  };

  const generateSample = (symIdx: number) => {
    const s = SYMBOLS[symIdx];
    const candles = generateSeries(s.seed, 70, s.startPrice);
    setImage(renderSampleChart(candles));
    setSymbol(s.symbol);
    setAnalysis("");
    setError("");
  };

  const analyze = async () => {
    if (!image) return;
    setLoading(true);
    setAnalysis("");
    setError("");
    try {
      const res = await fetch("/api/ai/chart-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image, symbol: symbol || undefined }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setAnalysis(data.content);
      }
    } catch {
      setError("Failed to analyze the chart. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <ModuleHeader
        title="AI Chart Analysis"
        description="Upload any price chart and get an instant professional breakdown — trend, levels, entry, stop, target, and R:R."
        icon={<ScanEye className="size-5" />}
      />

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Upload / input */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-foreground">1. Provide a chart</h3>

            {/* Drop zone */}
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files?.[0];
                if (f) onFile(f);
              }}
              onClick={() => fileRef.current?.click()}
              className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-border/70 p-8 text-center transition-colors hover:border-emerald-500/40 hover:bg-muted/30"
            >
              <Upload className="mb-2 size-8 text-muted-foreground" />
              <p className="text-sm font-medium text-foreground">Drop a chart image or click to upload</p>
              <p className="mt-0.5 text-xs text-muted-foreground">PNG, JPG, WebP — TradingView screenshots work great</p>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onFile(f);
                }}
              />
            </div>

            {/* Sample charts */}
            <div className="mt-4">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <Sparkles className="size-3.5 text-emerald-400" /> Or use a generated sample
              </div>
              <div className="flex flex-wrap gap-2">
                {SYMBOLS.map((s, i) => (
                  <button
                    key={s.symbol}
                    onClick={() => generateSample(i)}
                    className="rounded-lg border border-border/60 px-2.5 py-1.5 text-xs font-medium text-muted-foreground hover:border-emerald-500/40 hover:text-emerald-400"
                  >
                    {s.symbol}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <Label className="text-xs text-muted-foreground">Symbol (optional)</Label>
              <Input
                placeholder="e.g. RELIANCE"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                className="mt-1"
              />
            </div>

            <Button
              className="mt-4 w-full bg-emerald-600 hover:bg-emerald-500 text-white"
              disabled={!image || loading}
              onClick={analyze}
            >
              {loading ? <><Loader2 className="size-4 animate-spin" /> Analyzing…</> : <><Bot className="size-4" /> Analyze Chart</>}
            </Button>
            {error && <p className="mt-2 text-sm text-rose-400">{error}</p>}
          </Card>

          {/* Preview */}
          {image && (
            <Card className="p-5">
              <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
                <ImageIcon className="size-4 text-emerald-400" /> Chart Preview
              </h3>
              <img src={image} alt="Chart to analyze" className="w-full rounded-lg border border-border/60" />
            </Card>
          )}
        </div>

        {/* Analysis */}
        <Card className="p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
            <Bot className="size-4 text-emerald-400" /> AI Analysis
          </h3>
          {!analysis && !loading && (
            <div className="flex h-64 flex-col items-center justify-center text-center text-sm text-muted-foreground">
              <ScanEye className="mb-2 size-10 text-muted-foreground/40" />
              {image ? "Click “Analyze Chart” to get a full breakdown." : "Upload or generate a chart to begin."}
            </div>
          )}
          {loading && (
            <div className="flex h-64 flex-col items-center justify-center text-center">
              <Loader2 className="mb-2 size-8 animate-spin text-emerald-400" />
              <p className="text-sm text-muted-foreground">Reading the chart…</p>
              <div className="mt-2 flex gap-1">
                <span className="typing-dot text-emerald-400">●</span>
                <span className="typing-dot text-emerald-400">●</span>
                <span className="typing-dot text-emerald-400">●</span>
              </div>
            </div>
          )}
          {analysis && (
            <div className="scrollbar-thin max-h-[70vh] overflow-y-auto">
              <Markdown>{analysis}</Markdown>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
