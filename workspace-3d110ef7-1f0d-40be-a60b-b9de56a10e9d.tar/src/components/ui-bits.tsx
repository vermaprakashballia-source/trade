"use client";

import * as React from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { rankForXp, rankProgress, nextRank } from "@/lib/ranks";
import type { Trader } from "@/lib/types";

export function ModuleHeader({
  title,
  description,
  icon,
  actions,
}: {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <div className="flex items-center gap-2.5">
          {icon && (
            <div className="flex size-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20">
              {icon}
            </div>
          )}
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            {title}
          </h1>
        </div>
        {description && (
          <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

export function StatCard({
  label,
  value,
  sub,
  icon,
  tone = "default",
}: {
  label: string;
  value: React.ReactNode;
  sub?: React.ReactNode;
  icon?: React.ReactNode;
  tone?: "default" | "up" | "down" | "emerald" | "amber";
}) {
  const toneClass = {
    default: "text-foreground",
    up: "text-emerald-400",
    down: "text-rose-400",
    emerald: "text-emerald-400",
    amber: "text-amber-400",
  }[tone];
  return (
    <Card className="gap-0 p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        {icon && <span className="text-muted-foreground">{icon}</span>}
      </div>
      <div className={cn("mt-2 text-2xl font-bold tabular-nums", toneClass)}>
        {value}
      </div>
      {sub && <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>}
    </Card>
  );
}

export function RankBadge({ trader, compact }: { trader: Trader; compact?: boolean }) {
  const rank = rankForXp(trader.xp);
  const prog = rankProgress(trader.xp);
  const nxt = nextRank(trader.xp);
  return (
    <div className={cn("flex items-center gap-3", compact && "gap-2")}>
      <div
        className={cn(
          "flex shrink-0 items-center justify-center rounded-full font-bold text-background ring-2",
          compact ? "size-8 text-xs" : "size-10 text-sm"
        )}
        style={{ backgroundColor: rank.accent, boxShadow: `0 0 16px ${rank.accent}55` }}
      >
        {rank.rank}
      </div>
      <div className="min-w-0">
        <div className={cn("font-semibold text-foreground truncate", compact && "text-sm")}>
          {rank.name}
        </div>
        {!compact && nxt && (
          <div className="mt-1 w-40 max-w-full">
            <div className="h-1.5 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all"
                style={{ width: `${Math.round(prog.pct * 100)}%` }}
              />
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">
              {trader.xp.toLocaleString()} / {nxt.minXp.toLocaleString()} XP → {nxt.name}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function Pill({
  children,
  tone = "default",
  className,
}: {
  children: React.ReactNode;
  tone?: "default" | "up" | "down" | "emerald" | "amber" | "sky";
  className?: string;
}) {
  const tones = {
    default: "bg-muted text-muted-foreground",
    up: "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/20",
    down: "bg-rose-500/15 text-rose-400 ring-1 ring-rose-500/20",
    emerald: "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/20",
    amber: "bg-amber-500/15 text-amber-400 ring-1 ring-amber-500/20",
    sky: "bg-sky-500/15 text-sky-400 ring-1 ring-sky-500/20",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border/70 p-10 text-center">
      {icon && (
        <div className="mb-3 flex size-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
          {icon}
        </div>
      )}
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
      {description && (
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function SectionTitle({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h2 className={cn("text-sm font-semibold uppercase tracking-wide text-muted-foreground", className)}>
      {children}
    </h2>
  );
}
