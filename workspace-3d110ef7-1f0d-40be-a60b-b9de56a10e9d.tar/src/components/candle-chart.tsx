'use client';

// Self-contained canvas candlestick chart for TradeHackMe AI.
// Pure React + Canvas 2D. No external charting libraries.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Candle } from '@/lib/market';
import { fmtPrice } from '@/lib/market';

export interface ChartMark {
  index: number; // candle index to mark with a vertical highlight
  type?: 'support' | 'resistance' | 'entry' | 'sl' | 'tp' | 'note';
  label?: string;
}

export interface PriceLine {
  price: number;
  type: 'support' | 'resistance' | 'entry' | 'sl' | 'tp' | 'target';
  label?: string;
}

export interface CandleChartProps {
  data: Candle[]; // full series
  visibleCount?: number; // render only first N candles (for replay). default = all
  height?: number; // default 380
  showVolume?: boolean; // default true
  interactive?: boolean; // default true -> crosshair + onCandleClick
  onCandleClick?: (index: number) => void;
  marks?: ChartMark[]; // vertical highlights at candle index
  lines?: PriceLine[]; // horizontal price lines
  className?: string;
  symbol?: string; // shown top-left
  accent?: 'emerald' | 'rose' | 'amber'; // up-candle theme. default emerald
}

// ---------------------------------------------------------------------------
// Palette — dark trading-desk look. Up = accent, Down = rose (contrast).
// ---------------------------------------------------------------------------
interface Palette {
  bg: string;
  grid: string;
  axisText: string;
  legendText: string;
  up: string;
  down: string;
  upWick: string;
  downWick: string;
  upVol: string;
  downVol: string;
}

function buildPalette(accent: 'emerald' | 'rose' | 'amber'): Palette {
  const base: Palette = {
    bg: '#0b0f14',
    grid: 'rgba(255,255,255,0.05)',
    axisText: '#94a3b8',
    legendText: '#e2e8f0',
    up: '#22c55e',
    down: '#f43f5e',
    upWick: 'rgba(34,197,94,0.9)',
    downWick: 'rgba(244,63,94,0.9)',
    upVol: 'rgba(34,197,94,0.32)',
    downVol: 'rgba(244,63,94,0.32)',
  };
  if (accent === 'rose') {
    // Bearish accent: up=rose, down=emerald (clear contrast).
    base.up = '#fb7185';
    base.down = '#22c55e';
    base.upWick = 'rgba(251,113,133,0.9)';
    base.downWick = 'rgba(34,197,94,0.9)';
    base.upVol = 'rgba(251,113,133,0.32)';
    base.downVol = 'rgba(34,197,94,0.32)';
  } else if (accent === 'amber') {
    base.up = '#f59e0b';
    base.upWick = 'rgba(245,158,11,0.9)';
    base.upVol = 'rgba(245,158,11,0.32)';
  }
  return base;
}

const MARK_COLORS: Record<NonNullable<ChartMark['type']>, string> = {
  support: 'rgba(34,197,94,0.14)',
  resistance: 'rgba(244,63,94,0.14)',
  entry: 'rgba(56,189,248,0.14)',
  sl: 'rgba(244,63,94,0.16)',
  tp: 'rgba(34,197,94,0.14)',
  note: 'rgba(245,158,11,0.14)',
};

const MARK_BORDER: Record<NonNullable<ChartMark['type']>, string> = {
  support: '#22c55e',
  resistance: '#f43f5e',
  entry: '#38bdf8',
  sl: '#f43f5e',
  tp: '#22c55e',
  note: '#f59e0b',
};

const LINE_COLORS: Record<PriceLine['type'], string> = {
  support: '#22c55e',
  resistance: '#f43f5e',
  entry: '#38bdf8',
  sl: '#f43f5e',
  tp: '#22c55e',
  target: '#22c55e',
};

// ---------------------------------------------------------------------------
// Layout constants.
// ---------------------------------------------------------------------------
const PAD_L = 8;
const PAD_R = 72; // price axis labels
const PAD_T = 36; // legend + mark tags
const PAD_B = 22; // time axis labels

// ---------------------------------------------------------------------------
// Helper: rounded rectangle path.
// ---------------------------------------------------------------------------
function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

// Helper: format a candle timestamp. Intraday => "MMM DD HH:mm", else "MMM DD".
function formatTime(ms: number, intraday: boolean): string {
  const d = new Date(ms);
  const month = d.toLocaleString('en-US', { month: 'short' });
  const day = d.getDate();
  if (intraday) {
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return `${month} ${day} ${hh}:${mm}`;
  }
  return `${month} ${day}`;
}

// ---------------------------------------------------------------------------
// Component.
// ---------------------------------------------------------------------------
export default function CandleChart(props: CandleChartProps) {
  const {
    data,
    visibleCount,
    height = 380,
    showVolume = true,
    interactive = true,
    onCandleClick,
    marks = [],
    lines = [],
    className,
    symbol,
    accent = 'emerald',
  } = props;

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [width, setWidth] = useState(0);
  const [hover, setHover] = useState<{ x: number; y: number; idx: number } | null>(
    null
  );

  // Visible slice (memoized so redraw deps are stable).
  const view = useMemo(
    () => data.slice(0, visibleCount ?? data.length),
    [data, visibleCount]
  );

  // Observe container width for responsiveness.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width ?? 0;
      setWidth(w);
    });
    ro.observe(el);
    // Initial measurement in case observer is late.
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  // The single redraw routine. Called whenever inputs change.
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = width;
    const h = height;
    if (w <= 0 || h <= 0) return;

    // Crisp canvas: internal resolution = CSS size * dpr.
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const palette = buildPalette(accent);

    // Background.
    ctx.fillStyle = palette.bg;
    ctx.fillRect(0, 0, w, h);

    const chartW = Math.max(10, w - PAD_L - PAD_R);
    const chartH = Math.max(10, h - PAD_T - PAD_B);

    // Volume panel occupies bottom ~18% of the chart area.
    const volH = showVolume ? Math.round(chartH * 0.18) : 0;
    const gap = showVolume ? 6 : 0;
    const volTop = PAD_T + chartH - volH;
    const priceH = chartH - volH - gap;
    const priceTop = PAD_T;
    const priceBottom = priceTop + priceH;

    // Empty data short-circuit.
    if (!view.length) {
      ctx.fillStyle = palette.axisText;
      ctx.font = '13px ui-sans-serif, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('No data', w / 2, h / 2);
      return;
    }

    // ----- Price range (include horizontal lines so they remain visible). ---
    let minP = Infinity;
    let maxP = -Infinity;
    for (const c of view) {
      if (c.low < minP) minP = c.low;
      if (c.high > maxP) maxP = c.high;
    }
    for (const ln of lines) {
      if (ln.price < minP) minP = ln.price;
      if (ln.price > maxP) maxP = ln.price;
    }
    if (!isFinite(minP) || !isFinite(maxP)) {
      minP = 0;
      maxP = 1;
    }
    if (minP === maxP) {
      minP -= 1;
      maxP += 1;
    }
    const pad = (maxP - minP) * 0.08;
    minP -= pad;
    maxP += pad;
    const rangeP = maxP - minP;

    // ----- Volume max. -----------------------------------------------------
    let maxVol = 0;
    for (const c of view) if (c.volume > maxVol) maxVol = c.volume;
    if (maxVol === 0) maxVol = 1;

    // ----- Geometry helpers. ----------------------------------------------
    const slotW = chartW / view.length;
    const bodyW = Math.max(1, Math.min(14, slotW * 0.7));
    const xFor = (i: number) => PAD_L + i * slotW + slotW / 2;
    const yFor = (p: number) => priceTop + (1 - (p - minP) / rangeP) * priceH;

    // Detect intraday vs daily for time labels.
    const intervalMs = view.length > 1 ? view[1].time - view[0].time : 0;
    const intraday = intervalMs > 0 && intervalMs < 86_400_000;

    // ----- Horizontal grid + price axis labels (right). --------------------
    ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.textBaseline = 'middle';
    const gridN = 5;
    for (let i = 0; i <= gridN; i++) {
      const t = i / gridN;
      const y = priceTop + t * priceH;
      const p = maxP - t * rangeP;
      ctx.strokeStyle = palette.grid;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(PAD_L, y);
      ctx.lineTo(PAD_L + chartW, y);
      ctx.stroke();
      ctx.fillStyle = palette.axisText;
      ctx.textAlign = 'left';
      ctx.fillText(fmtPrice(p), PAD_L + chartW + 6, y);
    }

    // ----- Vertical grid + time axis labels (bottom). ----------------------
    const labelN = Math.min(6, view.length);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    for (let i = 0; i < labelN; i++) {
      const idx =
        labelN === 1
          ? 0
          : Math.floor((i / (labelN - 1)) * (view.length - 1));
      const c = view[idx];
      if (!c) continue;
      const x = xFor(idx);
      ctx.strokeStyle = palette.grid;
      ctx.beginPath();
      ctx.moveTo(x, PAD_T);
      ctx.lineTo(x, PAD_T + chartH);
      ctx.stroke();
      ctx.fillStyle = palette.axisText;
      ctx.fillText(formatTime(c.time, intraday), x, PAD_T + chartH + 6);
    }

    // ----- Marks (translucent vertical bands) — under candles. -------------
    for (const m of marks) {
      if (m.index < 0 || m.index >= view.length) continue;
      const x = xFor(m.index);
      const type = m.type ?? 'note';
      ctx.fillStyle = MARK_COLORS[type] ?? MARK_COLORS.note;
      ctx.fillRect(x - slotW / 2, PAD_T, slotW, chartH);
      // Tag above chart.
      if (m.label) {
        ctx.font = '10px ui-sans-serif, system-ui, sans-serif';
        const tw = ctx.measureText(m.label).width + 8;
        const tx = Math.max(
          PAD_L,
          Math.min(PAD_L + chartW - tw, x - tw / 2)
        );
        ctx.fillStyle = MARK_BORDER[type] ?? MARK_BORDER.note;
        roundRect(ctx, tx, PAD_T - 14, tw, 13, 3);
        ctx.fill();
        ctx.fillStyle = '#0b0f14';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(m.label, tx + tw / 2, PAD_T - 7.5);
      }
    }

    // ----- Volume bars. ----------------------------------------------------
    if (showVolume) {
      for (let i = 0; i < view.length; i++) {
        const c = view[i];
        const x = xFor(i);
        const vh = (c.volume / maxVol) * (volH - 2);
        const up = c.close >= c.open;
        ctx.fillStyle = up ? palette.upVol : palette.downVol;
        ctx.fillRect(x - bodyW / 2, volTop + (volH - vh), bodyW, vh);
      }
    }

    // ----- Candles. --------------------------------------------------------
    for (let i = 0; i < view.length; i++) {
      const c = view[i];
      const x = xFor(i);
      const up = c.close >= c.open;
      const wickColor = up ? palette.upWick : palette.downWick;
      const bodyColor = up ? palette.up : palette.down;

      const yOpen = yFor(c.open);
      const yClose = yFor(c.close);
      const yHigh = yFor(c.high);
      const yLow = yFor(c.low);

      // Wick (thin vertical line high -> low).
      ctx.strokeStyle = wickColor;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, yHigh);
      ctx.lineTo(Math.round(x) + 0.5, yLow);
      ctx.stroke();

      // Body.
      const bodyTop = Math.min(yOpen, yClose);
      const bodyH = Math.max(1, Math.abs(yClose - yOpen));
      ctx.fillStyle = bodyColor;
      ctx.fillRect(Math.round(x - bodyW / 2), bodyTop, bodyW, bodyH);
    }

    // ----- Horizontal price lines (with right-edge pill labels). -----------
    for (const ln of lines) {
      const y = yFor(ln.price);
      if (y < priceTop - 2 || y > priceBottom + 2) continue;
      const color = LINE_COLORS[ln.type] ?? '#94a3b8';
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.moveTo(PAD_L, y);
      ctx.lineTo(PAD_L + chartW, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;

      if (ln.label) {
        ctx.font = '10px ui-sans-serif, system-ui, sans-serif';
        const tw = ctx.measureText(ln.label).width + 8;
        const lx = PAD_L + chartW - tw - 2;
        const ly = y - 7;
        ctx.fillStyle = color;
        roundRect(ctx, lx, ly, tw, 13, 3);
        ctx.fill();
        ctx.fillStyle = '#0b0f14';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(ln.label, lx + tw / 2, ly + 6.5);
      }
    }

    // ----- OHLC legend (top-left) — hovered candle, else last. -------------
    const legendIdx = hover ? hover.idx : view.length - 1;
    const lc = view[legendIdx];
    if (lc) {
      const chg = lc.close - lc.open;
      const chgPct = lc.open !== 0 ? (chg / lc.open) * 100 : 0;
      const up = chg >= 0;

      // Symbol (bold).
      ctx.font = 'bold 12px ui-sans-serif, system-ui, sans-serif';
      ctx.fillStyle = palette.legendText;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      const symText = symbol ? symbol + '   ' : '';
      ctx.fillText(symText, PAD_L + 4, 6);
      const symW = ctx.measureText(symText).width;

      // OHLC (mono).
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.fillStyle = palette.axisText;
      const ohlcText = `O ${fmtPrice(lc.open)}   H ${fmtPrice(lc.high)}   L ${fmtPrice(
        lc.low
      )}   C ${fmtPrice(lc.close)}`;
      ctx.fillText(ohlcText, PAD_L + 4 + symW, 7);
      const ohlcW = ctx.measureText(ohlcText).width;

      // Change %.
      const chgStr = `   ${up ? '+' : ''}${fmtPrice(chg)} (${up ? '+' : ''}${chgPct.toFixed(
        2
      )}%)`;
      ctx.fillStyle = up ? palette.up : palette.down;
      ctx.fillText(chgStr, PAD_L + 4 + symW + ohlcW, 7);
    }

    // ----- Crosshair (interactive only). ----------------------------------
    if (interactive && hover) {
      const { x, y } = hover;
      ctx.strokeStyle = 'rgba(226,232,240,0.45)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      // Vertical.
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, PAD_T);
      ctx.lineTo(Math.round(x) + 0.5, PAD_T + chartH);
      ctx.stroke();
      // Horizontal.
      ctx.beginPath();
      ctx.moveTo(PAD_L, Math.round(y) + 0.5);
      ctx.lineTo(PAD_L + chartW, Math.round(y) + 0.5);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price label on right axis.
      const p = maxP - ((y - priceTop) / priceH) * rangeP;
      if (p >= minP && p <= maxP) {
        const ps = fmtPrice(p);
        ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
        const tw = ctx.measureText(ps).width + 8;
        ctx.fillStyle = '#1e293b';
        roundRect(ctx, PAD_L + chartW + 2, y - 8, tw, 16, 3);
        ctx.fill();
        ctx.strokeStyle = '#475569';
        ctx.stroke();
        ctx.fillStyle = '#e2e8f0';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(ps, PAD_L + chartW + 2 + tw / 2, y);
      }

      // Time label on bottom axis.
      const tIdx = hover.idx;
      if (tIdx >= 0 && tIdx < view.length) {
        const ts = formatTime(view[tIdx].time, intraday);
        ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
        const tw = ctx.measureText(ts).width + 8;
        const lx = Math.max(
          PAD_L,
          Math.min(PAD_L + chartW - tw, x - tw / 2)
        );
        ctx.fillStyle = '#1e293b';
        roundRect(ctx, lx, PAD_T + chartH + 2, tw, 16, 3);
        ctx.fill();
        ctx.strokeStyle = '#475569';
        ctx.stroke();
        ctx.fillStyle = '#e2e8f0';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(ts, lx + tw / 2, PAD_T + chartH + 10);
      }
    }
  }, [width, height, view, showVolume, interactive, hover, marks, lines, accent, symbol]);

  // Single useEffect triggers redraw whenever draw callback changes.
  useEffect(() => {
    draw();
  }, [draw]);

  // ----- Mouse handlers. ---------------------------------------------------
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!interactive) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const chartW = Math.max(10, width - PAD_L - PAD_R);
    if (!view.length || chartW <= 0) return;
    const slot = chartW / view.length;
    let idx = Math.floor((x - PAD_L) / slot);
    if (idx < 0) idx = 0;
    if (idx >= view.length) idx = view.length - 1;
    setHover({ x, y, idx });
  };

  const handleMouseLeave = () => {
    setHover(null);
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!interactive || !onCandleClick) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const chartW = Math.max(10, width - PAD_L - PAD_R);
    if (!view.length || chartW <= 0) return;
    const slot = chartW / view.length;
    let idx = Math.floor((x - PAD_L) / slot);
    if (idx < 0) idx = 0;
    if (idx >= view.length) idx = view.length - 1;
    onCandleClick(idx);
  };

  return (
    <div
      ref={containerRef}
      className={className}
      style={{ width: '100%', height, position: 'relative' }}
    >
      <canvas
        ref={canvasRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        style={{
          display: 'block',
          width: '100%',
          height: '100%',
          cursor: interactive ? 'crosshair' : 'default',
        }}
        aria-label={symbol ? `${symbol} candlestick chart` : 'candlestick chart'}
        role="img"
      />
    </div>
  );
}
