"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import {
  LayoutDashboard,
  GraduationCap,
  Target,
  History,
  Zap,
  Brain,
  CandlestickChart,
  ScanEye,
  Bot,
  BookMarked,
  Gauge,
  Trophy,
  Menu,
  Moon,
  Sun,
  TrendingUp,
  Github,
  Heart,
} from "lucide-react";
import { useStore } from "@/store/use-store";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { RankBadge } from "@/components/ui-bits";
import { fmtINRCompact } from "@/lib/market";
import { rankForXp } from "@/lib/ranks";
import type { ViewKey } from "@/lib/types";

import { DashboardModule } from "@/components/modules/dashboard";
import { AcademyModule } from "@/components/modules/academy";
import { SimulationModule } from "@/components/modules/simulation";
import { RoomsModule } from "@/components/modules/rooms";
import { ReplayModule } from "@/components/modules/replay";
import { MentorModule } from "@/components/modules/mentor";
import { PsychologyModule } from "@/components/modules/psychology";
import { ScenariosModule } from "@/components/modules/scenarios";
import { ChartAiModule } from "@/components/modules/chart-ai";
import { JournalModule } from "@/components/modules/journal";
import { AnalyticsModule } from "@/components/modules/analytics";
import { LeaderboardModule } from "@/components/modules/leaderboard";

interface NavItem {
  key: ViewKey;
  label: string;
  icon: React.ReactNode;
}
interface NavGroup {
  title: string;
  items: NavItem[];
}

const NAV: NavGroup[] = [
  {
    title: "Overview",
    items: [{ key: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="size-4" /> }],
  },
  {
    title: "Learn",
    items: [
      { key: "academy", label: "Academy", icon: <GraduationCap className="size-4" /> },
      { key: "rooms", label: "Trading Rooms", icon: <Target className="size-4" /> },
      { key: "replay", label: "Trade Replay Lab", icon: <History className="size-4" /> },
      { key: "scenarios", label: "Scenario Trainer", icon: <Zap className="size-4" /> },
      { key: "psychology", label: "Psychology Sim", icon: <Brain className="size-4" /> },
    ],
  },
  {
    title: "Practice",
    items: [
      { key: "simulation", label: "Market Simulator", icon: <CandlestickChart className="size-4" /> },
      { key: "chart-ai", label: "AI Chart Analysis", icon: <ScanEye className="size-4" /> },
    ],
  },
  {
    title: "AI",
    items: [{ key: "mentor", label: "AI Mentor", icon: <Bot className="size-4" /> }],
  },
  {
    title: "Insights",
    items: [
      { key: "journal", label: "Trade Journal", icon: <BookMarked className="size-4" /> },
      { key: "analytics", label: "Analytics", icon: <Gauge className="size-4" /> },
      { key: "leaderboard", label: "Leaderboard", icon: <Trophy className="size-4" /> },
    ],
  },
];

const TITLES: Record<ViewKey, { title: string; desc: string }> = {
  dashboard: { title: "Dashboard", desc: "Command center" },
  academy: { title: "Academy", desc: "Interactive learning" },
  simulation: { title: "Simulator", desc: "Live practice" },
  rooms: { title: "Rooms", desc: "Missions" },
  replay: { title: "Replay Lab", desc: "Historical replay" },
  mentor: { title: "AI Mentor", desc: "Your coach" },
  psychology: { title: "Psychology", desc: "Mind training" },
  scenarios: { title: "Scenarios", desc: "Decision training" },
  "chart-ai": { title: "Chart AI", desc: "Vision analysis" },
  journal: { title: "Journal", desc: "Trade log" },
  analytics: { title: "Analytics", desc: "Performance" },
  leaderboard: { title: "Leaderboard", desc: "Community" },
};

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const activeView = useStore((s) => s.activeView);
  const setActiveView = useStore((s) => s.setActiveView);
  return (
    <nav className="flex-1 space-y-5 overflow-y-auto scrollbar-thin px-3 py-4">
      {NAV.map((group) => (
        <div key={group.title}>
          <div className="px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            {group.title}
          </div>
          <div className="space-y-0.5">
            {group.items.map((item) => {
              const active = activeView === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => {
                    setActiveView(item.key);
                    onNavigate?.();
                  }}
                  className={
                    "flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-all " +
                    (active
                      ? "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/20"
                      : "text-muted-foreground hover:bg-muted/60 hover:text-foreground")
                  }
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  if (!mounted) return <div className="size-9" />;
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      aria-label="Toggle theme"
    >
      {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
    </Button>
  );
}

export function AppShell() {
  const hydrate = useStore((s) => s.hydrate);
  const hydrated = useStore((s) => s.hydrated);
  const activeView = useStore((s) => s.activeView);
  const trader = useStore((s) => s.trader);
  const sidebarOpen = useStore((s) => s.sidebarOpen);
  const setSidebarOpen = useStore((s) => s.setSidebarOpen);

  React.useEffect(() => {
    hydrate();
  }, [hydrate]);

  const renderModule = () => {
    switch (activeView) {
      case "dashboard":
        return <DashboardModule />;
      case "academy":
        return <AcademyModule />;
      case "simulation":
        return <SimulationModule />;
      case "rooms":
        return <RoomsModule />;
      case "replay":
        return <ReplayModule />;
      case "mentor":
        return <MentorModule />;
      case "psychology":
        return <PsychologyModule />;
      case "scenarios":
        return <ScenariosModule />;
      case "chart-ai":
        return <ChartAiModule />;
      case "journal":
        return <JournalModule />;
      case "analytics":
        return <AnalyticsModule />;
      case "leaderboard":
        return <LeaderboardModule />;
      default:
        return <DashboardModule />;
    }
  };

  const meta = TITLES[activeView];

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Topbar */}
      <header className="sticky top-0 z-40 flex h-14 items-center justify-between gap-3 border-b border-border/60 bg-background/85 px-4 backdrop-blur lg:px-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </Button>
          <div className="flex items-center gap-2.5">
            <div className="flex size-8 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/25">
              <TrendingUp className="size-4.5" />
            </div>
            <div className="hidden sm:block">
              <div className="text-sm font-bold leading-none text-foreground">TradeHackMe <span className="text-emerald-400">AI</span></div>
              <div className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">{meta.title} · {meta.desc}</div>
            </div>
          </div>
        </div>

        {/* Trader chip */}
        <div className="flex items-center gap-2">
          {trader && (
            <div className="hidden items-center gap-3 rounded-full border border-border/60 bg-muted/30 px-3 py-1.5 sm:flex">
              <div className="flex items-center gap-1.5">
                <Badge
                  className="border-0 bg-emerald-500/15 text-[10px] font-bold text-emerald-400"
                  style={{}}
                >
                  R{rankForXp(trader.xp).rank}
                </Badge>
                <span className="text-xs text-muted-foreground">{rankForXp(trader.xp).name}</span>
              </div>
              <div className="h-4 w-px bg-border" />
              <div className="text-right">
                <div className="text-xs font-bold tabular-nums text-foreground">{fmtINRCompact(trader.capital)}</div>
                <div className="text-[9px] uppercase text-muted-foreground">Capital</div>
              </div>
            </div>
          )}
          <ThemeToggle />
        </div>
      </header>

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-60 shrink-0 flex-col border-r border-border/60 bg-sidebar lg:flex">
          <NavList />
          <div className="border-t border-border/60 p-3">
            {trader && <RankBadge trader={trader} compact />}
          </div>
        </aside>

        {/* Main */}
        <main className="min-w-0 flex-1 px-4 py-6 lg:px-8">{renderModule()}</main>
      </div>

      {/* Mobile sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="border-b border-border/60 px-4 py-3">
            <SheetTitle className="flex items-center gap-2 text-left">
              <div className="flex size-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
                <TrendingUp className="size-4" />
              </div>
              TradeHackMe <span className="text-emerald-400">AI</span>
            </SheetTitle>
          </SheetHeader>
          <NavList onNavigate={() => setSidebarOpen(false)} />
          {trader && (
            <div className="border-t border-border/60 p-3">
              <RankBadge trader={trader} compact />
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/60 bg-background">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-5 text-center sm:flex-row sm:text-left lg:px-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="flex size-6 items-center justify-center rounded-md bg-emerald-500/15 text-emerald-400">
              <TrendingUp className="size-3.5" />
            </div>
            <span>
              <span className="font-semibold text-foreground">TradeHackMe AI</span> — The TryHackMe of Trading
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-x-1.5 gap-y-1 text-xs text-muted-foreground">
            {["Learn", "Practice", "Analyze", "Improve", "Master"].map((s, i, arr) => (
              <React.Fragment key={s}>
                <span className={i === arr.length - 1 ? "font-semibold text-emerald-400" : ""}>{s}</span>
                {i < arr.length - 1 && <span className="text-muted-foreground/50">→</span>}
              </React.Fragment>
            ))}
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span>Built with</span>
            <Heart className="size-3 fill-rose-500 text-rose-500" />
            <span>for traders · Virtual capital only</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
