"use client";

import ReactMarkdown from "react-markdown";

export function Markdown({ children, className }: { children: string; className?: string }) {
  return (
    <div className={"prose-trade " + (className ?? "")}>
      <ReactMarkdown
        components={{
          h1: ({ children }) => (
            <h3 className="mt-4 mb-2 text-lg font-semibold text-foreground">{children}</h3>
          ),
          h2: ({ children }) => (
            <h3 className="mt-4 mb-2 text-lg font-semibold text-foreground">{children}</h3>
          ),
          h3: ({ children }) => (
            <h4 className="mt-3 mb-1.5 text-base font-semibold text-emerald-400">{children}</h4>
          ),
          p: ({ children }) => (
            <p className="my-2 text-sm leading-relaxed text-muted-foreground">{children}</p>
          ),
          ul: ({ children }) => (
            <ul className="my-2 list-disc space-y-1 pl-5 text-sm text-muted-foreground">{children}</ul>
          ),
          ol: ({ children }) => (
            <ol className="my-2 list-decimal space-y-1 pl-5 text-sm text-muted-foreground">{children}</ol>
          ),
          li: ({ children }) => <li className="leading-relaxed">{children}</li>,
          strong: ({ children }) => (
            <strong className="font-semibold text-foreground">{children}</strong>
          ),
          code: ({ children }) => (
            <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs text-emerald-400">
              {children}
            </code>
          ),
          blockquote: ({ children }) => (
            <blockquote className="my-2 border-l-2 border-emerald-500/50 pl-3 italic text-muted-foreground">
              {children}
            </blockquote>
          ),
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
