import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// GET /api/progress — all LessonProgress rows for trader "me"
export async function GET() {
  try {
    await ensureTrader()
    const rows = await db.lessonProgress.findMany({
      where: { traderId: 'me' },
      orderBy: { lessonId: 'asc' },
    })
    return NextResponse.json(rows)
  } catch (err) {
    console.error('[GET /api/progress]', err)
    return NextResponse.json(
      { error: 'Failed to fetch progress' },
      { status: 500 }
    )
  }
}

// POST /api/progress — upsert a lesson progress row
// Body: { lessonId, status?, score? }
export async function POST(req: NextRequest) {
  try {
    await ensureTrader()
    const body = await req.json().catch(() => ({}))

    const { lessonId, status, score } = body
    if (!lessonId || typeof lessonId !== 'string') {
      return NextResponse.json(
        { error: 'lessonId (string) is required' },
        { status: 400 }
      )
    }

    // Determine if this upsert is transitioning to "completed".
    const existing = await db.lessonProgress.findUnique({
      where: { traderId_lessonId: { traderId: 'me', lessonId } },
    })

    const wasCompleted = existing?.status === 'completed'
    const willBeCompleted = status === 'completed'

    const data: {
      status?: string
      score?: number
      completedAt?: Date | null
    } = {}

    if (typeof status === 'string') data.status = status
    if (typeof score === 'number') data.score = score
    if (willBeCompleted && !wasCompleted) {
      data.completedAt = new Date()
    }

    const upserted = await db.lessonProgress.upsert({
      where: { traderId_lessonId: { traderId: 'me', lessonId } },
      update: data,
      create: {
        traderId: 'me',
        lessonId,
        status: typeof status === 'string' ? status : 'locked',
        score: typeof score === 'number' ? score : 0,
        completedAt: status === 'completed' ? new Date() : null,
      },
    })

    // If transitioning to completed, increment trader.lessonsCompleted.
    if (willBeCompleted && !wasCompleted) {
      const current = await db.trader.findUniqueOrThrow({
        where: { id: 'me' },
      })
      await db.trader.update({
        where: { id: 'me' },
        data: { lessonsCompleted: current.lessonsCompleted + 1 },
      })
    }

    return NextResponse.json(upserted)
  } catch (err) {
    console.error('[POST /api/progress]', err)
    return NextResponse.json(
      { error: 'Failed to upsert progress' },
      { status: 500 }
    )
  }
}
