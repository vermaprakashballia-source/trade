import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// Compute (pnl, rMultiple) for a closed trade.
function computeTradeResult(opts: {
  side: string
  entry: number
  exit: number
  size: number
  stopLoss: number | null
}) {
  const { side, entry, exit, size, stopLoss } = opts
  const pnl =
    side.toUpperCase() === 'LONG'
      ? (exit - entry) * size
      : (entry - exit) * size

  let rMultiple: number | null = null
  if (stopLoss !== null && stopLoss !== undefined) {
    const riskPerUnit = Math.abs(entry - stopLoss)
    if (riskPerUnit > 0) {
      const rewardPerUnit =
        side.toUpperCase() === 'LONG' ? exit - entry : entry - exit
      rMultiple = rewardPerUnit / riskPerUnit
    }
  }
  return { pnl, rMultiple }
}

// PATCH /api/trades/[id] — close a trade.
// Body: { exit, aiFeedback? }
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await ensureTrader()
    const { id } = await params
    const body = await req.json().catch(() => ({}))

    if (typeof body.exit !== 'number') {
      return NextResponse.json(
        { error: 'exit (number) is required' },
        { status: 400 }
      )
    }

    const trade = await db.trade.findUnique({ where: { id } })
    if (!trade) {
      return NextResponse.json({ error: 'Trade not found' }, { status: 404 })
    }
    if (trade.traderId !== 'me') {
      return NextResponse.json(
        { error: 'Trade does not belong to trader' },
        { status: 403 }
      )
    }

    const exit = Number(body.exit)
    const { pnl, rMultiple } = computeTradeResult({
      side: trade.side,
      entry: trade.entry,
      exit,
      size: trade.size,
      stopLoss: trade.stopLoss,
    })

    const closedTrade = await db.trade.update({
      where: { id },
      data: {
        exit,
        status: 'CLOSED',
        closedAt: new Date(),
        pnl,
        rMultiple,
        aiFeedback:
          typeof body.aiFeedback === 'string'
            ? body.aiFeedback
            : trade.aiFeedback,
      },
    })

    // Update trader stats atomically: tradesDone+1, win/loss, capital += pnl, streak.
    const current = await db.trader.findUniqueOrThrow({ where: { id: 'me' } })
    const win = pnl > 0
    const newCurrentStreak = win ? current.currentStreak + 1 : 0
    const newBestStreak = Math.max(current.bestStreak, newCurrentStreak)

    const updatedTrader = await db.trader.update({
      where: { id: 'me' },
      data: {
        tradesDone: current.tradesDone + 1,
        wins: current.wins + (win ? 1 : 0),
        losses: current.losses + (win ? 0 : 1),
        currentStreak: newCurrentStreak,
        bestStreak: newBestStreak,
        capital: current.capital + pnl,
      },
    })

    return NextResponse.json({ trade: closedTrade, trader: updatedTrader })
  } catch (err) {
    console.error('[PATCH /api/trades/[id]]', err)
    return NextResponse.json(
      { error: 'Failed to close trade' },
      { status: 500 }
    )
  }
}

// DELETE /api/trades/[id] — delete a trade (for clearing)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await ensureTrader()
    const { id } = await params

    const trade = await db.trade.findUnique({ where: { id } })
    if (!trade) {
      return NextResponse.json({ error: 'Trade not found' }, { status: 404 })
    }
    if (trade.traderId !== 'me') {
      return NextResponse.json(
        { error: 'Trade does not belong to trader' },
        { status: 403 }
      )
    }

    await db.trade.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[DELETE /api/trades/[id]]', err)
    return NextResponse.json(
      { error: 'Failed to delete trade' },
      { status: 500 }
    )
  }
}
