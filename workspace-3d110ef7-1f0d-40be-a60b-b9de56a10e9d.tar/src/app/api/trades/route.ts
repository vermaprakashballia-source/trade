import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// GET /api/trades — all trades for trader "me", newest first
export async function GET() {
  try {
    await ensureTrader()
    const trades = await db.trade.findMany({
      where: { traderId: 'me' },
      orderBy: { openedAt: 'desc' },
    })
    return NextResponse.json(trades)
  } catch (err) {
    console.error('[GET /api/trades]', err)
    return NextResponse.json(
      { error: 'Failed to fetch trades' },
      { status: 500 }
    )
  }
}

// POST /api/trades — open a new trade
// Body: { symbol, side, entry, size, stopLoss?, takeProfit?, context?, reason? }
export async function POST(req: NextRequest) {
  try {
    await ensureTrader()
    const body = await req.json().catch(() => ({}))

    const { symbol, side, entry, size, stopLoss, takeProfit, context, reason } =
      body

    if (
      !symbol ||
      !side ||
      typeof entry !== 'number' ||
      typeof size !== 'number'
    ) {
      return NextResponse.json(
        { error: 'Missing required fields: symbol, side, entry, size' },
        { status: 400 }
      )
    }

    const normalizedSide = String(side).toUpperCase()
    if (normalizedSide !== 'LONG' && normalizedSide !== 'SHORT') {
      return NextResponse.json(
        { error: 'side must be LONG or SHORT' },
        { status: 400 }
      )
    }

    const created = await db.trade.create({
      data: {
        traderId: 'me',
        symbol: String(symbol),
        side: normalizedSide,
        entry: Number(entry),
        size: Number(size),
        stopLoss: typeof stopLoss === 'number' ? Number(stopLoss) : null,
        takeProfit: typeof takeProfit === 'number' ? Number(takeProfit) : null,
        status: 'OPEN',
        context: context ? String(context) : 'simulation',
        reason: reason ? String(reason) : null,
      },
    })

    return NextResponse.json(created, { status: 201 })
  } catch (err) {
    console.error('[POST /api/trades]', err)
    return NextResponse.json(
      { error: 'Failed to create trade' },
      { status: 500 }
    )
  }
}
