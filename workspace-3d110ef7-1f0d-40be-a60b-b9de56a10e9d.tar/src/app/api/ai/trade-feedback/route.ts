import { NextRequest, NextResponse } from "next/server";
import { aiChat, type AIMessage } from "@/lib/ai-provider";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const trade = body.trade; // summary object
    if (!trade) {
      return NextResponse.json({ error: "trade is required" }, { status: 400 });
    }

    const prompt = `You are an AI trading mentor evaluating a closed simulated trade on TradeHackMe AI. Give crisp, honest, professional feedback.

Trade summary:
- Symbol: ${trade.symbol}
- Side: ${trade.side}
- Entry: ${trade.entry}
- Exit: ${trade.exit ?? "open"}
- Size: ${trade.size}
- Stop loss: ${trade.stopLoss ?? "none"}
- Take profit: ${trade.takeProfit ?? "none"}
- PnL: ${trade.pnl ?? "open"}
- R-multiple: ${trade.rMultiple ?? "n/a"}
- Context: ${trade.context}
- Trader note: ${trade.reason ?? "none"}

Respond in 3-5 short bullet points covering:
1. What was done well (or the single biggest positive).
2. The biggest mistake or risk flaw (entry timing, sizing, stop placement, exit, R:R).
3. One concrete, specific rule to apply next time.
4. A one-line judgment: was this a "good process" trade regardless of outcome?

Be specific and numeric. No fluff. No guaranteed-profit language.`;

    const messages: AIMessage[] = [
      { role: "system", content: "You are a disciplined prop-firm trading coach." },
      { role: "user", content: prompt },
    ];

    const content: string = await aiChat(messages);

    return NextResponse.json({
      content: content || "Trade logged. Keep refining your process — risk first.",
    });
  } catch (err) {
    console.error("trade-feedback AI error", err);
    return NextResponse.json(
      {
        content:
          "Trade logged. Quick coach note: confirm your stop respected the 1% rule and your R:R was predefined. Review the entry — did you have confirmation, or did you chase? Process over outcome.",
        error: String(err),
      },
      { status: 200 }
    );
  }
}
