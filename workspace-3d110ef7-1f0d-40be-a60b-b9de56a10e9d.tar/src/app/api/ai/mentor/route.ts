import { NextRequest, NextResponse } from "next/server";
import { aiChat, MENTOR_SYSTEM, type AIMessage } from "@/lib/ai-provider";

export const runtime = "nodejs";

interface HistoryMsg {
  role: "user" | "assistant";
  content: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message: string | undefined = body.message;
    const history: HistoryMsg[] = Array.isArray(body.history)
      ? body.history.slice(-10)
      : [];
    const traderContext: string | undefined = body.traderContext;

    if (!message || typeof message !== "string") {
      return NextResponse.json(
        { error: "message is required" },
        { status: 400 }
      );
    }

    const messages: AIMessage[] = [{ role: "system", content: MENTOR_SYSTEM }];

    if (traderContext) {
      messages.push({
        role: "system",
        content: `Trader context:\n${traderContext}`,
      });
    }

    for (const m of history) {
      messages.push({ role: m.role, content: m.content });
    }
    messages.push({ role: "user", content: message });

    const content: string = await aiChat(messages);

    return NextResponse.json({ content: content || "I'm here. Could you rephrase that?" });
  } catch (err) {
    console.error("mentor AI error", err);
    return NextResponse.json(
      {
        content:
          "I hit a snag connecting to my reasoning engine. Give me a moment and try again — in the meantime, remember: risk first, process over outcome.",
        error: String(err),
      },
      { status: 200 }
    );
  }
}
