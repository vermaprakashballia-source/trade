import { NextRequest, NextResponse } from "next/server";
import { aiChat, type AIMessage } from "@/lib/ai-provider";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { scenarioTitle, setup, userChoiceLabel, bestChoiceLabel, proReasoning } =
      body;

    if (!scenarioTitle || !userChoiceLabel) {
      return NextResponse.json(
        { error: "scenarioTitle and userChoiceLabel are required" },
        { status: 400 }
      );
    }

    const correct = userChoiceLabel === bestChoiceLabel;
    const prompt = `You are a professional trading coach debriefing a scenario exercise on TradeHackMe AI.

Scenario: ${scenarioTitle}
Setup: ${setup}
The user chose: "${userChoiceLabel}".
The professional best choice was: "${bestChoiceLabel}".
${correct ? "The user's choice MATCHED the professional choice." : "The user's choice DIFFERED from the professional choice."}

Write a 2-3 paragraph debrief that:
1. Acknowledges the user's reasoning charitably.
2. Explains WHY professionals prefer the best choice — the mechanics, risk logic, and probability thinking (don't just restate; deepen it).
3. Gives one transferable principle the trader can apply to future, similar situations.

Tone: candid, mentor-like, no hype, no guaranteed outcomes. Reference probabilities and risk where relevant. Keep under 180 words.`;

    const messages: AIMessage[] = [
      {
        role: "system",
        content:
          "You are a seasoned prop-firm risk manager coaching a developing trader.",
      },
      { role: "user", content: prompt },
    ];

    const content: string =
      (await aiChat(messages)) ||
      proReasoning ||
      "Focus on process and risk. The professional choice minimizes regret and keeps probabilities on your side.";

    return NextResponse.json({ content, correct });
  } catch (err) {
    console.error("scenario AI error", err);
    return NextResponse.json(
      {
        content:
          "Professional principle: in uncertain situations, choose the option with the best expected outcome AND the smallest regret if wrong. Process and risk first — outcomes are probabilistic.",
        correct: false,
        error: String(err),
      },
      { status: 200 }
    );
  }
}
