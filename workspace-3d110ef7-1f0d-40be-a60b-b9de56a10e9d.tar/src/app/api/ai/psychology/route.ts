import { NextRequest, NextResponse } from "next/server";
import { aiChat, type AIMessage } from "@/lib/ai-provider";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    // choices: array of { title, chosenLabel, tag, discipline }
    const choices = Array.isArray(body.choices) ? body.choices : [];
    const disciplineScore: number | undefined = body.disciplineScore;

    if (!choices.length) {
      return NextResponse.json(
        { error: "choices array is required" },
        { status: 400 }
      );
    }

    const summary = choices
      .map(
        (c: any, i: number) =>
          `${i + 1}. ${c.title}: chose "${c.chosenLabel}" (${c.tag}, discipline ${c.discipline >= 0 ? "+" : ""}${c.discipline})`
      )
      .join("\n");

    const prompt = `You are a trading psychology coach for TradeHackMe AI. A trader just completed a Psychology Simulator session. Generate a concise Psychology Report.

Their decisions:
${summary}

Overall discipline score (0-100): ${disciplineScore ?? "n/a"}

Respond in Markdown with EXACTLY these sections:

### Emotional Score
A 0-100 score with a one-line read on their emotional control this session.

### Discipline Score
Comment on their discipline score (${disciplineScore ?? "n/a"}/100) — what it means and whether it's a concern.

### Consistency Score
0-100 estimate of decision consistency (did they follow a stable process or flip-flop?), with a sentence.

### FOMO Score
0-100 (higher = more FOMO), with a sentence. Infer from their choices.

### Risk Control Rating
A short qualitative rating (Strong / Adequate / Weak) with justification.

### Key Pattern
One sentence naming the dominant psychological pattern you observed.

### Recommendation
One concrete, actionable recommendation for their next trading session.

Be specific to their actual choices. No generic platitudes. Keep it tight.`;

    const messages: AIMessage[] = [
      {
        role: "system",
        content:
          "You are an expert in trading psychology and behavioral finance, coaching a retail trader.",
      },
      { role: "user", content: prompt },
    ];

    const content: string =
      (await aiChat(messages)) ||
      "Focus on building a stable, rules-based process. Emotional control follows discipline, not the other way around.";

    return NextResponse.json({ content });
  } catch (err) {
    console.error("psychology AI error", err);
    return NextResponse.json(
      {
        content:
          "### Psychology Report\n\nYour decisions have been recorded. The throughline of profitable trading psychology is simple: a pre-committed process beats in-the-moment emotion every time. Define your rules before the market opens, and let the rules trade — not your feelings.",
        error: String(err),
      },
      { status: 200 }
    );
  }
}
