import { NextRequest, NextResponse } from "next/server";
import { aiVision, type AIMessage } from "@/lib/ai-provider";

export const runtime = "nodejs";

const PROMPT = `You are a senior technical analyst reviewing a trading chart image for an educational trading platform (TradeHackMe AI). Analyze the chart and produce a structured, professional breakdown.

Respond in clear Markdown with these exact sections (use ### headings):

### Trend Analysis
State the prevailing trend (uptrend / downtrend / ranging) and the evidence on the chart (structure of highs/lows, moving averages if visible).

### Key Levels
- **Support:** list visible support zones with approximate prices.
- **Resistance:** list visible resistance zones with approximate prices.

### Entry Zone
Suggest a logical entry zone (or "wait — no clean setup") with a brief rationale.

### Stop Loss
Suggest a stop-loss placement that invalidates the thesis, with the price.

### Target / Take Profit
Suggest at least one profit target. State the Risk-to-Reward ratio.

### Educational Notes
1–2 bullet points teaching the user what to learn from this chart.

Keep it concise and concrete. Do NOT guarantee outcomes. Use approximate prices from the chart. If the image is not a price chart, say so politely and describe what you see.`;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const image: string | undefined = body.image; // data URL: data:image/...;base64,....
    const symbol: string | undefined = body.symbol;

    if (!image || !image.startsWith("data:image")) {
      return NextResponse.json(
        { error: "A valid image data URL is required." },
        { status: 400 }
      );
    }

    const userText = symbol
      ? `${PROMPT}\n\nThe user says this chart is of ${symbol}.`
      : PROMPT;

    const messages: AIMessage[] = [
      {
        role: "user",
        content: [
          { type: "text", text: userText },
          { type: "image_url", image_url: { url: image } },
        ],
      },
    ];

    const content: string = await aiVision(messages);

    return NextResponse.json({
      content: content || "I couldn't parse this chart. Try a clearer image.",
    });
  } catch (err) {
    console.error("chart-analysis AI error", err);
    return NextResponse.json(
      {
        content:
          "### Analysis Unavailable\n\nMy vision model is temporarily unavailable. Please try again in a moment. Meanwhile, practice identifying trend, support, and resistance by eye — that skill transfers to every chart you'll ever read.",
        error: String(err),
      },
      { status: 200 }
    );
  }
}
