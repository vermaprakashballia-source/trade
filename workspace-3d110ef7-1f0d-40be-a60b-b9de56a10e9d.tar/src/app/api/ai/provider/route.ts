import { NextResponse } from "next/server";
import { activeProvider } from "@/lib/ai-provider";

export const runtime = "nodejs";

// Diagnostic: tells you which AI backend is currently in use.
// GET /api/ai/provider -> { provider: "openai" | "zai", openaiConfigured: boolean }
export async function GET() {
  const provider = activeProvider();
  return NextResponse.json({
    provider,
    openaiConfigured: provider === "openai",
    note:
      provider === "openai"
        ? "OpenAI is active. All AI calls use the OpenAI Chat Completions API."
        : "Using the Z.ai SDK (default). Set OPENAI_API_KEY in .env.local to switch to OpenAI.",
  });
}
