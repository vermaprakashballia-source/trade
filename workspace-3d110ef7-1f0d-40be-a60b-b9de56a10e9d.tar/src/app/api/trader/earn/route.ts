import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// POST /api/trader/earn — atomically apply earnings/progress to the trader.
// Body: { xp?, capitalDelta?, win?, lessonCompleted?, roomCompleted?, disciplineDelta? }
export async function POST(req: NextRequest) {
  try {
    await ensureTrader()
    const body = await req.json().catch(() => ({}))

    const xp = typeof body.xp === 'number' ? body.xp : 0
    const capitalDelta =
      typeof body.capitalDelta === 'number' ? body.capitalDelta : 0
    const winFlag = typeof body.win === 'boolean' ? body.win : null
    const lessonCompleted = body.lessonCompleted === true
    const roomCompleted = body.roomCompleted === true
    const disciplineDelta =
      typeof body.disciplineDelta === 'number' ? body.disciplineDelta : 0

    // Fetch current state for streak/derived computations.
    const current = await db.trader.findUniqueOrThrow({ where: { id: 'me' } })

    const newWins = current.wins + (winFlag === true ? 1 : 0)
    const newLosses = current.losses + (winFlag === false ? 1 : 0)
    const newTradesDone = current.tradesDone + (winFlag !== null ? 1 : 0)
    const newCurrentStreak =
      winFlag === true
        ? current.currentStreak + 1
        : winFlag === false
          ? 0
          : current.currentStreak
    const newBestStreak = Math.max(current.bestStreak, newCurrentStreak)
    const newLessonsCompleted =
      current.lessonsCompleted + (lessonCompleted ? 1 : 0)
    const newRoomsCompleted = current.roomsCompleted + (roomCompleted ? 1 : 0)
    const clampedDiscipline = Math.min(
      100,
      Math.max(0, current.disciplineScore + disciplineDelta)
    )

    const updated = await db.trader.update({
      where: { id: 'me' },
      data: {
        xp: current.xp + xp,
        capital: current.capital + capitalDelta,
        tradesDone: newTradesDone,
        wins: newWins,
        losses: newLosses,
        currentStreak: newCurrentStreak,
        bestStreak: newBestStreak,
        lessonsCompleted: newLessonsCompleted,
        roomsCompleted: newRoomsCompleted,
        disciplineScore: clampedDiscipline,
      },
    })

    return NextResponse.json(updated)
  } catch (err) {
    console.error('[POST /api/trader/earn]', err)
    return NextResponse.json(
      { error: 'Failed to apply earnings' },
      { status: 500 }
    )
  }
}
