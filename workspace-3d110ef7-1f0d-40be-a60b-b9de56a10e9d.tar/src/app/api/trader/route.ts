import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// GET /api/trader — return the singleton trader (ensuring it exists)
export async function GET() {
  try {
    const trader = await ensureTrader()
    return NextResponse.json(trader)
  } catch (err) {
    console.error('[GET /api/trader]', err)
    return NextResponse.json(
      { error: 'Failed to fetch trader' },
      { status: 500 }
    )
  }
}

// PATCH /api/trader — update scalar fields on the trader
export async function PATCH(req: NextRequest) {
  try {
    await ensureTrader()
    const body = await req.json().catch(() => ({}))

    const data: Record<string, unknown> = {}
    const allowedKeys = [
      'name',
      'rank',
      'rankName',
      'xp',
      'capital',
      'tradesDone',
      'wins',
      'losses',
      'bestStreak',
      'currentStreak',
      'lessonsCompleted',
      'roomsCompleted',
      'disciplineScore',
    ] as const

    for (const key of allowedKeys) {
      if (body[key] !== undefined && body[key] !== null) {
        data[key] = body[key]
      }
    }

    const updated = await db.trader.update({
      where: { id: 'me' },
      data,
    })
    return NextResponse.json(updated)
  } catch (err) {
    console.error('[PATCH /api/trader]', err)
    return NextResponse.json(
      { error: 'Failed to update trader' },
      { status: 500 }
    )
  }
}
