import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTrader } from '@/lib/seed'

// GET /api/chat?module=mentor — chat messages for trader "me" & module, oldest first
export async function GET(req: NextRequest) {
  try {
    await ensureTrader()
    const { searchParams } = new URL(req.url)
    const moduleParam = (searchParams.get('module') || 'mentor').toString()

    const messages = await db.chatMessage.findMany({
      where: { traderId: 'me', module: moduleParam },
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json(messages)
  } catch (err) {
    console.error('[GET /api/chat]', err)
    return NextResponse.json(
      { error: 'Failed to fetch chat messages' },
      { status: 500 }
    )
  }
}

// POST /api/chat — create a chat message
// Body: { role, content, module? }
export async function POST(req: NextRequest) {
  try {
    await ensureTrader()
    const body = await req.json().catch(() => ({}))

    const { role, content, module } = body
    if (!role || typeof role !== 'string') {
      return NextResponse.json(
        { error: 'role (string) is required' },
        { status: 400 }
      )
    }
    if (!content || typeof content !== 'string') {
      return NextResponse.json(
        { error: 'content (string) is required' },
        { status: 400 }
      )
    }

    const created = await db.chatMessage.create({
      data: {
        traderId: 'me',
        role,
        content,
        module: typeof module === 'string' ? module : 'mentor',
      },
    })

    return NextResponse.json(created, { status: 201 })
  } catch (err) {
    console.error('[POST /api/chat]', err)
    return NextResponse.json(
      { error: 'Failed to create chat message' },
      { status: 500 }
    )
  }
}
