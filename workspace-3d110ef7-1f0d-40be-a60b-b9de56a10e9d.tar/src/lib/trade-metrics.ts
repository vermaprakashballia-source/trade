// Trade statistics helpers used by Journal, Analytics, Dashboard.
import type { Trade } from "@/lib/types";

export interface TradeMetrics {
  total: number;
  open: number;
  closed: number;
  wins: number;
  losses: number;
  winRate: number; // 0-100
  netPnl: number;
  grossWin: number;
  grossLoss: number;
  profitFactor: number; // grossWin / |grossLoss| (Infinity if no losses)
  avgR: number;
  avgWin: number;
  avgLoss: number;
  bestTrade: number;
  worstTrade: number;
  maxDrawdown: number; // in currency
  expectancy: number; // avg pnl per trade
  streak: number; // current win/loss streak (signed: +win, -loss)
}

export function computeMetrics(trades: Trade[]): TradeMetrics {
  const closed = trades.filter((t) => t.status === "CLOSED" && t.pnl != null);
  const open = trades.filter((t) => t.status === "OPEN").length;
  let wins = 0;
  let losses = 0;
  let netPnl = 0;
  let grossWin = 0;
  let grossLoss = 0;
  let sumR = 0;
  let rCount = 0;
  let bestTrade = 0;
  let worstTrade = 0;

  // Sort closed by closedAt for drawdown calc.
  const sorted = [...closed].sort(
    (a, b) =>
      new Date(a.closedAt ?? a.openedAt).getTime() -
      new Date(b.closedAt ?? b.openedAt).getTime()
  );

  let peak = 0;
  let maxDD = 0;
  let equity = 0;
  let streak = 0;

  for (const t of sorted) {
    const pnl = t.pnl ?? 0;
    netPnl += pnl;
    equity += pnl;
    if (equity > peak) peak = equity;
    const dd = peak - equity;
    if (dd > maxDD) maxDD = dd;

    if (pnl >= 0) {
      wins++;
      grossWin += pnl;
      streak = streak >= 0 ? streak + 1 : 1;
    } else {
      losses++;
      grossLoss += Math.abs(pnl);
      streak = streak <= 0 ? streak - 1 : -1;
    }
    if (pnl > bestTrade) bestTrade = pnl;
    if (pnl < worstTrade) worstTrade = pnl;
    if (t.rMultiple != null && isFinite(t.rMultiple)) {
      sumR += t.rMultiple;
      rCount++;
    }
  }

  const closedCount = closed.length;
  return {
    total: trades.length,
    open,
    closed: closedCount,
    wins,
    losses,
    winRate: closedCount ? (wins / closedCount) * 100 : 0,
    netPnl,
    grossWin,
    grossLoss,
    profitFactor: grossLoss === 0 ? (grossWin > 0 ? Infinity : 0) : grossWin / grossLoss,
    avgR: rCount ? sumR / rCount : 0,
    avgWin: wins ? grossWin / wins : 0,
    avgLoss: losses ? grossLoss / losses : 0,
    bestTrade,
    worstTrade,
    maxDrawdown: maxDD,
    expectancy: closedCount ? netPnl / closedCount : 0,
    streak,
  };
}

// Equity curve points: startingCapital + cumulative pnl of closed trades in order.
export function equityCurve(
  trades: Trade[],
  startingCapital: number
): { label: string; equity: number }[] {
  const sorted = trades
    .filter((t) => t.status === "CLOSED" && t.pnl != null)
    .sort(
      (a, b) =>
        new Date(a.closedAt ?? a.openedAt).getTime() -
        new Date(b.closedAt ?? b.openedAt).getTime()
    );
  const pts: { label: string; equity: number }[] = [
    { label: "Start", equity: startingCapital },
  ];
  let eq = startingCapital;
  sorted.forEach((t, i) => {
    eq += t.pnl ?? 0;
    pts.push({ label: `T${i + 1}`, equity: eq });
  });
  return pts;
}
