// Candlestick pattern & structure detection helpers.
// Used by the Academy (interactive chart-ID tasks) and Rooms.
import type { Candle } from "@/lib/market";

// Bullish engulfing at index i: prior candle down, current up,
// current body engulfs prior body.
export function findBullishEngulfing(data: Candle[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < data.length; i++) {
    const a = data[i - 1];
    const b = data[i];
    const aDown = a.close < a.open;
    const bUp = b.close > b.open;
    if (!aDown || !bUp) continue;
    if (b.open <= a.close && b.close >= a.open) out.push(i);
  }
  return out;
}

// Bearish engulfing at index i.
export function findBearishEngulfing(data: Candle[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < data.length; i++) {
    const a = data[i - 1];
    const b = data[i];
    const aUp = a.close > a.open;
    const bDown = b.close < b.open;
    if (!aUp || !bDown) continue;
    if (b.open >= a.close && b.close <= a.open) out.push(i);
  }
  return out;
}

// Doji: tiny body relative to range.
export function findDoji(data: Candle[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    const range = c.high - c.low;
    const body = Math.abs(c.close - c.open);
    if (range <= 0) continue;
    if (body <= range * 0.1) out.push(i);
  }
  return out;
}

// Hammer: small body near top, long lower wick (>= 2x body), small upper wick.
export function findHammer(data: Candle[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    const body = Math.abs(c.close - c.open);
    const lower = Math.min(c.open, c.close) - c.low;
    const upper = c.high - Math.max(c.open, c.close);
    if (body <= 0) continue;
    if (lower >= body * 2 && upper <= body * 0.6) out.push(i);
  }
  return out;
}

// Support levels: local minima of lows (window), clustered by price proximity.
export function findSupportLevels(
  data: Candle[],
  window = 3
): { index: number; price: number }[] {
  const raw: { index: number; price: number }[] = [];
  for (let i = window; i < data.length - window; i++) {
    let isMin = true;
    for (let j = i - window; j <= i + window; j++) {
      if (j === i) continue;
      if (data[j].low < data[i].low) {
        isMin = false;
        break;
      }
    }
    if (isMin) raw.push({ index: i, price: data[i].low });
  }
  return clusterLevels(raw);
}

export function findResistanceLevels(
  data: Candle[],
  window = 3
): { index: number; price: number }[] {
  const raw: { index: number; price: number }[] = [];
  for (let i = window; i < data.length - window; i++) {
    let isMax = true;
    for (let j = i - window; j <= i + window; j++) {
      if (j === i) continue;
      if (data[j].high > data[i].high) {
        isMax = false;
        break;
      }
    }
    if (isMax) raw.push({ index: i, price: data[i].high });
  }
  return clusterLevels(raw);
}

function clusterLevels(
  raw: { index: number; price: number }[]
): { index: number; price: number }[] {
  if (!raw.length) return [];
  const sorted = [...raw].sort((a, b) => a.price - b.price);
  const clusters: { index: number; price: number }[][] = [[sorted[0]]];
  for (let k = 1; k < sorted.length; k++) {
    const prev = clusters[clusters.length - 1];
    const avgPrev =
      prev.reduce((s, p) => s + p.price, 0) / prev.length;
    if (Math.abs(sorted[k].price - avgPrev) / avgPrev < 0.012) {
      prev.push(sorted[k]);
    } else {
      clusters.push([sorted[k]]);
    }
  }
  // Representative = average price of cluster, index = most recent touch.
  return clusters.map((cl) => {
    const price = cl.reduce((s, p) => s + p.price, 0) / cl.length;
    const index = cl[cl.length - 1].index;
    return { index, price };
  });
}

// Trend via linear regression slope on closes, normalized by mean price.
export type Trend = "uptrend" | "downtrend" | "ranging";
export function detectTrend(data: Candle[]): Trend {
  if (data.length < 10) return "ranging";
  const n = data.length;
  const xs = Array.from({ length: n }, (_, i) => i);
  const ys = data.map((c) => c.close);
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - meanX) * (ys[i] - meanY);
    den += (xs[i] - meanX) ** 2;
  }
  const slope = den === 0 ? 0 : num / den;
  const norm = slope / meanY;
  if (norm > 0.004) return "uptrend";
  if (norm < -0.004) return "downtrend";
  return "ranging";
}
