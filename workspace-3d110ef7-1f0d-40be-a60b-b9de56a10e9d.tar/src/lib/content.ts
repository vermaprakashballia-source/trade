// Curriculum & scenario content for TradeHackMe AI.
// Lessons, mission-based Rooms, Scenario Trainer cases, and Psychology scenarios.

export type Level = "Beginner" | "Intermediate" | "Advanced";

export interface LessonSection {
  heading: string;
  body: string;
}

export interface ChartIdTask {
  type: "chart-id";
  seed: number;
  count: number;
  startPrice: number;
  symbol: string;
  pattern:
    | "bullish-engulfing"
    | "bearish-engulfing"
    | "doji"
    | "hammer"
    | "support"
    | "resistance"
    | "uptrend"
    | "downtrend";
  instruction: string;
  success: string;
  failHint: string;
}

export interface QuizTask {
  type: "quiz";
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}

export interface Lesson {
  id: string;
  title: string;
  level: Level;
  category: string;
  duration: number; // minutes
  xp: number;
  icon: string; // lucide icon name
  blurb: string;
  sections: LessonSection[];
  keyPoints: string[];
  task: ChartIdTask | QuizTask;
  finalQuiz: {
    question: string;
    options: string[];
    answer: number;
    explanation: string;
  };
}

export const LESSONS: Lesson[] = [
  {
    id: "market-basics",
    title: "Market Basics: How Markets Work",
    level: "Beginner",
    category: "Foundations",
    duration: 8,
    xp: 40,
    icon: "LineChart",
    blurb: "Understand buyers, sellers, price discovery, and what moves markets.",
    sections: [
      {
        heading: "What is a market?",
        body: "A market is where buyers and sellers exchange assets. Prices are set by the constant negotiation between bids (buyers) and asks (sellers). When aggressive buyers lift the ask, price rises; when aggressive sellers hit the bid, price falls.",
      },
      {
        heading: "Price discovery",
        body: "Price discovery is the ongoing process by which the market finds the fair value of an asset based on incoming information, order flow, and participant psychology. Every candle on a chart is a snapshot of that negotiation over a time period.",
      },
      {
        heading: "What moves price?",
        body: "Price moves on the balance of supply and demand, driven by news, earnings, macro data, institutional flows, and sentiment. As a trader, your job is not to predict the news but to react responsibly to the price action it produces.",
      },
    ],
    keyPoints: [
      "Markets are auctions — price is set by bids and asks.",
      "Every candle is a record of negotiated value over time.",
      "You trade the price, not the news.",
    ],
    task: {
      type: "quiz",
      question:
        "If aggressive buyers keep lifting the ask while sellers pull their offers, what is most likely happening to price?",
      options: [
        "Price is falling sharply",
        "Price is rising",
        "Price is frozen",
        "Price becomes random",
      ],
      answer: 1,
      explanation:
        "When buyers lift the ask and sellers withdraw, demand overwhelms supply, pushing price higher.",
    },
    finalQuiz: {
      question: "Which best describes price discovery?",
      options: [
        "A government setting the official price",
        "The market continuously finding fair value through order flow",
        "A trader's personal prediction",
        "The opening price of the day",
      ],
      answer: 1,
      explanation:
        "Price discovery is the live, continuous process of finding fair value via bids, asks, and executed trades.",
    },
  },
  {
    id: "candlesticks",
    title: "Reading Candlesticks",
    level: "Beginner",
    category: "Price Action",
    duration: 10,
    xp: 50,
    icon: "CandlestickChart",
    blurb: "Decode the four data points of every candle and what their shapes reveal.",
    sections: [
      {
        heading: "Anatomy of a candle",
        body: "Each candle shows four prices for a period: Open, High, Low, Close. The body is drawn between open and close. The wicks (shadows) stretch to the high and low. A green candle closed higher than it opened (bullish); a red candle closed lower (bearish).",
      },
      {
        heading: "Bullish engulfing",
        body: "A bullish engulfing pattern occurs when a small bearish candle is followed by a larger bullish candle whose body completely covers (engulfs) the previous body. It signals a shift of control from sellers to buyers, especially when it appears at support with rising volume.",
      },
      {
        heading: "Context matters",
        body: "No candle tells a story alone. A hammer at the top of an uptrend means little; the same hammer at support after a pullback can mark a reversal. Always read candles in the context of trend, location, and volume.",
      },
    ],
    keyPoints: [
      "OHLC = Open, High, Low, Close.",
      "Body shows conviction; wicks show rejection.",
      "Patterns only matter in context.",
    ],
    task: {
      type: "chart-id",
      seed: 7781,
      count: 80,
      startPrice: 1500,
      symbol: "HDFCBANK",
      pattern: "bullish-engulfing",
      instruction:
        "Click on the candle that completes a Bullish Engulfing pattern (the bullish candle that engulfs the prior bearish body).",
      success:
        "Correct! That bullish candle fully engulfs the prior bearish body — a classic shift of control to buyers.",
      failHint:
        "Not quite. Look for a small red candle immediately followed by a taller green candle whose body covers the red one.",
    },
    finalQuiz: {
      question:
        "A bullish engulfing pattern is most reliable when it appears:",
      options: [
        "At the top of an extended uptrend",
        "In the middle of a wide, directionless range",
        "At support after a pullback, with volume confirmation",
        "Right after a huge gap up",
      ],
      answer: 2,
      explanation:
        "At support with volume, a bullish engulfing shows buyers stepping in aggressively where sellers failed — high-quality signal.",
    },
  },
  {
    id: "support-resistance",
    title: "Support & Resistance",
    level: "Beginner",
    category: "Structure",
    duration: 9,
    xp: 50,
    icon: "Anchor",
    blurb: "Learn the floors and ceilings that price respects again and again.",
    sections: [
      {
        heading: "What is support?",
        body: "Support is a price level where buying interest is strong enough to overcome selling pressure, halting a decline. Think of it as a floor. Each time price touches and bounces, the level is reinforced.",
      },
      {
        heading: "What is resistance?",
        body: "Resistance is a ceiling where selling pressure overcomes buying, capping a rally. Broken resistance often becomes new support, and broken support often becomes new resistance — this is called role reversal.",
      },
      {
        heading: "How to draw them",
        body: "Mark levels where price has reversed at least twice, clustering touches by proximity. The more touches and the longer the timeframe, the more significant the level. Horizontal levels are stronger than diagonal trendlines.",
      },
    ],
    keyPoints: [
      "Support = floor, Resistance = ceiling.",
      "Need at least two touches to validate a level.",
      "Broken levels flip roles.",
    ],
    task: {
      type: "chart-id",
      seed: 4456,
      count: 90,
      startPrice: 22000,
      symbol: "NIFTY50",
      pattern: "support",
      instruction:
        "Click on a candle low that marks a valid SUPPORT level (a price where price bounced multiple times).",
      success:
        "Yes — that swing low aligns with prior bounces. Price respected that floor repeatedly.",
      failHint:
        "Look for a horizontal zone where price made a low and bounced — not a single random dip.",
    },
    finalQuiz: {
      question: "When resistance is broken decisively, it often becomes:",
      options: [
        "Stronger resistance",
        "New support",
        "Irrelevant forever",
        "A trendline",
      ],
      answer: 1,
      explanation:
        "Role reversal: once buyers reclaim resistance, that level tends to act as support on retests.",
    },
  },
  {
    id: "trend-analysis",
    title: "Trend Analysis: The Trader's Edge",
    level: "Beginner",
    category: "Structure",
    duration: 9,
    xp: 55,
    icon: "TrendingUp",
    blurb: "Identify trend direction and trade with it, not against it.",
    sections: [
      {
        heading: "The trend is your friend",
        body: "An uptrend is a series of higher highs and higher lows. A downtrend is lower highs and lower lows. A range is sideways. Trading with the trend puts the statistical wind at your back; fighting it is where most beginners bleed.",
      },
      {
        heading: "Higher highs & higher lows",
        body: "In an uptrend, each pullback holds above the prior low, and each rally makes a new high. As long as this structure holds, the uptrend is intact. The moment a lower low prints, the trend may be reversing.",
      },
      {
        heading: "Trendlines & slope",
        body: "An uptrend line connects rising lows; a downtrend line connects falling highs. The steepness reflects momentum — too steep and the trend is unsustainable, too flat and there may be no trend at all.",
      },
    ],
    keyPoints: [
      "Uptrend = HH/HL. Downtrend = LH/LL.",
      "Trade in the trend's direction.",
      "Broken structure = early warning of reversal.",
    ],
    task: {
      type: "chart-id",
      seed: 9211,
      count: 80,
      startPrice: 2850,
      symbol: "RELIANCE",
      pattern: "uptrend",
      instruction:
        "This chart is in a clear trend. Click near the most recent higher low (a pullback that holds above the prior low) in the uptrend.",
      success:
        "Correct — that's a higher low. The structure of HH/HL confirms the uptrend.",
      failHint:
        "Find a swing low in the latter part of the chart that sits above the previous swing low.",
    },
    finalQuiz: {
      question:
        "An uptrend officially remains intact as long as price makes:",
      options: [
        "Random spikes",
        "Higher highs and higher lows",
        "Lower highs",
        "Flat closes",
      ],
      answer: 1,
      explanation:
        "The HH/HL sequence defines an uptrend. A break of the last higher low is the first failure signal.",
    },
  },
  {
    id: "volume",
    title: "Volume: The Truth Teller",
    level: "Beginner",
    category: "Foundations",
    duration: 8,
    xp: 45,
    icon: "BarChart3",
    blurb: "Volume confirms conviction behind every move.",
    sections: [
      {
        heading: "What volume tells you",
        body: "Volume is the number of shares/contracts traded in a period. High volume = strong conviction; low volume = weak participation. A breakout on heavy volume is far more trustworthy than one on thin volume.",
      },
      {
        heading: "Volume confirms breakouts",
        body: "When price breaks resistance, you want to see volume expand — ideally 1.5–2x the average. A breakout on declining volume is suspicious and often fails, trapping late buyers.",
      },
      {
        heading: "Climax volume",
        body: "An enormous volume spike after a long move can signal exhaustion — a blow-off top or capitulation bottom. It often marks the end, not the beginning, of a move.",
      },
    ],
    keyPoints: [
      "Volume = conviction.",
      "Real breakouts need expanding volume.",
      "Climax volume can mark exhaustion.",
    ],
    task: {
      type: "quiz",
      question:
        "Price breaks above resistance, but volume is 40% below average. The most prudent interpretation is:",
      options: [
        "A confirmed breakout — buy immediately",
        "A low-conviction breakout — wait for a retest or volume confirmation",
        "A sell signal",
        "Volume is irrelevant",
      ],
      answer: 1,
      explanation:
        "Low-volume breakouts lack conviction and fail often. Waiting for a retest with volume is the disciplined choice.",
    },
    finalQuiz: {
      question: "A massive volume spike after a long uptrend usually suggests:",
      options: [
        "The start of an even bigger rally",
        "Possible exhaustion / blow-off top",
        "A guaranteed buy",
        "Nothing meaningful",
      ],
      answer: 1,
      explanation:
        "Climax volume after extended moves often marks exhaustion as the last buyers pile in.",
    },
  },
  {
    id: "risk-management",
    title: "Risk Management: Survival First",
    level: "Beginner",
    category: "Risk",
    duration: 11,
    xp: 70,
    icon: "ShieldCheck",
    blurb: "The single most important skill: protect your capital.",
    sections: [
      {
        heading: "The 1% rule",
        body: "Risk no more than 1% of your account on a single trade. With ₹1,00,000, that's ₹1,000 of risk — the amount you'd lose if your stop is hit. This lets you survive long losing streaks (statistically inevitable) without ruin.",
      },
      {
        heading: "Position sizing",
        body: "Position size = Risk Amount ÷ (Entry − Stop). If you risk ₹1,000 and your stop is ₹2 below entry, you can buy 500 shares. Size adapts to the stop distance, not the other way around — this is the #1 mistake beginners make.",
      },
      {
        heading: "Risk-to-reward",
        body: "Always know your R:R before entering. A 1:2 ratio means you risk ₹1 to make ₹2. With a 1:2 R:R, you can be wrong 60% of the time and still not lose money. Predetermine your stop and target — never improvise risk.",
      },
    ],
    keyPoints: [
      "Risk ≤ 1% per trade.",
      "Size = Risk ÷ Stop distance.",
      "Predetermine R:R before entry.",
    ],
    task: {
      type: "quiz",
      question:
        "Account = ₹1,00,000. You buy at ₹100 with a stop at ₹98. Using the 1% rule, what's the correct position size?",
      options: ["1,000 shares", "2,500 shares", "500 shares", "5,000 shares"],
      answer: 2,
      explanation:
        "1% of ₹1,00,000 = ₹1,000 risk. Stop distance = ₹100 − ₹98 = ₹2. Size = ₹1,000 ÷ ₹2 = 500 shares. Always size to the stop, not to gut feel.",
    },
    finalQuiz: {
      question: "With a 1:2 risk-to-reward ratio, your break-even win rate is:",
      options: ["50%", "33.3%", "66.7%", "25%"],
      answer: 1,
      explanation:
        "Risking 1 to make 2: you break even winning 1 of every 3 trades (33.3%). Anything above that is profit.",
    },
  },
  {
    id: "breakouts",
    title: "Breakout Trading",
    level: "Intermediate",
    category: "Price Action",
    duration: 10,
    xp: 75,
    icon: "Zap",
    blurb: "Catch explosive moves as price escapes a range.",
    sections: [
      {
        heading: "What is a breakout?",
        body: "A breakout is price moving decisively beyond a support or resistance level, often accompanied by a surge in volume. It signals that the balance of power has shifted and a new leg may be beginning.",
      },
      {
        heading: "Confirmation is everything",
        body: "Many breakouts fail — these are 'fakeouts' designed to trap amateurs. Confirm with: (1) a decisive candle close beyond the level, (2) volume expansion, and (3) ideally a retest of the broken level as new support/resistance before adding size.",
      },
      {
        heading: "Entry tactics",
        body: "Aggressive: enter on the breakout candle. Balanced: enter on the retest. Conservative: enter only after a successful retest holds. The retest entry offers the best R:R and the clearest invalidation (the retest fails).",
      },
    ],
    keyPoints: [
      "Breakout = level broken with conviction.",
      "Confirm with close + volume + retest.",
      "Retest entry = best R:R.",
    ],
    task: {
      type: "chart-id",
      seed: 3390,
      count: 90,
      startPrice: 1480,
      symbol: "INFY",
      pattern: "resistance",
      instruction:
        "Click on a candle high that marks a valid RESISTANCE level (a ceiling price tested multiple times).",
      success:
        "Correct — that swing high defines resistance. A decisive close above it would be a breakout.",
      failHint:
        "Find a horizontal ceiling where price was rejected more than once.",
    },
    finalQuiz: {
      question: "The highest-probability breakout entry is typically:",
      options: [
        "Buying the moment price touches the level",
        "Buying the retest of the broken level after confirmation",
        "Buying at the very top of the breakout candle",
        "Buying randomly",
      ],
      answer: 1,
      explanation:
        "Waiting for a successful retest confirms the breakout is real and offers a tight, logical stop.",
    },
  },
  {
    id: "pullbacks",
    title: "Pullbacks & Continuation",
    level: "Intermediate",
    category: "Price Action",
    duration: 9,
    xp: 70,
    icon: "Waves",
    blurb: "Enter trends on the pullback, not the chase.",
    sections: [
      {
        heading: "Why pullbacks matter",
        body: "Trends don't move in straight lines; they advance in impulses and retrace in pullbacks. Buying the pullback (rather than chasing the breakout) gives you a better entry, a tighter stop, and a superior R:R.",
      },
      {
        heading: "Where to buy",
        body: "In an uptrend, look for pullbacks to prior resistance turned support, a moving average (20/50 EMA), or a 38.2%–61.8% Fibonacci retracement. The deeper the pullback in a strong trend, the better the value — but watch for trend structure breaking.",
      },
      {
        heading: "Confirmation trigger",
        body: "Don't catch a falling knife. Wait for the pullback to stall — a bullish reversal candle (hammer, engulfing) at your zone — then enter. Your stop goes just below the pullback low.",
      },
    ],
    keyPoints: [
      "Buy pullbacks, not breakouts (for trend continuation).",
      "Use prior structure, MAs, or Fibonacci as zones.",
      "Wait for a reversal candle to trigger entry.",
    ],
    task: {
      type: "quiz",
      question:
        "In a strong uptrend, price pulls back to the 50 EMA and forms a hammer. The disciplined action is:",
      options: [
        "Short because it might reverse",
        "Wait for a bearish candle",
        "Enter long with a stop below the hammer low",
        "Do nothing — trends never pull back",
      ],
      answer: 2,
      explanation:
        "A hammer at a logical pullback zone in an uptrend is a classic continuation trigger. Enter long with risk defined below the hammer.",
    },
    finalQuiz: {
      question: "Buying a pullback instead of chasing the breakout mainly improves:",
      options: [
        "Your commission costs",
        "Your entry price, stop tightness, and R:R",
        "Your win rate to 100%",
        "Nothing",
      ],
      answer: 1,
      explanation:
        "Better entry + tighter stop + larger target = superior risk-to-reward, the core of pullback trading.",
    },
  },
  {
    id: "market-structure",
    title: "Market Structure & Shifts",
    level: "Intermediate",
    category: "Structure",
    duration: 10,
    xp: 75,
    icon: "Network",
    blurb: "Read the skeleton of the market: BOS, CHoCH, and liquidity.",
    sections: [
      {
        heading: "Structure defined",
        body: "Market structure is the sequence of highs and lows. In an uptrend: higher highs (HH) and higher lows (HL). A Break of Structure (BOS) — a new HH — confirms continuation. A Change of Character (CHoCH) — the first lower low — warns of reversal.",
      },
      {
        heading: "Liquidity",
        body: "Obvious swing highs and lows pool stop orders — this is 'liquidity'. Smart money often pushes price beyond these levels to trigger stops before reversing. A 'liquidity sweep' (a wick beyond a key level that snaps back) is a powerful reversal signal.",
      },
      {
        heading: "Trading structure",
        body: "Trade in the direction of the prevailing structure. Enter after a BOS in trend direction on the pullback. Become cautious after a CHoCH. Never assume reversal on a single candle — wait for structure to confirm.",
      },
    ],
    keyPoints: [
      "BOS = continuation. CHoCH = early reversal warning.",
      "Obvious levels attract stop liquidity.",
      "Confirm reversals with structure, not feelings.",
    ],
    task: {
      type: "chart-id",
      seed: 6061,
      count: 90,
      startPrice: 3650,
      symbol: "TCS",
      pattern: "downtrend",
      instruction:
        "This chart is trending down. Click near the most recent lower high (a rally peak that sits below the prior peak).",
      success:
        "Correct — that lower high confirms the downtrend structure (LH/LL).",
      failHint:
        "Find a recent swing high that is lower than the previous swing high.",
    },
    finalQuiz: {
      question: "Price breaks the last higher low in an uptrend. This is best described as:",
      options: [
        "A Break of Structure (continuation)",
        "A Change of Character (reversal warning)",
        "A sideways range",
        "Meaningless",
      ],
      answer: 1,
      explanation:
        "Breaking the last higher low is the first lower low — a CHoCH that warns the uptrend may be failing.",
    },
  },
  {
    id: "trading-psychology",
    title: "Trading Psychology: Mastering Yourself",
    level: "Advanced",
    category: "Psychology",
    duration: 11,
    xp: 85,
    icon: "Brain",
    blurb: "Your biggest opponent isn't the market — it's you.",
    sections: [
      {
        heading: "The emotional trap",
        body: "Fear, greed, FOMO, and revenge drive most retail losses. After a loss, the urge to 'win it back' leads to oversized positions and broken rules. After a win, overconfidence leads to the same. Discipline is a skill, not a personality trait.",
      },
      {
        heading: "Process over outcome",
        body: "You cannot control whether any single trade wins. You can control: your setup, your risk, your stop, your plan. Judge yourself on whether you followed your process — not on the P&L of the last trade. A good loss (followed plan) beats a bad win (broke rules).",
      },
      {
        heading: "The daily loss limit",
        body: "Set a hard daily loss limit (e.g., 2% of account). Hit it, and you stop for the day — no exceptions. This single rule prevents the death spiral of revenge trading that destroys most accounts.",
      },
    ],
    keyPoints: [
      "Emotions drive 90% of retail losses.",
      "Judge the process, not the outcome.",
      "A daily loss limit saves accounts.",
    ],
    task: {
      type: "quiz",
      question:
        "You've lost 3 trades in a row and feel an urge to double your position size to recover. This is:",
      options: [
        "A rational adjustment",
        "Revenge trading — a discipline breach",
        "Required to stay profitable",
        "A sign of a good setup",
      ],
      answer: 1,
      explanation:
        "Increasing size after losses to 'win it back' is the textbook definition of revenge trading. Hold size constant; respect your plan.",
    },
    finalQuiz: {
      question: "The healthiest way to evaluate a trade after it closes is to ask:",
      options: [
        "Did it make money?",
        "Did I follow my process and rules?",
        "Was I lucky?",
        "Should I have gone bigger?",
      ],
      answer: 1,
      explanation:
        "Process-based evaluation builds the consistency that produces long-term results. Outcome-focused evaluation breeds emotional trading.",
    },
  },
  {
    id: "multi-timeframe",
    title: "Multi-Timeframe Analysis",
    level: "Advanced",
    category: "Strategy",
    duration: 10,
    xp: 80,
    icon: "Layers",
    blurb: "Align the big picture with your entry for higher-probability trades.",
    sections: [
      {
        heading: "Top-down analysis",
        body: "Start on a higher timeframe (daily) for trend and key levels, drop to a mid timeframe (1H) for structure, then to a low timeframe (5m) for precise entry. This 'rule of three' keeps you on the side of the dominant trend with surgical entries.",
      },
      {
        heading: "Trend alignment",
        body: "If the daily is bullish, look only for longs on the lower timeframes. Trading against the higher timeframe trend is like swimming upstream — possible, but exhausting and low-probability.",
      },
      {
        heading: "Level confluence",
        body: "When a daily support, a 1H structure level, and a 5m reversal candle all align, you have confluence — and confluence is where the best trades live. The more reasons to take a trade, the higher its quality.",
      },
    ],
    keyPoints: [
      "Top-down: Daily → 1H → 5m.",
      "Trade only with the higher-timeframe trend.",
      "Confluence = higher probability.",
    ],
    task: {
      type: "quiz",
      question:
        "The daily chart is in a downtrend, but the 5m shows a bullish breakout. The disciplined action is:",
      options: [
        "Buy the 5m breakout — momentum is up",
        "Skip it — counter-trend trades are low probability",
        "Short the 5m breakout failure instead",
        "Both A and C are equally good",
      ],
      answer: 1,
      explanation:
        "Trading against the higher timeframe trend stacks the odds against you. Patience for a with-trend setup is the professional choice.",
    },
    finalQuiz: {
      question: "Multi-timeframe confluence primarily improves:",
      options: [
        "Your commission rate",
        "Trade probability through aligned evidence",
        "Your chart count",
        "Nothing measurable",
      ],
      answer: 1,
      explanation:
        "Stacking evidence across timeframes raises the probability of each trade — the core of professional analysis.",
    },
  },
];

// ---------------------------------------------------------------------------
// Mission-based Trading Rooms.
// ---------------------------------------------------------------------------

export interface RoomObjective {
  id: string;
  label: string;
  hint?: string;
}

export interface Room {
  id: string;
  title: string;
  level: Level;
  blurb: string;
  xp: number;
  symbol: string;
  seed: number;
  count: number;
  startPrice: number;
  objectives: RoomObjective[];
  briefing: string;
  successFeedback: string;
}

export const ROOMS: Room[] = [
  {
    id: "room-sr",
    title: "Support & Resistance Lab",
    level: "Beginner",
    blurb: "Map the key levels price respects.",
    xp: 120,
    symbol: "NIFTY50",
    seed: 7123,
    count: 120,
    startPrice: 22000,
    objectives: [
      { id: "s1", label: "Identify 1 major support zone", hint: "Click the low where price bounced repeatedly." },
      { id: "s2", label: "Identify a 2nd support zone", hint: "Find another respected floor." },
      { id: "r1", label: "Identify 1 major resistance zone", hint: "Click the high where price was rejected." },
      { id: "r2", label: "Identify a 2nd resistance zone", hint: "Find another ceiling." },
    ],
    briefing:
      "Map the battlefield. Support and resistance are the levels where price is most likely to react. Identify the strongest zones on this NIFTY chart.",
    successFeedback:
      "Excellent structural mapping. You can now plan entries at support and exits at resistance — the foundation of every strategy.",
  },
  {
    id: "room-trend",
    title: "Trend Trading Room",
    level: "Beginner",
    blurb: "Define trend, entry, stop, and target.",
    xp: 140,
    symbol: "RELIANCE",
    seed: 8841,
    count: 120,
    startPrice: 2850,
    objectives: [
      { id: "dir", label: "Determine trend direction", hint: "Up, down, or range?" },
      { id: "entry", label: "Mark your entry point", hint: "Click the candle where you'd enter." },
      { id: "sl", label: "Set your stop loss level", hint: "Below the pullback low (longs)." },
      { id: "tp", label: "Set your profit target", hint: "Next resistance or 2R." },
    ],
    briefing:
      "Trade with the trend. Determine direction, then place a logical entry, a stop that proves you wrong, and a target that rewards your risk.",
    successFeedback:
      "Clean trend trade. You defined direction, entered on structure, and managed risk — exactly how professionals operate.",
  },
  {
    id: "room-risk",
    title: "Risk Management Challenge",
    level: "Intermediate",
    blurb: "Keep risk ≤ 1% across a sequence of trades.",
    xp: 160,
    symbol: "TCS",
    seed: 5532,
    count: 120,
    startPrice: 3650,
    objectives: [
      { id: "size", label: "Calculate position size for a 1% risk", hint: "Size = Risk ÷ Stop distance." },
      { id: "stop", label: "Place a valid stop loss", hint: "At structure, not arbitrary." },
      { id: "rr", label: "Achieve at least 1:2 R:R", hint: "Target must be 2× your risk." },
      { id: "dd", label: "Keep simulated drawdown under 5%", hint: "Don't overtrade." },
    ],
    briefing:
      "Capital preservation is the supreme skill. Plan a trade that risks ≤ 1% of a ₹1,00,000 account, with a structural stop and a 1:2+ target.",
    successFeedback:
      "Textbook risk management. This discipline, repeated over hundreds of trades, is what separates survivors from statistics.",
  },
  {
    id: "room-breakout",
    title: "Breakout Trading Room",
    level: "Intermediate",
    blurb: "Detect, confirm, and execute a breakout.",
    xp: 150,
    symbol: "INFY",
    seed: 3390,
    count: 120,
    startPrice: 1480,
    objectives: [
      { id: "level", label: "Identify the breakout level", hint: "Resistance that's been tested." },
      { id: "confirm", label: "Confirm with volume", hint: "Click the high-volume breakout candle." },
      { id: "entry", label: "Execute the entry", hint: "On breakout or retest." },
      { id: "manage", label: "Set stop & target", hint: "Stop below broken level, target 2R." },
    ],
    briefing:
      "Catch the explosion. Identify the level, wait for volume confirmation, execute, and manage the trade with defined risk.",
    successFeedback:
      "You traded the breakout with confirmation and managed risk — the difference between catching a move and getting faked out.",
  },
];

// ---------------------------------------------------------------------------
// Scenario Trainer — "What would you do?" market events.
// ---------------------------------------------------------------------------

export interface ScenarioChoice {
  id: string;
  label: string;
  tag: "Buy" | "Sell" | "Wait";
}

export interface Scenario {
  id: string;
  title: string;
  category: string;
  blurb: string;
  setup: string;
  choices: ScenarioChoice[];
  bestChoice: string;
  proReasoning: string;
}

export const SCENARIOS: Scenario[] = [
  {
    id: "sc-cpi",
    title: "Hot CPI Release",
    category: "Macro Event",
    blurb: "Inflation prints above expectations. How do you react?",
    setup:
      "You're long NIFTY futures from the morning open. At 2:00 PM, CPI prints 6.4% vs 6.1% expected — a hot surprise. The index instantly drops 1.2% in a minute with spiking volume. Your position is now at your stop. What do you do?",
    choices: [
      { id: "hold", label: "Hold and hope it recovers — it's just a spike", tag: "Wait" },
      { id: "exit", label: "Exit at the stop immediately — the thesis is broken", tag: "Sell" },
      { id: "add", label: "Add to the long — averaging down is smart", tag: "Buy" },
    ],
    bestChoice: "exit",
    proReasoning:
      "Professionals honor stops, especially around high-impact news. A hot CPI fundamentally shifts the rate-hike narrative against equities. Hoping for recovery is emotional; honoring a pre-defined stop is process. Re-evaluate from the sidelines with a clear head — you can always re-enter a new setup.",
  },
  {
    id: "sc-breakout",
    title: "Low-Volume Breakout",
    category: "Technical",
    blurb: "Resistance breaks — but volume is missing.",
    setup:
      "INFY breaks above 1,520 resistance for the first time in 3 weeks. It looks exciting — but volume on the breakout candle is 30% below the 20-day average, and the candle has a long upper wick. You have no position. What do you do?",
    choices: [
      { id: "chase", label: "Buy the breakout now before you miss it", tag: "Buy" },
      { id: "wait", label: "Wait for a retest of 1,520 with volume to enter", tag: "Wait" },
      { id: "short", label: "Short immediately — it's a fakeout", tag: "Sell" },
    ],
    bestChoice: "wait",
    proReasoning:
      "A breakout on declining volume with a rejection wick is a classic fakeout trap. Professionals wait for confirmation: a successful retest of the broken level as support, ideally with volume expansion. The retest also offers a far tighter stop and superior R:R. Patience here protects capital and improves the entry.",
  },
  {
    id: "sc-crash",
    title: "Sudden Flash Crash",
    category: "Volatility Event",
    blurb: "The market drops 4% in 10 minutes. Your move?",
    setup:
      "A sudden flash crash sends the index down 4% in 10 minutes on no obvious news. VIX spikes 60%. You have a watchlist of strong names now down 6-8%. You have full buying power. What do you do?",
    choices: [
      { id: "allin", label: "Go all-in on your watchlist — generational discount", tag: "Buy" },
      { id: "scale", label: "Scale in slowly with 25% of power, keep powder dry", tag: "Buy" },
      { id: "flee", label: "Sell everything and hide — it's a crash", tag: "Sell" },
    ],
    bestChoice: "scale",
    proReasoning:
      "Flash crashes are volatility events, not investment theses. Professionals scale in gradually rather than going all-in, because crashes can overshoot violently. Keeping dry powder lets you average down if it extends and removes the emotional burden of a single mistimed entry. Going all-in removes optionality; fleeing locks in losses on quality names. Sized, staged entries balance opportunity with risk.",
  },
  {
    id: "sc-earnings",
    title: "Pre-Earnings Position",
    category: "Earnings",
    blurb: "Earnings tomorrow. Hold or flatten?",
    setup:
      "You hold a 2R winning long in RELIANCE. Earnings report drops tomorrow morning before open. The stock has a history of 5-7% post-earnings gaps in both directions. Your profit is unrealized. What do you do?",
    choices: [
      { id: "ride", label: "Hold through earnings — let it run", tag: "Wait" },
      { id: "take", label: "Take most of the profit, trim to a runner", tag: "Sell" },
      { id: "flip", label: "Add to the position — momentum is strong", tag: "Buy" },
    ],
    bestChoice: "take",
    proReasoning:
      "Earnings are pure binary risk — a coin flip on gap direction that can wipe a 2R gain instantly. Professionals de-risk: take most of the profit off the table to lock in the win, and let a small runner ride with a trailing stop. This converts a binary gamble into a freeroll on the upside while protecting capital. Adding into earnings is gambling, not trading.",
  },
  {
    id: "sc-fomo",
    title: "The Parabolic Runner",
    category: "Psychology",
    blurb: "A stock you ditched is up 40% in 2 days.",
    setup:
      "You sold a stock for a small profit 2 days ago. It has since ripped 40% with no pullback and is now parabolic. Everyone on social media is posting gains. You feel intense FOMO. What do you do?",
    choices: [
      { id: "chase", label: "Buy now — it's clearly going to the moon", tag: "Buy" },
      { id: "plan", label: "Wait for a pullback to a logical level, then assess", tag: "Wait" },
      { id: "short", label: "Short it — parabolas always crash", tag: "Sell" },
    ],
    bestChoice: "plan",
    proReasoning:
      "Chasing a parabolic move is how accounts blow up — the reversal is usually as violent as the rally. The fact that you already sold is irrelevant to the current setup; sunk-cost and envy are not edges. Professionals wait for the parabola to exhaust and pull back to a level, then assess a new, lower-risk entry. Discipline here is what separates traders from gamblers.",
  },
];

// ---------------------------------------------------------------------------
// Trading Psychology Simulator scenarios.
// ---------------------------------------------------------------------------

export interface PsychChoice {
  id: string;
  label: string;
  discipline: number; // -2..+2 effect on discipline score
  tag: "disciplined" | "neutral" | "impulsive";
}

export interface PsychScenario {
  id: string;
  title: string;
  blurb: string;
  situation: string;
  emotionalTrigger: string;
  choices: PsychChoice[];
  reflection: string;
}

export const PSYCH_SCENARIOS: PsychScenario[] = [
  {
    id: "psy-loss-streak",
    title: "Three Losses In A Row",
    blurb: "The urge to 'win it back' is rising.",
    situation:
      "You've just taken your third consecutive loss following your plan perfectly. Your account is down 2.8% on the day. The next setup triggers — a slightly lower-quality one. You feel heat in your chest and an urge to double your size to recover.",
    emotionalTrigger: "Revenge trading, loss aversion, ego",
    choices: [
      { id: "double", label: "Double the size — recover fast", discipline: -2, tag: "impulsive" },
      { id: "skip", label: "Skip the lower-quality setup, stop for the day", discipline: 2, tag: "disciplined" },
      { id: "normal", label: "Take it at normal size, it's still a valid setup", discipline: 0, tag: "neutral" },
    ],
    reflection:
      "Revenge trading — increasing size after losses to recover — is the #1 account killer. Skipping a lower-quality setup after a losing streak is a sign of maturity, not weakness. Your daily loss limit exists precisely for this moment.",
  },
  {
    id: "psy-fomo",
    title: "The Missed Moonshot",
    blurb: "FOMO is whispering in your ear.",
    situation:
      "A stock you researched but didn't buy just gap-up 18% and keeps climbing. Friends are messaging you about it. You have FOMO and feel like you 'lost' money by not buying. You're hovering over the buy button.",
    emotionalTrigger: "FOMO, envy, imagined loss",
    choices: [
      { id: "chase", label: "Buy now — don't miss any more upside", discipline: -2, tag: "impulsive" },
      { id: "wait", label: "Wait for a pullback and a real setup", discipline: 2, tag: "disciplined" },
      { id: "half", label: "Buy half now, half on pullback", discipline: -1, tag: "neutral" },
    ],
    reflection:
      "FOMO is not an edge. Money you didn't make is not money you lost. Chasing a parabolic gap exposes you to the inevitable mean reversion with terrible R:R. Waiting for structure is the professional response.",
  },
  {
    id: "psy-win-streak",
    title: "The Invincible Streak",
    blurb: "Overconfidence after wins.",
    situation:
      "You've won 6 trades in a row and are up 8% this week. You feel unstoppable. A marginal setup appears — one you'd normally skip. You're tempted to take it with 3x your normal size because you're 'in the zone'.",
    emotionalTrigger: "Overconfidence, greed, recency bias",
    choices: [
      { id: "big", label: "Size up 3x — ride the hot hand", discipline: -2, tag: "impulsive" },
      { id: "skip", label: "Skip it — quality over streak", discipline: 2, tag: "disciplined" },
      { id: "normal", label: "Take it at normal size", discipline: 0, tag: "neutral" },
    ],
    reflection:
      "Winning streaks breed the overconfidence that precedes the biggest drawdowns. Your edge doesn't improve because you've won recently — each trade is independent. Sizing up on a marginal setup converts a streak into a disaster waiting to happen.",
  },
  {
    id: "psy-early-profit",
    title: "The Itchy Exit",
    blurb: "Fear of giving back gains.",
    situation:
      "Your trade is up 1R, halfway to your 2R target. It pulls back slightly and you feel anxious it'll reverse. You're tempted to move your stop to breakeven and exit early to 'lock in' the win, against your plan to hold to 2R.",
    emotionalTrigger: "Fear, loss aversion, premature exit",
    choices: [
      { id: "exit", label: "Exit now — a bird in hand", discipline: -1, tag: "neutral" },
      { id: "be", label: "Move stop to breakeven and let it work", discipline: 0, tag: "neutral" },
      { id: "hold", label: "Hold to the 2R target as planned", discipline: 2, tag: "disciplined" },
    ],
    reflection:
      "Consistently cutting winners short destroys the R:R that makes a system profitable. If your plan says hold to 2R, hold — unless the trade thesis is invalidated. Fear-based exits train you to never let winners run, capping your edge permanently.",
  },
  {
    id: "psy-news",
    title: "The Panic Headline",
    blurb: "An unexpected news shock mid-trade.",
    situation:
      "You're long with a 1R risk. Breaking news hits that's bearish for your stock. Price instantly gaps down through your stop, now showing -2.5R. You're in shock and tempted to hold and 'wait for it to come back'.",
    emotionalTrigger: "Shock, denial, hope",
    choices: [
      { id: "hold", label: "Hold — it'll bounce back", discipline: -2, tag: "impulsive" },
      { id: "exit", label: "Exit immediately — the thesis is broken", discipline: 2, tag: "disciplined" },
      { id: "avg", label: "Average down — discount entry", discipline: -2, tag: "impulsive" },
    ],
    reflection:
      "When the thesis breaks, you exit — period. Hoping for a bounce is denial. The market doesn't care about your entry. Professionals take the loss and re-evaluate objectively. Averaging down into breaking news is how catastrophic losses happen.",
  },
];
