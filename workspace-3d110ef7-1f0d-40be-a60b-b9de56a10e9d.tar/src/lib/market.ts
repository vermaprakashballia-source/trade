// src/lib/market.ts
// Deterministic mock market-data engine for TradeHackMe AI.
// No external dependencies. Used by the candle chart, lesson replays,
// and any module that needs reproducible OHLCV data.

export interface Candle {
  time: number; // epoch ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// ---------------------------------------------------------------------------
// Seeded PRNG — Mulberry32. Deterministic by seed (same seed => same sequence).
// Returns a function producing floats in [0, 1).
// ---------------------------------------------------------------------------
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box–Muller transform: convert uniform [0,1) samples to a standard normal.
function gaussian(rand: () => number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rand();
  while (v === 0) v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const DAY_MS = 86_400_000;

interface GenerateOpts {
  volatility?: number; // per-candle vol as fraction of price (default 0.02)
  drift?: number; // per-candle trend bias (default 0)
  intervalMs?: number; // ms between candles (default 1 day)
  startTime?: number; // epoch ms of first candle (default = now - count*interval)
}

// ---------------------------------------------------------------------------
// generateSeries — realistic OHLCV via random walk with:
//   - volatility clustering (GARCH(1,1)-ish EWMA persistence + mean reversion)
//   - occasional vol spikes (news / events)
//   - tiny open gaps (occasionally larger)
//   - realistic wicks scaled by current volatility
//   - volume correlated with range, with extra juice on big moves & spikes
// Determinism: same seed => identical series. Critical for lesson replay.
// ---------------------------------------------------------------------------
export function generateSeries(
  seed: number,
  count: number,
  startPrice: number,
  opts?: GenerateOpts
): Candle[] {
  const volatility = opts?.volatility ?? 0.02;
  const drift = opts?.drift ?? 0;
  const intervalMs = opts?.intervalMs ?? DAY_MS;
  const startTime = opts?.startTime ?? Date.now() - count * intervalMs;

  const rand = mulberry32(seed);
  const out: Candle[] = [];

  if (count <= 0 || startPrice <= 0 || !isFinite(startPrice)) return out;

  let prevClose = startPrice;
  // Volatility state — persists yesterday's shock, mean-reverts to base vol.
  let volState = volatility;

  for (let i = 0; i < count; i++) {
    const shock = gaussian(rand); // ~ N(0, 1)

    // GARCH(1,1)-ish update: blend lagged variance with realized shock.
    const lambda = 0.92;
    const realized = Math.abs(shock) * volatility;
    volState = Math.sqrt(
      lambda * volState * volState + (1 - lambda) * realized * realized
    );
    // Mean-revert toward base volatility so vol doesn't blow up or die out.
    volState = volState * 0.94 + volatility * 0.06;
    // Occasional volatility spike (earnings, news, etc.).
    if (rand() < 0.04) volState *= 1.5 + rand() * 0.9;

    // Per-candle log-ish return.
    const ret = drift + volState * shock;

    // Open = prev close + tiny gap (occasionally larger gap).
    const gapScale = rand() < 0.06 ? 0.8 : 0.25;
    const gap = (rand() - 0.5) * volState * prevClose * gapScale;
    const open = Math.max(0.0001, prevClose + gap);

    const close = Math.max(0.0001, prevClose * (1 + ret));

    // Body & wick geometry.
    const bodyHigh = Math.max(open, close);
    const bodyLow = Math.min(open, close);
    const wickBudget = prevClose * volState * (0.6 + rand() * 0.9);
    const upWick = rand() * wickBudget;
    const dnWick = rand() * wickBudget;
    const high = bodyHigh + upWick;
    const low = Math.max(bodyLow * 0.5, bodyLow - dnWick); // never negative

    // Volume: baseline + correlated with range, occasional spikes.
    const baseVol = 1_000_000 + rand() * 600_000;
    const rangePct = (high - low) / prevClose;
    let volume = baseVol * (1 + rangePct * 60) + baseVol * rand() * 0.6;
    if (Math.abs(ret) > volState * 1.5) volume *= 1.6 + rand(); // big move => vol
    if (rand() < 0.05) volume *= 1.8 + rand() * 1.5; // random spike

    out.push({
      time: startTime + i * intervalMs,
      open: round2(open),
      high: round2(high),
      low: round2(low),
      close: round2(close),
      volume: Math.round(volume),
    });

    prevClose = close;
  }

  return out;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ---------------------------------------------------------------------------
// Formatting helpers.
// ---------------------------------------------------------------------------

// Format a price with 2 decimals, no currency symbol (e.g. "154.32").
export function fmtPrice(n: number): string {
  if (!isFinite(n)) return '—';
  return n.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

// Indian-style comma grouping for the integer part of a number string.
// Last 3 digits before decimal, then groups of 2 going left.
function indianGroup(intPart: string): string {
  if (intPart.length <= 3) return intPart;
  const last3 = intPart.slice(-3);
  const rest = intPart.slice(0, -3);
  const grouped = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return grouped + ',' + last3;
}

// ₹ with Indian grouping + 2 decimals (e.g. ₹1,00,000.00).
export function fmtINR(n: number): string {
  if (!isFinite(n)) return '₹—';
  const neg = n < 0;
  const abs = Math.abs(n);
  const intPart = Math.floor(abs);
  const frac = Math.round((abs - intPart) * 100);
  // Handle rounding overflow (e.g. 0.9995 -> 1.00).
  const intStr =
    frac >= 100
      ? indianGroup(String(intPart + 1))
      : indianGroup(String(intPart));
  const fracStr = String((frac + 100) % 100).padStart(2, '0');
  return (neg ? '-₹' : '₹') + intStr + '.' + fracStr;
}

// Trim to 1 decimal place, no trailing ".0".
function trim1(n: number): string {
  const v = Math.round(n * 10) / 10;
  return String(v);
}

// ₹ with L/Cr suffix for large amounts; K for thousands.
// Examples: ₹1.0L, ₹10.5L, ₹1.2Cr, ₹12.5K, ₹500.
export function fmtINRCompact(n: number): string {
  if (!isFinite(n)) return '₹—';
  const neg = n < 0;
  const abs = Math.abs(n);
  let s: string;
  if (abs >= 1e7) s = '₹' + trim1(abs / 1e7) + 'Cr';
  else if (abs >= 1e5) s = '₹' + trim1(abs / 1e5) + 'L';
  else if (abs >= 1e3) s = '₹' + trim1(abs / 1e3) + 'K';
  else s = '₹' + String(Math.round(abs));
  return neg ? '-' + s : s;
}

// Western compact number: 1.2K, 3.4M, 5.6B.
export function fmtCompact(n: number): string {
  if (!isFinite(n)) return '—';
  const neg = n < 0;
  const abs = Math.abs(n);
  let s: string;
  if (abs >= 1e9) s = trim1(abs / 1e9) + 'B';
  else if (abs >= 1e6) s = trim1(abs / 1e6) + 'M';
  else if (abs >= 1e3) s = trim1(abs / 1e3) + 'K';
  else s = String(Math.round(abs));
  return neg ? '-' + s : s;
}

// ---------------------------------------------------------------------------
// PnL / R-multiple helpers.
// ---------------------------------------------------------------------------

// Percentage PnL for a trade. Positive for winners, negative for losers.
export function pnlPct(
  entry: number,
  exit: number,
  side: 'LONG' | 'SHORT'
): number {
  if (entry === 0 || !isFinite(entry) || !isFinite(exit)) return 0;
  if (side === 'LONG') return ((exit - entry) / entry) * 100;
  return ((entry - exit) / entry) * 100;
}

// R-multiple = reward / risk. Returns 0 for invalid stop placement.
// LONG : risk = entry - stop  (stop below entry), reward = exit - entry
// SHORT: risk = stop - entry  (stop above entry), reward = entry - exit
export function rMultiple(
  entry: number,
  stop: number,
  exit: number,
  side: 'LONG' | 'SHORT'
): number {
  if (!isFinite(entry) || !isFinite(stop) || !isFinite(exit)) return 0;
  if (side === 'LONG') {
    const risk = entry - stop;
    if (risk <= 0) return 0;
    return (exit - entry) / risk;
  }
  const risk = stop - entry;
  if (risk <= 0) return 0;
  return (entry - exit) / risk;
}

// ---------------------------------------------------------------------------
// Seeded instruments used across the app. Distinct seed + startPrice each.
// Mix of indices, large-cap stocks, and a crypto-ish asset.
// ---------------------------------------------------------------------------
export const SYMBOLS: {
  symbol: string;
  name: string;
  seed: number;
  startPrice: number;
}[] = [
  { symbol: 'NIFTY50', name: 'Nifty 50 Index', seed: 101, startPrice: 22000 },
  { symbol: 'RELIANCE', name: 'Reliance Industries', seed: 202, startPrice: 2850 },
  { symbol: 'TCS', name: 'Tata Consultancy Services', seed: 303, startPrice: 3650 },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', seed: 404, startPrice: 1520 },
  { symbol: 'INFY', name: 'Infosys Ltd', seed: 505, startPrice: 1480 },
  { symbol: 'BTCUSD', name: 'Bitcoin / USD', seed: 606, startPrice: 42000 },
];
