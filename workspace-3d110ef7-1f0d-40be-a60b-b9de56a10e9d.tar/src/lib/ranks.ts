// Rank progression system for TradeHackMe AI.
// Inspired by TryHackMe. XP thresholds unlock ranks.

export interface RankDef {
  rank: number;
  name: string;
  minXp: number;
  blurb: string;
  color: string; // tailwind text color class
  accent: string; // hex for badges
  unlockables: string[];
}

export const RANKS: RankDef[] = [
  {
    rank: 1,
    name: "Beginner Trader",
    minXp: 0,
    blurb: "Just starting the journey. Learning the language of the markets.",
    color: "text-slate-300",
    accent: "#94a3b8",
    unlockables: ["Beginner Academy", "₹1,00,000 Sim Account", "Support & Resistance Room"],
  },
  {
    rank: 2,
    name: "Market Explorer",
    minXp: 300,
    blurb: "Comfortable navigating charts and reading price action.",
    color: "text-emerald-300",
    accent: "#6ee7b7",
    unlockables: ["Intermediate Academy", "Trade Replay Lab", "Trend Trading Room"],
  },
  {
    rank: 3,
    name: "Chart Analyst",
    minXp: 800,
    blurb: "Spots patterns and structure with growing confidence.",
    color: "text-teal-300",
    accent: "#5eead4",
    unlockables: ["AI Chart Analysis", "Breakout Trading Room", "Scenario Trainer"],
  },
  {
    rank: 4,
    name: "Risk Manager",
    minXp: 1500,
    blurb: "Capital preservation is now second nature.",
    color: "text-cyan-300",
    accent: "#67e8f9",
    unlockables: ["Risk Management Room", "Advanced Position Sizing", "Psychology Simulator"],
  },
  {
    rank: 5,
    name: "Swing Specialist",
    minXp: 2500,
    blurb: "Captures multi-day moves with discipline.",
    color: "text-lime-300",
    accent: "#bef264",
    unlockables: ["Swing Trading Track", "Advanced Replay Scenarios", "₹5,00,000 Sim Account"],
  },
  {
    rank: 6,
    name: "Elite Trader",
    minXp: 4000,
    blurb: "Consistently profitable. Edge is real.",
    color: "text-amber-300",
    accent: "#fcd34d",
    unlockables: ["Elite Challenges", "Advanced AI Mentor", "Portfolio Analytics"],
  },
  {
    rank: 7,
    name: "Professional Trader",
    minXp: 6500,
    blurb: "Trades like a pro — process over outcome.",
    color: "text-orange-300",
    accent: "#fdba74",
    unlockables: ["Pro Simulations", "Multi-Asset Rooms", "₹10,00,000 Sim Account"],
  },
  {
    rank: 8,
    name: "Quant Trader",
    minXp: 10000,
    blurb: "Thinks in probabilities, systems, and edges.",
    color: "text-fuchsia-300",
    accent: "#f0abfc",
    unlockables: ["Quant Track", "Algorithmic Trading Lessons", "Advanced Analytics"],
  },
  {
    rank: 9,
    name: "Master Trader",
    minXp: 15000,
    blurb: "Mastery. The market is a student of yours now.",
    color: "text-rose-300",
    accent: "#fda4af",
    unlockables: ["Master Certifications", "Mentor Others", "Exclusive Simulations"],
  },
];

export function rankForXp(xp: number): RankDef {
  let current = RANKS[0];
  for (const r of RANKS) {
    if (xp >= r.minXp) current = r;
  }
  return current;
}

export function nextRank(xp: number): RankDef | null {
  for (const r of RANKS) {
    if (r.minXp > xp) return r;
  }
  return null;
}

// Progress (0..1) from current rank to next rank.
export function rankProgress(xp: number): { pct: number; into: number; span: number } {
  const cur = rankForXp(xp);
  const nxt = nextRank(xp);
  if (!nxt) return { pct: 1, into: 0, span: 0 };
  const span = nxt.minXp - cur.minXp;
  const into = xp - cur.minXp;
  return { pct: Math.min(1, into / span), into, span };
}
