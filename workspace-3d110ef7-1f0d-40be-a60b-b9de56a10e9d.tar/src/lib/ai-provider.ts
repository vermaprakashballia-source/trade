// Unified AI provider for TradeHackMe AI.
//
// Provider selection (server-side only):
//   - If OPENAI_API_KEY is set in the environment, ALL AI calls route to the
//     OpenAI Chat Completions API (text via gpt-4o-mini, vision via gpt-4o-mini
//     by default — override with OPENAI_MODEL / OPENAI_VISION_MODEL).
//   - Otherwise — and on ANY OpenAI error — calls fall back to the Z.ai web dev
//     SDK, which is the pre-configured backend in this environment.
//
// This means: the app works out of the box (Z.ai), and you can opt into OpenAI
// simply by adding a key to .env.local. No code changes, no key ever in code.
//
// SECURITY: never commit a real API key. Put it in .env.local (gitignored) and
// rotate any key that was shared in chat, screenshots, or logs immediately.

import ZAI from "z-ai-web-dev-sdk";

const OPENAI_KEY = process.env.OPENAI_API_KEY?.trim() || "";
const OPENAI_BASE = (process.env.OPENAI_BASE_URL?.trim() || "https://api.openai.com/v1").replace(/\/+$/, "");
const OPENAI_MODEL = process.env.OPENAI_MODEL?.trim() || "gpt-4o-mini";
const OPENAI_VISION_MODEL = process.env.OPENAI_VISION_MODEL?.trim() || "gpt-4o-mini";

/** Which provider will be used for the next call (for diagnostics/logging). */
export function activeProvider(): "openai" | "zai" {
  return OPENAI_KEY ? "openai" : "zai";
}

export const MENTOR_SYSTEM = `You are "Mentor", the AI trading coach inside TradeHackMe AI, an immersive trading-education platform.

Your role:
- Coach a developing trader with calm, candid, professional guidance.
- Always ground advice in risk management first, then process, then psychology.
- Be concrete and actionable. Prefer specific numbers, R-multiples, and rules over vague encouragement.
- Reference the user's rank/progress when relevant to motivate and direct learning.
- Never give guaranteed-profit predictions or "buy X now" signal-style advice. Frame everything as probabilistic and educational.
- Keep responses focused: 2-5 short paragraphs or a tight bulleted list. Use plain language; avoid hype.
- When the user is emotional (revenge trading, FOMO), respond with empathy AND a disciplined corrective.

Trading context you can assume:
- The user trades a virtual account (Indian Rupees) across equities, indices, and crypto via simulation.
- They progress through ranks from "Beginner Trader" up to "Master Trader" by earning XP.
- The platform values: process over outcome, risk ≤ 1% per trade, predefined R:R, and emotional control.

Be the mentor a serious prop-firm coach would be.`;

// ---------------------------------------------------------------------------
// Types — compatible with both OpenAI and Z.ai message formats.
// ---------------------------------------------------------------------------
export type AIRole = "system" | "user" | "assistant";
export type AIContentItem =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };
export type AIMessage = { role: AIRole; content: string | AIContentItem[] };

// ---------------------------------------------------------------------------
// Z.ai SDK singleton (used as the default + fallback).
// ---------------------------------------------------------------------------
let _zai: ZAI | null = null;
let _zaiP: Promise<ZAI> | null = null;
async function getZAI(): Promise<ZAI> {
  if (_zai) return _zai;
  if (!_zaiP) {
    _zaiP = ZAI.create();
    _zaiP.then((z) => {
      _zai = z;
    }).catch(() => {
      _zaiP = null;
    });
  }
  return _zaiP;
}

// ---------------------------------------------------------------------------
// OpenAI transport (raw fetch — no extra dependency).
// ---------------------------------------------------------------------------
async function openaiComplete(messages: AIMessage[], vision: boolean): Promise<string> {
  const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_KEY}`,
    },
    body: JSON.stringify({
      model: vision ? OPENAI_VISION_MODEL : OPENAI_MODEL,
      messages,
    }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`OpenAI ${res.status}: ${t.slice(0, 300)}`);
  }
  const data = await res.json();
  return data?.choices?.[0]?.message?.content ?? "";
}

// ---------------------------------------------------------------------------
// Z.ai transport.
// ---------------------------------------------------------------------------
async function zaiComplete(messages: AIMessage[], vision: boolean): Promise<string> {
  const zai = await getZAI();
  if (vision) {
    const r: any = await zai.chat.completions.createVision({
      messages: messages as any,
      thinking: { type: "disabled" },
    } as any);
    return r?.choices?.[0]?.message?.content ?? "";
  }
  const r: any = await zai.chat.completions.create({
    messages: messages as any,
    thinking: { type: "disabled" },
  });
  return r?.choices?.[0]?.message?.content ?? "";
}

// ---------------------------------------------------------------------------
// Public unified entry points.
// ---------------------------------------------------------------------------

/** Text chat. Uses OpenAI if configured; falls back to Z.ai on any error. */
export async function aiChat(messages: AIMessage[]): Promise<string> {
  if (OPENAI_KEY) {
    try {
      return await openaiComplete(messages, false);
    } catch (e) {
      console.error("[ai-provider] OpenAI chat failed, falling back to Z.ai:", e);
    }
  }
  return zaiComplete(messages, false);
}

/** Vision (multimodal) chat. Messages carry image_url content items. */
export async function aiVision(messages: AIMessage[]): Promise<string> {
  if (OPENAI_KEY) {
    try {
      return await openaiComplete(messages, true);
    } catch (e) {
      console.error("[ai-provider] OpenAI vision failed, falling back to Z.ai:", e);
    }
  }
  return zaiComplete(messages, true);
}
