"use client";

import { useStore } from "@/store/use-store";
import type { Trade, LessonProgress } from "@/lib/types";

// Centralized client-side API helpers that hit the REST routes and refresh
// the relevant slices of the Zustand store.

export function useTraderApi() {
  const refreshTrader = useStore((s) => s.refreshTrader);
  const refreshTrades = useStore((s) => s.refreshTrades);
  const refreshProgress = useStore((s) => s.refreshProgress);
  const patchTrader = useStore((s) => s.patchTrader);

  return {
    async openTrade(input: {
      symbol: string;
      side: "LONG" | "SHORT";
      entry: number;
      size: number;
      stopLoss?: number;
      takeProfit?: number;
      context?: string;
      reason?: string;
    }): Promise<Trade | null> {
      try {
        const res = await fetch("/api/trades", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        if (!res.ok) return null;
        const trade = await res.json();
        await refreshTrades();
        return trade;
      } catch {
        return null;
      }
    },

    async closeTrade(
      id: string,
      exit: number
    ): Promise<{ trade: Trade; aiFeedback: string } | null> {
      try {
        const res = await fetch(`/api/trades/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ exit }),
        });
        if (!res.ok) return null;
        const data = await res.json();
        await refreshTrades();
        await refreshTrader();
        // Fetch AI feedback separately.
        let aiFeedback = "";
        try {
          const fbRes = await fetch("/api/ai/trade-feedback", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ trade: data.trade }),
          });
          if (fbRes.ok) {
            const fb = await fbRes.json();
            aiFeedback = fb.content;
          }
        } catch {
          /* ignore */
        }
        return { trade: data.trade, aiFeedback };
      } catch {
        return null;
      }
    },

    async awardXp(input: {
      xp?: number;
      capitalDelta?: number;
      win?: boolean;
      lessonCompleted?: boolean;
      roomCompleted?: boolean;
      disciplineDelta?: number;
    }): Promise<void> {
      try {
        const res = await fetch("/api/trader/earn", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        if (res.ok) {
          // Optimistic feel: refresh from server.
          await refreshTrader();
        }
      } catch {
        /* ignore */
      }
    },

    async setProgress(input: {
      lessonId: string;
      status?: "locked" | "active" | "completed";
      score?: number;
    }): Promise<LessonProgress | null> {
      try {
        const res = await fetch("/api/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        if (!res.ok) return null;
        const p = await res.json();
        await refreshProgress();
        await refreshTrader();
        return p;
      } catch {
        return null;
      }
    },

    async updateTraderName(name: string): Promise<void> {
      patchTrader({ name });
      try {
        await fetch("/api/trader", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name }),
        });
        await refreshTrader();
      } catch {
        /* ignore */
      }
    },

    async deleteTrade(id: string): Promise<void> {
      try {
        await fetch(`/api/trades/${id}`, { method: "DELETE" });
        await refreshTrades();
        await refreshTrader();
      } catch {
        /* ignore */
      }
    },

    async resetTrades(): Promise<void> {
      // Delete all trades then refresh. Implemented in module via repeated delete.
      // Kept here for completeness but modules handle their own loops.
    },
  };
}
