// Shared domain types for TradeHackMe AI.
// Mirror the Prisma models (see prisma/schema.prisma).

export interface Trader {
  id: string;
  name: string;
  rank: number;
  rankName: string;
  xp: number;
  capital: number;
  startingCapital: number;
  tradesDone: number;
  wins: number;
  losses: number;
  bestStreak: number;
  currentStreak: number;
  lessonsCompleted: number;
  roomsCompleted: number;
  disciplineScore: number;
  createdAt: string;
  updatedAt: string;
}

export interface Trade {
  id: string;
  traderId: string;
  symbol: string;
  side: "LONG" | "SHORT";
  entry: number;
  exit: number | null;
  size: number;
  stopLoss: number | null;
  takeProfit: number | null;
  pnl: number | null;
  rMultiple: number | null;
  status: "OPEN" | "CLOSED";
  context: string;
  aiFeedback: string | null;
  reason: string | null;
  openedAt: string;
  closedAt: string | null;
}

export interface LessonProgress {
  id: string;
  traderId: string;
  lessonId: string;
  status: "locked" | "active" | "completed";
  score: number;
  completedAt: string | null;
}

export interface ChatMessage {
  id: string;
  traderId: string;
  role: "user" | "assistant";
  content: string;
  module: string;
  createdAt: string;
}

export type ViewKey =
  | "dashboard"
  | "academy"
  | "simulation"
  | "rooms"
  | "replay"
  | "mentor"
  | "psychology"
  | "scenarios"
  | "chart-ai"
  | "journal"
  | "analytics"
  | "leaderboard";
