import { db } from '@/lib/db'

/**
 * Ensures the singleton trader (id = "me") exists.
 * Creates with defaults if missing, otherwise returns existing.
 * Safe to call repeatedly (idempotent).
 */
export async function ensureTrader() {
  const trader = await db.trader.upsert({
    where: { id: 'me' },
    update: {},
    create: { id: 'me' },
  })
  return trader
}
