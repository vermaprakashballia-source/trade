"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Trader, Trade, LessonProgress, ViewKey } from "@/lib/types";

interface StoreState {
  // UI state (persisted)
  activeView: ViewKey;
  sidebarOpen: boolean;
  hydrated: boolean;

  // Domain state (fetched, not persisted)
  trader: Trader | null;
  trades: Trade[];
  progress: LessonProgress[];
  dataLoaded: boolean;

  // Actions
  setActiveView: (v: ViewKey) => void;
  setSidebarOpen: (b: boolean) => void;
  setHydrated: (b: boolean) => void;

  hydrate: () => Promise<void>;
  refreshTrader: () => Promise<void>;
  refreshTrades: () => Promise<void>;
  refreshProgress: () => Promise<void>;

  // Convenience patch for local optimistic updates
  patchTrader: (patch: Partial<Trader>) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      activeView: "dashboard",
      sidebarOpen: false,
      hydrated: false,

      trader: null,
      trades: [],
      progress: [],
      dataLoaded: false,

      setActiveView: (v) => set({ activeView: v, sidebarOpen: false }),
      setSidebarOpen: (b) => set({ sidebarOpen: b }),
      setHydrated: (b) => set({ hydrated: b }),

      hydrate: async () => {
        await Promise.all([
          get().refreshTrader(),
          get().refreshTrades(),
          get().refreshProgress(),
        ]);
        set({ dataLoaded: true });
      },

      refreshTrader: async () => {
        try {
          const res = await fetch("/api/trader");
          if (res.ok) {
            const t = await res.json();
            set({ trader: t });
          }
        } catch {
          /* ignore */
        }
      },

      refreshTrades: async () => {
        try {
          const res = await fetch("/api/trades");
          if (res.ok) {
            const t = await res.json();
            set({ trades: t });
          }
        } catch {
          /* ignore */
        }
      },

      refreshProgress: async () => {
        try {
          const res = await fetch("/api/progress");
          if (res.ok) {
            const p = await res.json();
            set({ progress: p });
          }
        } catch {
          /* ignore */
        }
      },

      patchTrader: (patch) => {
        const cur = get().trader;
        if (cur) set({ trader: { ...cur, ...patch } });
      },
    }),
    {
      name: "thm-ui",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        activeView: s.activeView,
        sidebarOpen: s.sidebarOpen,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    }
  )
);
