# TradeHackMe AI — Worklog

This file is the shared worklog for all agents building TradeHackMe AI.
Append (do not overwrite) new sections separated by `---`.

## Project conventions
- Next.js 16 App Router, TypeScript, Tailwind v4, shadcn/ui (New York).
- Single user-visible route: `/` (src/app/page.tsx). All modules switch via Zustand `activeView` state.
- Dark trading-desk aesthetic by default. Brand accent = emerald (growth). Up = emerald, Down = rose. Avoid indigo/blue as primary brand color.
- AI via `z-ai-web-dev-sdk` (backend only). Import: `import ZAI from 'z-ai-web-dev-sdk'`, then `const zai = await ZAI.create()`.
- Database: Prisma + SQLite. `import { db } from '@/lib/db'`.
- Use API routes (not server actions) for backend logic.
- Shared contracts (must match exactly across agents):
  - `src/lib/market.ts`: `interface Candle { time:number; open:number; high:number; low:number; close:number; volume:number }`, `generateSeries(seed:number, count:number, startPrice:number, opts?:{volatility?:number; drift?:number}): Candle[]`, `fmtPrice(n:number):string`, `fmtINR(n:number):string`, `fmtCompact(n:number):string`, `computeR(...)` helpers if needed.
  - `src/components/candle-chart.tsx`: default export `CandleChart` with props documented in the file.
  - Prisma models: `Trader`, `Trade`, `LessonProgress`, `ChatMessage` (schema defined by Task 2).
  - Trader singleton id = `"me"`.

---

## Task ID: 2 — Data Layer (Prisma Schema + API Routes)

- **Agent name:** Data Layer Agent
- **Task:** Define the Prisma schema for the four core models, push to SQLite, create a singleton-trader seed helper, and implement all REST API routes for trader state, trades, lesson progress, and chat history.

### Work Log

1. **Schema** — Replaced `prisma/schema.prisma` body (kept `generator client` + `datasource db`). Defined exactly four models per spec:
   - `Trader` — singleton (`id @default("me")`), full game-state fields (rank, rankName, xp, capital, startingCapital, tradesDone, wins, losses, bestStreak, currentStreak, lessonsCompleted, roomsCompleted, disciplineScore). Relations: `trades Trade[]`, `progress LessonProgress[]`, `chats ChatMessage[]`.
   - `Trade` — `cuid()` id, `traderId`, symbol/side/entry/exit/size/stopLoss/takeProfit/pnl/rMultiple/status/context/aiFeedback/reason, `openedAt @default(now())`, `closedAt?`. `@@`-free; relation back to `Trader`.
   - `LessonProgress` — `cuid()` id, `(traderId, lessonId)` `@@unique`, status/score/completedAt.
   - `ChatMessage` — `cuid()` id, role/content/module, `createdAt @default(now())`.
2. **Push** — Ran `bun run db:push -- --accept-data-loss`. Schema synced; Prisma Client v6.19.2 generated. Verified the four tables (`ChatMessage`, `LessonProgress`, `Trade`, `Trader`) exist in `db/custom.db`.
3. **Seed helper** — Created `src/lib/seed.ts` exporting `async function ensureTrader()` which uses `db.trader.upsert({ where: { id: 'me' }, update: {}, create: { id: 'me' } })` and returns the row. Idempotent; safe to call from every route handler.
4. **API routes** — All under `src/app/api/...`, App Router `route.ts` files, `NextRequest`/`NextResponse`, every handler calls `ensureTrader()` first and wraps DB calls in `try/catch` returning `{ error }` on 500.

   - **`/api/trader`** (`src/app/api/trader/route.ts`)
     - `GET` → `200 { ...Trader }`
     - `PATCH` body `{ name?, rank?, rankName?, xp?, capital?, tradesDone?, wins?, losses?, bestStreak?, currentStreak?, lessonsCompleted?, roomsCompleted?, disciplineScore? }` → `200 { ...Trader }` (only provided fields updated).
   - **`/api/trader/earn`** (`src/app/api/trader/earn/route.ts`)
     - `POST` body `{ xp?, capitalDelta?, win?, lessonCompleted?, roomCompleted?, disciplineDelta? }`. Reads current trader, computes new streak (win→+1, loss→0; bestStreak = max), increments wins/losses/tradesDone only when `win` is boolean, increments lessons/rooms when flags true, clamps `disciplineScore` to `[0,100]`, adds xp + capitalDelta. Single `db.trader.update` → `200 { ...Trader }`.
   - **`/api/trades`** (`src/app/api/trades/route.ts`)
     - `GET` → `200 Trade[]` (newest first by `openedAt`).
     - `POST` body `{ symbol, side, entry, size, stopLoss?, takeProfit?, context?, reason? }` (validates required fields + side ∈ {LONG, SHORT}; status="OPEN") → `201 { ...Trade }`.
   - **`/api/trades/[id]`** (`src/app/api/trades/[id]/route.ts`) — uses `params: Promise<{ id: string }>` + `await params`.
     - `PATCH` body `{ exit, aiFeedback? }`. Computes `pnl` = `(exit-entry)*size` (LONG) / `(entry-exit)*size` (SHORT); `rMultiple` = reward/risk using `stopLoss` when present. Sets status="CLOSED", closedAt=now. Then updates trader: tradesDone+1, wins/losses+1 by `pnl>0`, capital+=pnl, currentStreak/bestStreak. → `200 { trade: Trade, trader: Trader }`.
     - `DELETE` → `200 { ok: true }`.
   - **`/api/progress`** (`src/app/api/progress/route.ts`)
     - `GET` → `200 LessonProgress[]` (ordered by lessonId asc).
     - `POST` body `{ lessonId, status?, score? }`. Upserts by `(traderId, lessonId)`. On transition to `status="completed"` (was not completed), sets `completedAt` and increments `trader.lessonsCompleted`. → `200 { ...LessonProgress }`.
   - **`/api/chat`** (`src/app/api/chat/route.ts`)
     - `GET ?module=mentor` (default `mentor`) → `200 ChatMessage[]` (oldest first).
     - `POST` body `{ role, content, module? }` (defaults module="mentor") → `201 { ...ChatMessage }`.

### Stage Summary

- Schema is live in SQLite (`Trader`, `Trade`, `LessonProgress`, `ChatMessage`) with the singleton-trader pattern (id `"me"`) as the keystone.
- `ensureTrader()` is the canonical entry point for every data route — downstream agents MUST `import { ensureTrader } from '@/lib/seed'` and call it before any DB work to guarantee the trader row exists.
- All six API route files are in place and import only from `@/lib/db` and `@/lib/seed`. No server actions. No tests written (per instructions).
- Shared response shapes for downstream agents:
  - `GET /api/trader`, `PATCH /api/trader`, `POST /api/trader/earn` → full `Trader` object.
  - `GET /api/trades` → `Trade[]`; `POST /api/trades` → `Trade` (201).
  - `PATCH /api/trades/[id]` → `{ trade: Trade, trader: Trader }`; `DELETE` → `{ ok: true }`.
  - `GET /api/progress` → `LessonProgress[]`; `POST /api/progress` → `LessonProgress`.
  - `GET /api/chat?module=` → `ChatMessage[]`; `POST /api/chat` → `ChatMessage` (201).
  - Errors → `500 { error: string }` (validation → `400 { error }`, not-found → `404 { error }`, forbidden → `403 { error }`).
- Dev server hot-reloaded cleanly after route creation; no compile errors in `dev.log`.

---

## Task ID: 1
**Agent:** foundation-data-chart (Z.ai Code)
**Task:** Create deterministic mock market-data engine (`src/lib/market.ts`) and a self-contained canvas candlestick chart component (`src/components/candle-chart.tsx`).

### Work Log
- Read existing `worklog.md` to confirm shared contracts (Candle shape, generateSeries signature, dark emerald/rose palette, single `/` route, AI backend-only).
- Created `/home/z/my-project/src/lib/market.ts`:
  - `interface Candle { time, open, high, low, close, volume }` (matches shared contract).
  - `mulberry32(seed)` deterministic PRNG.
  - `generateSeries(seed, count, startPrice, opts?)` — random walk with GARCH(1,1)-ish volatility clustering, mean reversion, occasional vol spikes, tiny open gaps (occasionally larger), realistic wicks scaled by current vol, volume correlated with range + extra juice on big moves + random spikes. Fully deterministic by seed.
  - `fmtPrice(n)` → `"154.32"` (2 decimals, en-US grouping, no symbol).
  - `fmtINR(n)` → `₹1,00,000.00` (Indian grouping, 2 decimals, sign-aware).
  - `fmtINRCompact(n)` → `₹1.0L / ₹10.5L / ₹1.2Cr / ₹12.5K / ₹500`.
  - `fmtCompact(n)` → `1.2K / 3.4M / 5.6B`.
  - `pnlPct(entry, exit, side)` and `rMultiple(entry, stop, exit, side)` (returns 0 for invalid stop placement).
  - `SYMBOLS` array: NIFTY50, RELIANCE, TCS, HDFCBANK, INFY, BTCUSD — each with distinct seed + startPrice.
- Created `/home/z/my-project/src/components/candle-chart.tsx` (`'use client'`):
  - Default export `CandleChart`, exported props interfaces `CandleChartProps`, `ChartMark`, `PriceLine`.
  - Pure React + Canvas 2D, no charting libs. Imports `Candle` + `fmtPrice` from `@/lib/market`.
  - Responsive via `ResizeObserver`, devicePixelRatio-crisp canvas.
  - Dark palette (`#0b0f14`); up = accent (emerald default, rose, amber), down = rose (or swapped for rose accent).
  - Right price axis (5 gridlines + labels), bottom time axis (auto intraday vs daily formatting).
  - Volume panel (~18% of chart height) with faint up/down bars.
  - Crosshair (dashed) + right-axis price pill + bottom-axis time pill on hover; disabled when `interactive=false`.
  - OHLC legend top-left (symbol + O/H/L/C + change%) for hovered candle, else last candle.
  - `marks` → translucent vertical bands with colored tag pill above chart.
  - `lines` → dashed horizontal lines with right-edge colored pill labels.
  - Empty data → renders "No data". Memoized `view` slice + single `useEffect` redraw.
- Did not run lint/build per instructions.

### Stage Summary
Foundation pieces delivered: deterministic market engine + production-quality canvas chart. Both files use only the agreed shared contracts (Candle shape, fmtPrice, etc.), so downstream agents (trading replays, lesson engine, AI coach UI) can import directly:
- `import { Candle, generateSeries, fmtPrice, fmtINR, fmtINRCompact, fmtCompact, pnlPct, rMultiple, SYMBOLS } from '@/lib/market'`
- `import CandleChart, { CandleChartProps, ChartMark, PriceLine } from '@/components/candle-chart'`

Exact export names:
- `market.ts`: `Candle` (interface), `mulberry32`, `generateSeries`, `fmtPrice`, `fmtINR`, `fmtINRCompact`, `fmtCompact`, `pnlPct`, `rMultiple`, `SYMBOLS`.
- `candle-chart.tsx`: default export `CandleChart`; named exports `ChartMark`, `PriceLine`, `CandleChartProps` (interfaces).

---
Task ID: 3-18 (orchestrator)
Agent: Z.ai Code (main)
Task: Build design system, store, AI layer, all 12 modules, wire shell, self-verify.

Work Log:
- Authored dark trading-desk theme (globals.css), theme provider, layout shell (app-shell.tsx) with sidebar nav + topbar + sticky footer + mobile sheet.
- Zustand store (use-store.ts) syncing trader/trades/progress to REST API; UI prefs persisted to localStorage.
- AI singleton (zai.ts) + 5 AI API routes: mentor (LLM), chart-analysis (VLM), trade-feedback (LLM), scenario (LLM), psychology (LLM).
- Shared libs: types, ranks (9-rank ladder), patterns (candlestick detectors), content (11 lessons, 4 rooms, 5 scenarios, 5 psych scenarios), trade-metrics, client-api hook, ui-bits, markdown renderer.
- 12 modules: Dashboard, Academy, Simulation, Trading Rooms, Trade Replay Lab, AI Mentor, Psychology Simulator, Scenario Trainer, AI Chart Analysis, Trade Journal, Performance Analytics, Leaderboard.
- Fixed lint errors (trade-metrics array brace, chart-ai useSample→generateSample, unused eslint-disables, psychology effect ordering) and a runtime scoping bug in analytics (style variable).

Stage Summary:
- Lint clean (0 problems). Dev server healthy on :3000.
- Agent Browser verified end-to-end: dashboard+AI greeting, Academy lesson completion with XP, Simulator open/close trade with real AI feedback, AI Mentor context-aware chat, VLM chart analysis of generated chart, Analytics with real trade data.
- Responsive (mobile sheet nav, no horizontal overflow), sticky footer verified on short & long pages (no overlap), zero console/runtime/hydration errors.
- All 8 vision levels from the spec represented: Academy, Simulation, Rooms, Replay, Mentor, Psychology, Scenarios, Chart AI, plus Journal, Analytics, Leaderboard, ranking system, AI feedback on every trade, psychology reports, and AI deep-dives.

---
Task ID: 19 (OpenAI provider integration)
Agent: Z.ai Code (main)
Task: Add OpenAI as an optional AI provider (user supplied an API key — treated as compromised; not written to any file).

Work Log:
- Created src/lib/ai-provider.ts: unified aiChat() + aiVision() that route to OpenAI Chat Completions when OPENAI_API_KEY env is set, else fall back to the Z.ai SDK (and on any OpenAI error). Configurable via OPENAI_MODEL (default gpt-4o-mini), OPENAI_VISION_MODEL, OPENAI_BASE_URL.
- Refactored all 5 AI routes (mentor, chart-analysis, trade-feedback, scenario, psychology) to use aiChat/aiVision instead of the raw ZAI client.
- Added diagnostic GET /api/ai/provider -> { provider, openaiConfigured }.
- Created .env.local with an EMPTY OPENAI_API_KEY + instructions (the user's pasted key was NOT used; it must be revoked/rotated).
- Lint clean. Verified: /api/ai/provider returns {"provider":"zai","openaiConfigured":false}; /api/ai/mentor returns real context-aware reply via the Z.ai fallback; app renders in browser with zero errors.

Stage Summary:
- The app's AI was already connected (Z.ai SDK). OpenAI is now an OPTIONAL drop-in provider.
- To enable OpenAI: revoke the leaked key, create a fresh one, set OPENAI_API_KEY=... in .env.local, restart `bun run dev`. The /api/ai/provider endpoint confirms which backend is active.
- Automatic fallback to Z.ai means features never break even if OpenAI errors or is unreachable.
